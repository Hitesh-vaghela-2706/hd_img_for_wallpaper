from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import User
from .forms import UserForm

def user_list(request):
    users = User.objects.all()
    return render(request, 'user/user_list.html', {'users': users})

def user_create(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            # Check if email already exists
            if User.objects.filter(email=email).exists():
                form.add_error('email', 'A user with this email already exists.')
                return render(request, 'user/user_form.html', {'form': form, 'email_exists': True})
            user = form.save()
            return redirect('user_list')
    else:
        form = UserForm()
    return render(request, 'user/user_form.html', {'form': form})

def user_update(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            email = form.cleaned_data['email']
            # Check if email exists for a different user
            if User.objects.filter(email=email).exclude(pk=pk).exists():
                form.add_error('email', 'A user with this email already exists.')
                return render(request, 'user/user_form.html', {'form': form, 'email_exists': True})
            form.save()
            return redirect('user_list')
    else:
        form = UserForm(instance=user)
    return render(request, 'user/user_form.html', {'form': form})

def user_delete(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        user.delete()
        return redirect('user_list')