# Image & PDF Processing Web Application

This project is a full-stack web application designed to handle comprehensive image and PDF processing tasks directly in the browser. It was built strictly according to the provided Software Requirements Specification (SRS) document.

## 🚀 Tech Stack

- **Frontend:** React 18 (via CDN), Babel Standalone, Vanilla CSS (Glassmorphism & Dark Mode UI).
- **Backend:** Python, FastAPI, Uvicorn.
- **Image Processing Libraries:** `Pillow`, `opencv-python-headless`, `rembg`.
- **PDF Processing Libraries:** `PyMuPDF` (fitz), `ReportLab`.
- **Architecture:** API-based modular structure with routers and a service layer.

---

## 🛠️ Features & Tools Implemented

### Image Tools (12)

1. **Compress Image**: Reduce image file size while maintaining quality.
2. **Resize Image**: Scale images by percentage or specific width/height.
3. **Crop Image**: Crop images by specifying boundaries.
4. **Convert Format**: Convert between JPG, PNG, WEBP, GIF, BMP, etc.
5. **Photo Editing**: Adjust Brightness, Contrast, Saturation, and Sharpness.
6. **Upscale Image**: AI-based upscaling (2x/4x) using OpenCV.
7. **Remove Background**: AI background removal using `rembg`.
8. **Watermark Image**: Add text watermarks with adjustable opacity and position.
9. **Meme Generator**: Add classic top and bottom text to images.
10. **Rotate Image**: Rotate images to precise degrees.
11. **HTML to Image**: Basic URL screenshot renderer.
12. **Blur Face**: Automatically detects faces and blurs them using Haar Cascades.

### New Image Tools (3)

1. **Image to PDF**: Combine multiple images into a single formatted PDF document.
2. **Background Color Changer**: Automatically remove backgrounds and apply custom hex colors.
3. **Passport Photo Generator**: Automatically centers faces and formats photos into printable sheets according to international standards (India, USA, UK, EU).

### PDF Tools (9)

1. **Compress PDF**: Compress PDF files with quality presets (Screen, Ebook, Printer).
2. **Merge PDF**: Combine multiple PDF files into one.
3. **Split PDF**: Split by specific page ranges or extract individual pages.
4. **PDF to Image**: Export every page of a PDF as high-quality JPG or PNG images.
5. **Watermark PDF**: Add text watermarks across all pages of a PDF.
6. **Protect PDF**: Add 128-bit AES password encryption to PDFs.
7. **Rotate PDF**: Rotate PDF pages (90°, 180°, 270°).
8. **Unlock PDF**: Remove passwords from protected PDFs.
9. **Passport PDF**: A printable, print-ready PDF containing standard passport photos with crop marks.

---

## 📂 Project Structure

```text
/SRS IMAGE/
├── frontend/
│   ├── index.html           # Main entry point
│   ├── css/
│   │   ├── style.css        # Global CSS variables, Dark Mode, Layout
│   │   └── tools.css        # Specific tool UI overrides
│   └── js/
│       ├── app.js           # Core React Application & Router
│       ├── components.js    # Reusable UI components (DropZone, Spinners)
│       ├── pages.js         # Page Combiner
│       ├── pages_image.js   # Image Tool Pages
│       └── pages_new.js     # New Tools & PDF Tool Pages
└── backend/
    ├── main.py              # FastAPI application & static file mounting
    ├── requirements.txt     # Python dependencies
    ├── routers/
    │   ├── image_tools.py   # Endpoints for Image Tools
    │   ├── new_image_tools.py # Endpoints for New Image Tools
    │   └── pdf_tools.py     # Endpoints for PDF Tools
    ├── services/
    │   ├── image_service.py # Image helper utilities
    │   ├── passport_service.py # Passport standard configs
    │   └── pdf_service.py   # PDF helper utilities
    └── temp_files/          # Auto-cleared temporary storage
```

---

## 🏃 How to Run the Application

The application serves the React frontend directly from the FastAPI backend.

1. **Navigate to the backend directory:**

   ```bash
   cd "/home/rdp/Desktop/SRS IMAGE/backend"
   ```

2. **Start the FastAPI server:**

   ```bash
   uvicorn main:app --port 8000 --reload
   ```

3. **Access the Web App:**
   Open your browser and navigate to:
   [http://localhost:8000](http://localhost:8000)

_(Note: The server includes an auto-cleanup task that deletes temporary processing files older than 60 minutes, ensuring the server doesn't run out of space.)_
