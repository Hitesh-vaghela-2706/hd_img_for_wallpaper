"""
Image & PDF Processing Web Application - FastAPI Backend
"""
import os
import shutil
import asyncio
from datetime import datetime, timedelta
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from routers import image_tools, new_image_tools, pdf_tools

TEMP_DIR = os.path.join(os.path.dirname(__file__), "temp_files")
os.makedirs(TEMP_DIR, exist_ok=True)


async def cleanup_old_files():
    """Delete temp files older than 60 minutes."""
    while True:
        now = datetime.now()
        try:
            for fname in os.listdir(TEMP_DIR):
                fpath = os.path.join(TEMP_DIR, fname)
                if os.path.isfile(fpath):
                    mtime = datetime.fromtimestamp(os.path.getmtime(fpath))
                    if now - mtime > timedelta(minutes=60):
                        os.remove(fpath)
        except Exception:
            pass
        await asyncio.sleep(300)  # check every 5 minutes


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(cleanup_old_files())
    yield
    task.cancel()


app = FastAPI(
    title="Image & PDF Processing API",
    description="Comprehensive image and PDF processing tools",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(image_tools.router, prefix="/api/image", tags=["Image Tools"])
app.include_router(new_image_tools.router, prefix="/api/new-image", tags=["New Image Tools"])
app.include_router(pdf_tools.router, prefix="/api/pdf", tags=["PDF Tools"])

# Mount static frontend
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")



@app.get("/")
def root():
    return {"message": "Image & PDF Processing API", "version": "1.0.0"}


@app.get("/health")
def health():
    return {"status": "ok", "temp_dir": TEMP_DIR}
