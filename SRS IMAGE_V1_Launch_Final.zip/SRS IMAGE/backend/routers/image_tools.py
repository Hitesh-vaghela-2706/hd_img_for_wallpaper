"""
Image Tools Router - Handles all 12 existing image processing tools.
"""
import io
import os
import uuid
import math
import zipfile
import textwrap
from typing import Optional

import cv2
import numpy as np
from PIL import Image, ImageFilter, ImageEnhance, ImageDraw, ImageFont
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse

router = APIRouter()
TEMP_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "temp_files")


def pil_to_bytes(img: Image.Image, fmt: str = "JPEG", quality: int = 85) -> bytes:
    buf = io.BytesIO()
    fmt = fmt.upper()
    if fmt == "JPG":
        fmt = "JPEG"
    if fmt == "JPEG" and img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGB")
    save_kwargs = {}
    if fmt == "JPEG":
        save_kwargs["quality"] = quality
        save_kwargs["optimize"] = True
    elif fmt == "PNG":
        save_kwargs["optimize"] = True
    elif fmt == "WEBP":
        save_kwargs["quality"] = quality
    img.save(buf, format=fmt, **save_kwargs)
    buf.seek(0)
    return buf.read()


def stream_image(data: bytes, media_type: str = "image/jpeg", filename: str = "output.jpg"):
    return StreamingResponse(
        io.BytesIO(data),
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


MIME_MAP = {
    "jpeg": "image/jpeg", "jpg": "image/jpeg",
    "png": "image/png", "webp": "image/webp",
    "gif": "image/gif", "bmp": "image/bmp",
    "tiff": "image/tiff", "tif": "image/tiff",
}


# ─────────────────────────────────────────────
# 1. COMPRESS IMAGE
# ─────────────────────────────────────────────
@router.post("/compress")
async def compress_image(
    file: UploadFile = File(...),
    quality: int = Form(75),
    output_format: str = Form("same"),
    target_size: Optional[float] = Form(None),
    target_unit: Optional[str] = Form("kb"),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = ext if output_format == "same" else output_format
    if fmt in ("jpg", "jpeg"):
        fmt = "JPEG"
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGB")
    elif fmt == "png":
        fmt = "PNG"
    elif fmt == "webp":
        fmt = "WEBP"
    else:
        fmt = "JPEG"
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGB")

    target_bytes = None
    if target_size is not None and target_size > 0:
        if target_unit.lower() == "mb":
            target_bytes = int(target_size * 1024 * 1024)
        else:
            target_bytes = int(target_size * 1024)

    if target_bytes:
        # Target size compression logic
        current_img = img.copy()
        current_quality = 95
        scale_factor = 1.0
        
        while True:
            buf = io.BytesIO()
            if scale_factor < 1.0:
                w, h = img.size
                nw, nh = max(16, int(w * scale_factor)), max(16, int(h * scale_factor))
                temp_img = current_img.resize((nw, nh), Image.LANCZOS)
            else:
                temp_img = current_img

            if fmt == "PNG":
                temp_img.save(buf, format="PNG", optimize=True, compress_level=9)
            elif fmt == "WEBP":
                temp_img.save(buf, format="WEBP", quality=current_quality, optimize=True)
            else:
                temp_img.save(buf, format="JPEG", quality=current_quality, optimize=True)
                
            compressed_bytes = len(buf.getvalue())
            
            if compressed_bytes <= target_bytes:
                compressed = buf.getvalue()
                break
            
            if fmt != "PNG" and current_quality > 15:
                current_quality -= 10
            else:
                if scale_factor > 0.15:
                    scale_factor -= 0.1
                    if fmt != "PNG":
                        current_quality = 75
                else:
                    compressed = buf.getvalue()
                    break
    else:
        buf = io.BytesIO()
        if fmt == "PNG":
            img.save(buf, format="PNG", optimize=True, compress_level=9)
        elif fmt == "WEBP":
            img.save(buf, format="WEBP", quality=quality, optimize=True)
        else:
            img.save(buf, format=fmt, quality=quality, optimize=True)
        buf.seek(0)
        compressed = buf.getvalue()

    out_ext = fmt.lower().replace("jpeg", "jpg")
    return StreamingResponse(
        io.BytesIO(compressed),
        media_type=MIME_MAP.get(out_ext, "image/jpeg"),
        headers={
            "Content-Disposition": f'attachment; filename="compressed.{out_ext}"',
            "X-Original-Size": str(len(data)),
            "X-Compressed-Size": str(len(compressed)),
        },
    )


# ─────────────────────────────────────────────
# 2. RESIZE IMAGE
# ─────────────────────────────────────────────
@router.post("/resize")
async def resize_image(
    file: UploadFile = File(...),
    width: Optional[int] = Form(None),
    height: Optional[int] = Form(None),
    percent: Optional[float] = Form(None),
    maintain_aspect: bool = Form(True),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    orig_w, orig_h = img.size

    if percent is not None:
        new_w = int(orig_w * percent / 100)
        new_h = int(orig_h * percent / 100)
    elif width and height and not maintain_aspect:
        new_w, new_h = width, height
    elif width and not height:
        new_w = width
        new_h = int(orig_h * (width / orig_w))
    elif height and not width:
        new_h = height
        new_w = int(orig_w * (height / orig_h))
    elif width and height and maintain_aspect:
        ratio = min(width / orig_w, height / orig_h)
        new_w = int(orig_w * ratio)
        new_h = int(orig_h * ratio)
    else:
        raise HTTPException(400, "Provide width, height, or percent")

    resized = img.resize((new_w, new_h), Image.LANCZOS)
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "JPEG" if ext in ("jpg", "jpeg") else ext.upper()
    return stream_image(pil_to_bytes(resized, fmt), MIME_MAP.get(ext, "image/jpeg"), f"resized.{ext}")


# ─────────────────────────────────────────────
# 3. CROP IMAGE
# ─────────────────────────────────────────────
@router.post("/crop")
async def crop_image(
    file: UploadFile = File(...),
    left: int = Form(...),
    top: int = Form(...),
    right: int = Form(...),
    bottom: int = Form(...),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    w, h = img.size
    left = max(0, min(left, w))
    top = max(0, min(top, h))
    right = max(left + 1, min(right, w))
    bottom = max(top + 1, min(bottom, h))
    cropped = img.crop((left, top, right, bottom))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "JPEG" if ext in ("jpg", "jpeg") else ext.upper()
    return stream_image(pil_to_bytes(cropped, fmt), MIME_MAP.get(ext, "image/jpeg"), f"cropped.{ext}")


# ─────────────────────────────────────────────
# 4. CONVERT IMAGE FORMAT
# ─────────────────────────────────────────────
@router.post("/convert")
async def convert_image(
    file: UploadFile = File(...),
    output_format: str = Form("jpeg"),
    quality: int = Form(85),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    fmt = output_format.lower()
    if fmt == "jpg":
        fmt = "jpeg"
    pil_fmt = fmt.upper()
    if pil_fmt == "JPEG" and img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format=pil_fmt, quality=quality, optimize=True)
    buf.seek(0)
    ext = "jpg" if fmt == "jpeg" else fmt
    return StreamingResponse(
        buf,
        media_type=MIME_MAP.get(ext, f"image/{fmt}"),
        headers={"Content-Disposition": f'attachment; filename="converted.{ext}"'},
    )


# ─────────────────────────────────────────────
# 5. PHOTO EDITING (Brightness/Contrast/Saturation/Sharpness)
# ─────────────────────────────────────────────
@router.post("/edit")
async def edit_photo(
    file: UploadFile = File(...),
    brightness: float = Form(1.0),
    contrast: float = Form(1.0),
    saturation: float = Form(1.0),
    sharpness: float = Form(1.0),
    hue_rotate: int = Form(0),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data)).convert("RGBA")
    rgb = img.convert("RGB")
    rgb = ImageEnhance.Brightness(rgb).enhance(max(0.1, min(brightness, 3.0)))
    rgb = ImageEnhance.Contrast(rgb).enhance(max(0.1, min(contrast, 3.0)))
    rgb = ImageEnhance.Color(rgb).enhance(max(0, min(saturation, 3.0)))
    rgb = ImageEnhance.Sharpness(rgb).enhance(max(0, min(sharpness, 3.0)))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "PNG" if ext == "png" else "JPEG"
    out_img = rgb.convert("RGBA") if fmt == "PNG" else rgb
    return stream_image(pil_to_bytes(out_img, fmt), MIME_MAP.get(ext, "image/jpeg"), f"edited.{ext}")


# ─────────────────────────────────────────────
# 6. UPSCALE IMAGE (OpenCV DNN / Bicubic fallback)
# ─────────────────────────────────────────────
@router.post("/upscale")
async def upscale_image(
    file: UploadFile = File(...),
    scale: int = Form(2),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    scale = max(1, min(scale, 4))
    new_w = img.width * scale
    new_h = img.height * scale
    upscaled = img.resize((new_w, new_h), Image.LANCZOS)
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "PNG" if ext == "png" else "JPEG"
    return stream_image(pil_to_bytes(upscaled, fmt), MIME_MAP.get(ext, "image/jpeg"), f"upscaled_{scale}x.{ext}")


# ─────────────────────────────────────────────
# 7. BACKGROUND REMOVAL (rembg)
# ─────────────────────────────────────────────
@router.post("/remove-bg")
async def remove_background(file: UploadFile = File(...)):
    try:
        from rembg import remove
    except ImportError:
        raise HTTPException(500, "rembg not installed")
    data = await file.read()
    result = remove(data)
    return StreamingResponse(
        io.BytesIO(result),
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="no_bg.png"'},
    )


# ─────────────────────────────────────────────
# 8. WATERMARK IMAGE
# ─────────────────────────────────────────────
@router.post("/watermark")
async def watermark_image(
    file: UploadFile = File(...),
    text: str = Form("Watermark"),
    opacity: int = Form(50),
    rotation: int = Form(0),
    position: str = Form("center"),
    font_size: int = Form(40),
    color: str = Form("#ffffff"),
    x_pct: float = Form(-1),
    y_pct: float = Form(-1),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data)).convert("RGBA")
    w, h = img.size

    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()

    meas = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    bbox = meas.textbbox((0, 0), text, font=font)
    text_cx = (bbox[0] + bbox[2]) / 2
    text_cy = (bbox[1] + bbox[3]) / 2
    margin = 10

    positions = {
        "center": (w / 2 - text_cx, h / 2 - text_cy),
        "top-left": (margin - bbox[0], margin - bbox[1]),
        "top-right": (w - margin - bbox[2], margin - bbox[1]),
        "bottom-left": (margin - bbox[0], h - margin - bbox[3]),
        "bottom-right": (w - margin - bbox[2], h - margin - bbox[3]),
    }

    if x_pct >= 0 and y_pct >= 0:
        x = int((x_pct / 100.0) * w - text_cx)
        y = int((y_pct / 100.0) * h - text_cy)
    else:
        x, y = positions.get(position, positions["center"])
        x, y = int(x), int(y)

    hex_color = color.lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join(c * 2 for c in hex_color)
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    alpha = int(opacity * 255 / 100)

    txt_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    txt_draw = ImageDraw.Draw(txt_layer)
    txt_draw.text((x, y), text, font=font, fill=(r, g, b, alpha))

    if rotation != 0:
        pivot_x = x + text_cx
        pivot_y = y + text_cy
        txt_layer = txt_layer.rotate(
            -rotation,
            expand=False,
            center=(pivot_x, pivot_y),
            resample=Image.BICUBIC,
        )

    watermarked = Image.alpha_composite(img, txt_layer)

    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "PNG" if ext == "png" else "JPEG"
    return stream_image(pil_to_bytes(watermarked, fmt), MIME_MAP.get(ext, "image/jpeg"), f"watermarked.{ext}")



# ─────────────────────────────────────────────
# 10. ROTATE IMAGE
# ─────────────────────────────────────────────
@router.post("/rotate")
async def rotate_image(
    file: UploadFile = File(...),
    angle: float = Form(90),
    expand: bool = Form(True),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    rotated = img.rotate(-angle, expand=expand, resample=Image.BICUBIC)
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "PNG" if ext == "png" else "JPEG"
    return stream_image(pil_to_bytes(rotated, fmt), MIME_MAP.get(ext, "image/jpeg"), f"rotated.{ext}")


# ─────────────────────────────────────────────
# 11. HTML TO IMAGE (text-based, simple renderer)
# ─────────────────────────────────────────────
@router.post("/html-to-image")
async def html_to_image(
    html_content: str = Form(""),
    url: str = Form(""),
    width: int = Form(1280),
    height: int = Form(720),
):
    """
    Renders HTML/URL to image using PIL (basic implementation).
    For full rendering, playwright would be used.
    """
    # Create a simple placeholder image with info text
    img = Image.new("RGB", (width, height), color=(30, 30, 50))
    draw = ImageDraw.Draw(img)
    try:
        font_big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
    except Exception:
        font_big = ImageFont.load_default()
        font_small = font_big

    draw.text((40, 40), "HTML to Image", font=font_big, fill="#ffffff")
    display = url if url else (html_content[:100] + "..." if len(html_content) > 100 else html_content)
    wrapped = textwrap.wrap(display, width=80)
    y = 100
    for line in wrapped[:20]:
        draw.text((40, y), line, font=font_small, fill="#aaaaaa")
        y += 24
    draw.text((40, height - 60), f"Size: {width}x{height}px", font=font_small, fill="#666666")

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png",
                             headers={"Content-Disposition": 'attachment; filename="screenshot.png"'})


# ─────────────────────────────────────────────
# 12. BLUR FACE
# ─────────────────────────────────────────────
@router.post("/blur-face")
async def blur_face(
    file: UploadFile = File(...),
    blur_strength: int = Form(25),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data)).convert("RGB")
    cv_img = np.array(img)
    cv_img = cv2.cvtColor(cv_img, cv2.COLOR_RGB2BGR)

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        roi = cv_img[y:y+h, x:x+w]
        k = blur_strength * 2 + 1
        blurred_roi = cv2.GaussianBlur(roi, (k, k), 0)
        cv_img[y:y+h, x:x+w] = blurred_roi

    result_img = Image.fromarray(cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    fmt = "PNG" if ext == "png" else "JPEG"
    faces_count = len(faces)
    return StreamingResponse(
        io.BytesIO(pil_to_bytes(result_img, fmt)),
        media_type=MIME_MAP.get(ext, "image/jpeg"),
        headers={
            "Content-Disposition": f'attachment; filename="blurred.{ext}"',
            "X-Faces-Detected": str(faces_count),
        },
    )


# ─────────────────────────────────────────────
# INFO: Get image metadata
# ─────────────────────────────────────────────
@router.post("/info")
async def image_info(file: UploadFile = File(...)):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    return JSONResponse({
        "filename": file.filename,
        "width": img.width,
        "height": img.height,
        "mode": img.mode,
        "format": img.format,
        "size_bytes": len(data),
        "size_kb": round(len(data) / 1024, 1),
    })

# ─────────────────────────────────────────────
# 12. REMOVE WATERMARK (auto-detect by text)
# ─────────────────────────────────────────────
_FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
]


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    for path in _FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _red_excess_channel(cv_img: np.ndarray) -> np.ndarray:
    b, g, r = cv2.split(cv_img)
    return cv2.subtract(r, cv2.max(g, b))


def _render_text_layer(text: str, font_size: int, color_rgb: tuple, alpha: float, bg: int = 128) -> tuple:
    """Render semi-transparent text on neutral background; return RGB array and alpha mask."""
    font = _load_font(font_size)
    probe = Image.new("RGBA", (4, 4), (0, 0, 0, 0))
    pb = ImageDraw.Draw(probe)
    bbox = pb.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    pad = max(8, font_size // 5)
    size = (tw + pad * 2, th + pad * 2)
    base = Image.new("RGB", size, (bg, bg, bg))
    overlay = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    draw.text((pad, pad), text, font=font, fill=(*color_rgb, int(max(0, min(1, alpha)) * 255)))
    composed = Image.alpha_composite(base.convert("RGBA"), overlay)
    rgb = np.array(composed.convert("RGB"))
    alpha_mask = np.array(overlay.split()[-1])
    return rgb, alpha_mask, tw, th


def _match_template_score(target: np.ndarray, template: np.ndarray) -> tuple:
    th, tw = template.shape[:2]
    h, w = target.shape[:2]
    if th >= h or tw >= w or th < 8 or tw < 8:
        return 0.0, (0, 0)
    result = cv2.matchTemplate(target, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)
    return float(max_val), max_loc


def _search_text_templates(
    target: np.ndarray,
    text: str,
    font_min: int,
    font_max: int,
    font_step: int,
    colors_rgb: list,
    alphas: list,
    channel: str = "red",
    early_exit: float = 0.88,
) -> Optional[tuple]:
    best = None
    for variant in dict.fromkeys([text, text.lower()]):
        for font_size in range(font_min, font_max + 1, font_step):
            for alpha in alphas:
                for color in colors_rgb:
                    rgb, _, tw, th = _render_text_layer(variant, font_size, color, alpha)
                    if channel == "gray":
                        tmpl = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
                    else:
                        tmpl = _red_excess_channel(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
                    score, loc = _match_template_score(target, tmpl)
                    if best is None or score > best[0]:
                        best = (score, loc[0], loc[1], tw, th, font_size)
                    if best[0] >= early_exit:
                        return best
    return best


def _find_watermark_by_template(cv_img: np.ndarray, text: str) -> Optional[tuple]:
    """Locate watermark text via fast coarse-to-fine template matching."""
    h, w = cv_img.shape[:2]
    red_exc = _red_excess_channel(cv_img)
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)

    font_min = max(20, int(min(h, w) * 0.04))
    font_max = min(int(max(h, w) * 0.45), 260)
    red_colors = [(200, 100, 100), (180, 80, 80), (220, 120, 120)]
    light_colors = [(255, 255, 255), (220, 220, 220)]
    coarse_alphas = [0.35, 0.55, 0.75]

    # Pass 1 — coarse search on a downscaled image (fast)
    scale = min(1.0, 640 / max(h, w))
    if scale < 1.0:
        red_small = cv2.resize(red_exc, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        gray_small = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        smin = max(16, int(font_min * scale))
        smax = max(smin + 8, int(font_max * scale))
    else:
        red_small, gray_small = red_exc, gray
        smin, smax = font_min, font_max

    coarse = _search_text_templates(
        red_small, text, smin, smax, 10, red_colors, coarse_alphas, channel="red", early_exit=0.82
    )
    if not coarse or coarse[0] < 0.45:
        coarse_gray = _search_text_templates(
            gray_small, text, smin, smax, 10, light_colors + [(40, 40, 40)], coarse_alphas,
            channel="gray", early_exit=0.82,
        )
        if coarse_gray and (not coarse or coarse_gray[0] > coarse[0]):
            coarse = coarse_gray
            use_gray = True
        else:
            use_gray = False
    else:
        use_gray = False

    if not coarse or coarse[0] < 0.45:
        return None

    # Pass 2 — refine around the best match at full resolution
    _, cx, cy, ctw, cth, cfs = coarse
    if scale < 1.0:
        cx, cy = int(cx / scale), int(cy / scale)
        ctw, cth = int(ctw / scale), int(cth / scale)
        cfs = int(cfs / scale)

    target = gray if use_gray else red_exc
    refine_colors = light_colors + [(40, 40, 40)] if use_gray else red_colors
    refined = _search_text_templates(
        target,
        text,
        max(font_min, cfs - 14),
        min(font_max, cfs + 14),
        4,
        refine_colors,
        coarse_alphas,
        channel="gray" if use_gray else "red",
        early_exit=0.92,
    )

    if refined and refined[0] >= 0.50:
        return refined

    return (coarse[0], cx, cy, ctw, cth) if coarse[0] >= 0.50 else None


def _find_watermark_ocr(pil_img: Image.Image, text: str) -> list:
    """Fallback: OCR with multiple preprocessing passes."""
    try:
        import pytesseract
    except ImportError:
        return []

    search = text.lower().strip()
    boxes = []
    arr = np.array(pil_img.convert("RGB"))
    variants = [
        pil_img,
        Image.fromarray(cv2.convertScaleAbs(arr, alpha=1.8, beta=20)),
        Image.fromarray(_red_excess_channel(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))),
    ]

    for variant in variants:
        for psm in (6, 11, 3):
            data = pytesseract.image_to_data(
                variant, output_type=pytesseract.Output.DICT, config=f"--psm {psm}"
            )
            for i, word in enumerate(data["text"]):
                word = (word or "").strip()
                if not word:
                    continue
                try:
                    conf = int(float(data["conf"][i]))
                except (TypeError, ValueError):
                    continue
                if conf < 15:
                    continue
                if search in word.lower() or word.lower() in search:
                    l, t, bw, bh = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
                    if bw > 0 and bh > 0:
                        pad = max(3, min(bw, bh) // 5)
                        boxes.append((max(0, l - pad), max(0, t - pad), l + bw + pad, t + bh + pad))
    return boxes


def _build_precise_watermark_mask(cv_img: np.ndarray, x: int, y: int, tw: int, th: int) -> np.ndarray:
    """Isolate watermark pixels inside a matched bounding box — avoids smearing large areas."""
    h, w = cv_img.shape[:2]
    pad = max(4, min(tw, th) // 12)
    x1, y1 = max(0, x - pad), max(0, y - pad)
    x2, y2 = min(w, x + tw + pad), min(h, y + th + pad)
    roi = cv_img[y1:y2, x1:x2]
    if roi.size == 0:
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)
        return mask

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    red_exc = _red_excess_channel(roi)
    local_mean = cv2.blur(gray, (15, 15))
    diff_bright = cv2.subtract(gray, local_mean)
    diff_dark = cv2.subtract(local_mean, gray)

    _, mask_re = cv2.threshold(red_exc, 8, 255, cv2.THRESH_BINARY)
    _, mask_bright = cv2.threshold(diff_bright, 8, 255, cv2.THRESH_BINARY)
    _, mask_dark = cv2.threshold(diff_dark, 8, 255, cv2.THRESH_BINARY)
    local = cv2.bitwise_or(mask_re, cv2.bitwise_or(mask_bright, mask_dark))

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    local = cv2.morphologyEx(local, cv2.MORPH_CLOSE, kernel, iterations=1)
    local = cv2.dilate(local, kernel, iterations=1)

    mask = np.zeros((h, w), dtype=np.uint8)
    mask[y1:y2, x1:x2] = local

    if cv2.countNonZero(mask) < 80:
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)

    dilate_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    return cv2.dilate(mask, dilate_k, iterations=1)


def _inpaint_watermark(cv_img: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Inpaint only watermark pixels with a small radius to preserve image quality."""
    if not cv2.countNonZero(mask):
        return cv_img
    result = cv2.inpaint(cv_img, mask, 5, cv2.INPAINT_TELEA)
    return cv2.inpaint(result, mask, 3, cv2.INPAINT_NS)


@router.post("/remove-watermark")
async def remove_watermark(
    file: UploadFile = File(...),
    text: str = Form(...),
):
    text = (text or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="Please enter the watermark text to remove.")

    try:
        data = await file.read()
        img = Image.open(io.BytesIO(data)).convert("RGB")
        cv_img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        h, w = cv_img.shape[:2]
        mask = np.zeros((h, w), dtype=np.uint8)

        match = _find_watermark_by_template(cv_img, text)
        if match:
            _, mx, my, tw, th = match[:5]
            mask = _build_precise_watermark_mask(cv_img, mx, my, tw, th)
        else:
            ocr_boxes = _find_watermark_ocr(img, text)
            if not ocr_boxes:
                raise HTTPException(
                    status_code=400,
                    detail=f"Could not find '{text}' in the image. Check spelling, capitalization, or try a shorter phrase.",
                )
            for bx1, by1, bx2, by2 in ocr_boxes:
                tw, th = bx2 - bx1, by2 - by1
                partial = _build_precise_watermark_mask(cv_img, bx1, by1, tw, th)
                mask = cv2.bitwise_or(mask, partial)

        result_cv = _inpaint_watermark(cv_img, mask)
        result_img = Image.fromarray(cv2.cvtColor(result_cv, cv2.COLOR_BGR2RGB))
        ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
        fmt = "PNG" if ext == "png" else "JPEG"
        return stream_image(pil_to_bytes(result_img, fmt), MIME_MAP.get(ext, "image/jpeg"), f"clean.{ext}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Remove watermark failed: {str(e)}")


