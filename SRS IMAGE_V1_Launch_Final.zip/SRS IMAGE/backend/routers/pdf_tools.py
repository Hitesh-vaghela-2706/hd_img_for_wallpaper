"""
PDF Tools Router - All 9 PDF processing tools + Passport PDF
"""
import io
import os
import zipfile
from typing import List, Optional

import fitz  # PyMuPDF
from PIL import Image
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.utils import ImageReader

router = APIRouter()


PAPER_SIZES_MM = {
    "4r":     (101.6, 152.4),
    "a4":     (210.0, 297.0),
    "letter": (215.9, 279.4),
}


def mm_to_px(mm_val: float, dpi: int = 300) -> int:
    return int(mm_val * dpi / 25.4)


def hex_to_rgb(hex_color: str):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def pdf_bytes_to_stream(data: bytes, filename: str = "output.pdf") -> StreamingResponse:
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ─────────────────────────────────────────────
# PDF-01: COMPRESS PDF
# ─────────────────────────────────────────────
@router.post("/compress")
async def compress_pdf(
    file: UploadFile = File(...),
    quality: str = Form("ebook"),  # screen | ebook | printer | prepress
    target_size: Optional[float] = Form(None),
    target_unit: Optional[str] = Form("kb"),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")

    quality_map = {
        "screen": 35,
        "ebook": 60,
        "printer": 90,
        "prepress": 95,
    }
    img_quality = quality_map.get(quality.lower(), 60)

    out_doc = fitz.open()
    for page in doc:
        out_page = out_doc.new_page(width=page.rect.width, height=page.rect.height)
        out_page.show_pdf_page(out_page.rect, doc, page.number)

    # Re-save with compression
    buf = io.BytesIO()
    out_doc.save(buf, garbage=4, deflate=True, clean=True)
    buf.seek(0)
    compressed = buf.getvalue()

    target_bytes = None
    if target_size is not None and target_size > 0:
        if target_unit.lower() == "mb":
            target_bytes = int(target_size * 1024 * 1024)
        else:
            target_bytes = int(target_size * 1024)

    if target_bytes and len(compressed) > target_bytes:
        # We need to compress further by rendering pages as compressed images
        for dpi in [150, 100, 75]:
            for q in [70, 50, 30]:
                buf_temp = io.BytesIO()
                c = rl_canvas.Canvas(buf_temp)
                
                for page_num in range(len(doc)):
                    page = doc[page_num]
                    pix = page.get_pixmap(dpi=dpi)
                    img_data = pix.tobytes("jpeg")
                    img = Image.open(io.BytesIO(img_data))
                    
                    img_buf = io.BytesIO()
                    img.save(img_buf, format="JPEG", quality=q, optimize=True)
                    img_buf.seek(0)
                    
                    pw, ph = page.rect.width, page.rect.height
                    c.setPageSize((pw, ph))
                    c.drawImage(ImageReader(img_buf), 0, 0, pw, ph)
                    c.showPage()
                
                c.save()
                buf_temp.seek(0)
                temp_pdf_data = buf_temp.getvalue()
                
                if len(temp_pdf_data) <= target_bytes:
                    compressed = temp_pdf_data
                    break
            if len(compressed) <= target_bytes:
                break

    doc.close()
    out_doc.close()

    return StreamingResponse(
        io.BytesIO(compressed),
        media_type="application/pdf",
        headers={
            "Content-Disposition": 'attachment; filename="compressed.pdf"',
            "X-Original-Size": str(len(data)),
            "X-Compressed-Size": str(len(compressed)),
        },
    )


# ─────────────────────────────────────────────
# PDF-02: MERGE PDFs
# ─────────────────────────────────────────────
@router.post("/merge")
async def merge_pdfs(
    files: List[UploadFile] = File(...),
    order: str = Form(""),  # comma-separated indices, e.g. "2,0,1"
):
    if len(files) < 2:
        raise HTTPException(400, "Need at least 2 PDF files to merge")
    
    # Build ordered list of files
    if order.strip():
        try:
            indices = [int(i) for i in order.split(",")]
            ordered_files = [files[i] for i in indices if 0 <= i < len(files)]
        except Exception:
            ordered_files = files
    else:
        ordered_files = files
    
    merged = fitz.open()
    for upload in ordered_files:
        data = await upload.read()
        doc = fitz.open(stream=data, filetype="pdf")
        merged.insert_pdf(doc)
        doc.close()
    buf = io.BytesIO()
    merged.save(buf, garbage=4, deflate=True)
    buf.seek(0)
    merged.close()
    return pdf_bytes_to_stream(buf.getvalue(), "merged.pdf")


# ─────────────────────────────────────────────
# PDF-03: SPLIT PDF
# ─────────────────────────────────────────────
@router.post("/split")
async def split_pdf(
    file: UploadFile = File(...),
    mode: str = Form("range"),      # range | every_n | pages
    page_range: str = Form(""),     # e.g. "1-5,7,9-12"
    every_n: int = Form(1),
    specific_pages: str = Form(""), # e.g. "1,3,5"
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    total = doc.page_count

    def parse_ranges(s: str, total: int):
        pages = set()
        for part in s.split(","):
            part = part.strip()
            if "-" in part:
                try:
                    a, b = part.split("-", 1)
                    a, b = int(a.strip()) - 1, int(b.strip()) - 1
                    pages.update(range(max(0, a), min(total, b + 1)))
                except ValueError:
                    pass
            elif part:
                try:
                    pages.add(int(part.strip()) - 1)
                except ValueError:
                    pass
        return sorted(p for p in pages if 0 <= p < total)

    zip_buf = io.BytesIO()
    added_any = False
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if mode == "range" and page_range:
            pages = parse_ranges(page_range, total)
            if not pages:
                doc.close()
                raise HTTPException(400, f"No valid pages found in range '{page_range}'. PDF has {total} page(s).")
            out = fitz.open()
            for p in pages:
                out.insert_pdf(doc, from_page=p, to_page=p)
            b = io.BytesIO()
            out.save(b)
            b.seek(0)
            zf.writestr("split_range.pdf", b.getvalue())
            out.close()
            added_any = True
        elif mode == "every_n":
            chunk = max(1, every_n)
            for i in range(0, total, chunk):
                out = fitz.open()
                out.insert_pdf(doc, from_page=i, to_page=min(i + chunk - 1, total - 1))
                b = io.BytesIO()
                out.save(b)
                b.seek(0)
                zf.writestr(f"part_{i//chunk + 1}.pdf", b.getvalue())
                out.close()
                added_any = True
        elif mode == "pages" and specific_pages:
            pages = parse_ranges(specific_pages, total)
            if not pages:
                doc.close()
                raise HTTPException(400, f"No valid pages found in '{specific_pages}'. PDF has {total} page(s).")
            for p in pages:
                out = fitz.open()
                out.insert_pdf(doc, from_page=p, to_page=p)
                b = io.BytesIO()
                out.save(b)
                b.seek(0)
                zf.writestr(f"page_{p+1}.pdf", b.getvalue())
                out.close()
                added_any = True
        else:
            # Split each page individually
            for p in range(total):
                out = fitz.open()
                out.insert_pdf(doc, from_page=p, to_page=p)
                b = io.BytesIO()
                out.save(b)
                b.seek(0)
                zf.writestr(f"page_{p+1}.pdf", b.getvalue())
                out.close()
                added_any = True

    doc.close()

    if not added_any:
        raise HTTPException(400, f"Nothing to split. Check your settings. PDF has {total} page(s).")

    zip_buf.seek(0)
    return StreamingResponse(
        zip_buf,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="split_pages.zip"'},
    )




# ─────────────────────────────────────────────
# PDF-04: PDF TO IMAGE
# ─────────────────────────────────────────────
@router.post("/to-image")
async def pdf_to_image(
    file: UploadFile = File(...),
    dpi: int = Form(150),
    output_format: str = Form("jpeg"),
    pages: str = Form("all"),  # "all" or "1,2,3"
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    total = doc.page_count
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    fmt = output_format.lower()
    if fmt == "jpg":
        fmt = "jpeg"

    if pages == "all":
        page_list = list(range(total))
    else:
        page_list = [int(p.strip()) - 1 for p in pages.split(",") if p.strip().isdigit()]
        page_list = [p for p in page_list if 0 <= p < total]

    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p_idx in page_list:
            page = doc[p_idx]
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            b = io.BytesIO()
            if fmt == "jpeg":
                img.save(b, format="JPEG", quality=90)
                ext = "jpg"
            else:
                img.save(b, format="PNG")
                ext = "png"
            b.seek(0)
            zf.writestr(f"page_{p_idx+1}.{ext}", b.getvalue())

    doc.close()
    zip_buf.seek(0)
    return StreamingResponse(
        zip_buf,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="pdf_pages.zip"'},
    )


# ─────────────────────────────────────────────
# PDF-06: WATERMARK PDF
# ─────────────────────────────────────────────
@router.post("/watermark")
async def watermark_pdf(
    file: UploadFile = File(...),
    text: str = Form("CONFIDENTIAL"),
    opacity: float = Form(0.3),
    rotation: int = Form(45),
    font_size: int = Form(48),
    color: str = Form("#FF0000"),
    pages: str = Form("all"),
    x_pct: float = Form(-1),
    y_pct: float = Form(-1),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    total = doc.page_count

    if pages == "all":
        page_list = list(range(total))
    else:
        page_list = [int(p.strip()) - 1 for p in pages.split(",") if p.strip().isdigit()]
        page_list = [p for p in page_list if 0 <= p < total]

    hex_color = color.lstrip("#")
    r = int(hex_color[0:2], 16) / 255
    g = int(hex_color[2:4], 16) / 255
    b = int(hex_color[4:6], 16) / 255

    for p_idx in page_list:
        page = doc[p_idx]
        pw, ph = page.rect.width, page.rect.height
        
        if x_pct >= 0 and y_pct >= 0:
            cx = (x_pct / 100.0) * pw
            cy = (y_pct / 100.0) * ph
        else:
            cx, cy = pw / 2, ph / 2
            
        p = fitz.Point(cx - len(text) * font_size * 0.3, cy)
        page.insert_text(
            p,
            text,
            fontsize=font_size,
            morph=(p, fitz.Matrix(-rotation)),
            color=(r, g, b),
            fill_opacity=opacity,
            overlay=True,
        )

    buf = io.BytesIO()
    doc.save(buf, garbage=4, deflate=True)
    buf.seek(0)
    doc.close()
    return pdf_bytes_to_stream(buf.getvalue(), "watermarked.pdf")


# ─────────────────────────────────────────────
# PDF-X: REMOVE PDF WATERMARK (TEXT)
# ─────────────────────────────────────────────
@router.post("/remove-watermark")
async def remove_pdf_watermark(
    file: UploadFile = File(...),
    text: str = Form("CONFIDENTIAL"),
):
    try:
        data = await file.read()
        doc = fitz.open(stream=data, filetype="pdf")
        
        for page in doc:
            # Search for instances of the text (case-insensitive by default in PyMuPDF)
            text_instances = page.search_for(text)
            for inst in text_instances:
                # Add a redaction annotation over the found text, filled with white
                page.add_redact_annot(inst, fill=(1, 1, 1))
            
            # Apply all redactions on the page
            page.apply_redactions()
            
        buf = io.BytesIO()
        doc.save(buf, garbage=4, deflate=True)
        buf.seek(0)
        doc.close()
        return pdf_bytes_to_stream(buf.getvalue(), "unwatermarked.pdf")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to remove watermark: {str(e)}")


# ─────────────────────────────────────────────
# PDF-07: PASSWORD PROTECT PDF
# ─────────────────────────────────────────────
@router.post("/protect")
async def protect_pdf(
    file: UploadFile = File(...),
    user_password: str = Form(...),
    owner_password: str = Form(""),
    allow_printing: bool = Form(True),
    allow_copying: bool = Form(False),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    
    permissions = 0
    if allow_printing:
        permissions |= fitz.PDF_PERM_PRINT
    if allow_copying:
        permissions |= fitz.PDF_PERM_COPY

    owner_pw = owner_password if owner_password else user_password + "_owner"
    
    buf = io.BytesIO()
    doc.save(
        buf,
        encryption=fitz.PDF_ENCRYPT_AES_128,
        user_pw=user_password,
        owner_pw=owner_pw,
        permissions=permissions,
    )
    buf.seek(0)
    doc.close()
    return pdf_bytes_to_stream(buf.getvalue(), "protected.pdf")


# ─────────────────────────────────────────────
# PDF-08: ROTATE PDF
# ─────────────────────────────────────────────
@router.post("/rotate")
async def rotate_pdf(
    file: UploadFile = File(...),
    rotation: int = Form(90),   # 90, 180, 270
    pages: str = Form("all"),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    total = doc.page_count

    if pages == "all":
        page_list = list(range(total))
    else:
        page_list = [int(p.strip()) - 1 for p in pages.split(",") if p.strip().isdigit()]
        page_list = [p for p in page_list if 0 <= p < total]

    rotation = rotation % 360
    for p_idx in page_list:
        page = doc[p_idx]
        page.set_rotation((page.rotation + rotation) % 360)

    buf = io.BytesIO()
    doc.save(buf, garbage=4, deflate=True)
    buf.seek(0)
    doc.close()
    return pdf_bytes_to_stream(buf.getvalue(), "rotated.pdf")


# ─────────────────────────────────────────────
# PDF-09: UNLOCK PDF
# ─────────────────────────────────────────────
@router.post("/unlock")
async def unlock_pdf(
    file: UploadFile = File(...),
    password: str = Form(...),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    if doc.is_encrypted:
        if not doc.authenticate(password):
            doc.close()
            raise HTTPException(400, "Wrong password or cannot decrypt this PDF")
    buf = io.BytesIO()
    doc.save(buf, encryption=fitz.PDF_ENCRYPT_NONE, garbage=4, deflate=True)
    buf.seek(0)
    doc.close()
    return pdf_bytes_to_stream(buf.getvalue(), "unlocked.pdf")


# ─────────────────────────────────────────────
# PDF-NEW-01: PASSPORT PDF PRINTABLE FORMAT
# ─────────────────────────────────────────────
@router.post("/passport-pdf")
async def passport_pdf(
    file: UploadFile = File(...),
    standard: str = Form("india"),
    custom_width_mm: Optional[float] = Form(None),
    custom_height_mm: Optional[float] = Form(None),
    paper_size: str = Form("4r"),
    photos_count: int = Form(6),
    crop_marks: bool = Form(False),
    bg_color: str = Form("#FFFFFF"),
    include_instructions: bool = Form(False),
):
    from routers.new_image_tools import PASSPORT_STANDARDS, mm_to_px
    import cv2
    import numpy as np

    data = await file.read()
    try:
        img = Image.open(io.BytesIO(data)).convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid image file. Please upload a valid image (e.g., JPEG, PNG) to generate a Passport PDF.")

    std = PASSPORT_STANDARDS.get(standard.lower(), PASSPORT_STANDARDS["india"])
    if standard.lower() == "custom":
        w_mm = custom_width_mm or 35.0
        h_mm = custom_height_mm or 45.0
    else:
        w_mm = std["width_mm"]
        h_mm = std["height_mm"]
    dpi = 300

    photo_w_px = mm_to_px(w_mm, dpi)
    photo_h_px = mm_to_px(h_mm, dpi)

    # Face detection & crop
    cv_img = np.array(img)
    cv_bgr = cv2.cvtColor(cv_img, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2GRAY)
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))

    if len(faces) > 0:
        x, y, fw, fh = faces[0]
        pad = int(fh * 0.5)
        x1, y1 = max(0, x - pad), max(0, y - int(pad * 1.2))
        x2, y2 = min(img.width, x + fw + pad), min(img.height, y + fh + int(pad * 1.8))
        face_crop = img.crop((x1, y1, x2, y2))
    else:
        face_crop = img

    bg_r, bg_g, bg_b = hex_to_rgb(bg_color)
    bg_img = Image.new("RGB", (photo_w_px, photo_h_px), (bg_r, bg_g, bg_b))
    photo_resized = face_crop.resize((photo_w_px, photo_h_px), Image.LANCZOS)
    bg_img.paste(photo_resized)
    photo = bg_img

    paper = PAPER_SIZES_MM.get(paper_size.lower(), PAPER_SIZES_MM["4r"])
    pw_mm, ph_mm = paper
    gutter_mm = 2.0
    crop_mark_mm = 3.0

    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=(pw_mm * mm, ph_mm * mm))
    c.setPageSize((pw_mm * mm, ph_mm * mm))

    cols = max(1, int((pw_mm + gutter_mm) / (w_mm + gutter_mm)))
    rows = max(1, int((ph_mm + gutter_mm) / (h_mm + gutter_mm)))
    total_slots = cols * rows
    count = min(photos_count, total_slots)

    # Center the grid
    used_w = cols * w_mm + (cols - 1) * gutter_mm
    used_h = rows * h_mm + (rows - 1) * gutter_mm
    start_x_mm = (pw_mm - used_w) / 2
    start_y_mm = (ph_mm - used_h) / 2

    placed = 0
    photo_buf = io.BytesIO()
    photo.save(photo_buf, format="JPEG", quality=95, dpi=(dpi, dpi))
    photo_buf.seek(0)

    for row in range(rows):
        for col in range(cols):
            if placed >= count:
                break
            x = (start_x_mm + col * (w_mm + gutter_mm)) * mm
            y = (ph_mm - start_y_mm - (row + 1) * h_mm - row * gutter_mm) * mm
            photo_buf.seek(0)
            c.drawImage(ImageReader(photo_buf), x, y, w_mm * mm, h_mm * mm)

            if crop_marks:
                c.setStrokeColorRGB(0, 0, 0)
                c.setLineWidth(0.25)
                cm = crop_mark_mm * mm
                corners = [(x, y), (x + w_mm * mm, y), (x, y + h_mm * mm), (x + w_mm * mm, y + h_mm * mm)]
                for cx, cy in corners:
                    c.line(cx - cm, cy, cx - 1, cy)
                    c.line(cx + 1, cy, cx + cm, cy)
                    c.line(cx, cy - cm, cx, cy - 1)
                    c.line(cx, cy + 1, cx, cy + cm)
            placed += 1
        if placed >= count:
            break

    if include_instructions:
        c.showPage()
        c.setFont("Helvetica-Bold", 14)
        c.drawString(20 * mm, (ph_mm - 20) * mm, "Print Instructions")
        c.setFont("Helvetica", 11)
        instructions = [
            f"• Paper size: {paper_size.upper()}",
            f"• Photo size: {w_mm}mm × {h_mm}mm",
            "• Print at 100% scale (no scaling)",
            "• Use photo paper for best results",
            "• Minimum 300 DPI print quality",
        ]
        y_pos = (ph_mm - 40) * mm
        for line in instructions:
            c.drawString(20 * mm, y_pos, line)
            y_pos -= 8 * mm
        c.setFont("Helvetica-Oblique", 9)
        c.drawString(20 * mm, 20 * mm,
                     "DISCLAIMER: These photos may not meet official biometric standards. Please verify with official requirements.")

    c.save()
    buf.seek(0)
    return pdf_bytes_to_stream(buf.getvalue(), "passport_print.pdf")


# ─────────────────────────────────────────────
# PDF INFO
# ─────────────────────────────────────────────
@router.post("/info")
async def pdf_info(file: UploadFile = File(...)):
    data = await file.read()
    try:
        doc = fitz.open(stream=data, filetype="pdf")
        info = {
            "filename": file.filename,
            "page_count": doc.page_count,
            "is_encrypted": doc.is_encrypted,
            "size_bytes": len(data),
            "size_kb": round(len(data) / 1024, 1),
            "size_mb": round(len(data) / (1024 * 1024), 2),
            "metadata": doc.metadata,
        }
        doc.close()
        return JSONResponse(info)
    except Exception as e:
        raise HTTPException(400, f"Invalid PDF: {str(e)}")


# ─────────────────────────────────────────────
# PDF-NEW-02: MICRO PDF (N-up page layout)
# ─────────────────────────────────────────────
@router.post("/micro-pdf")
async def micro_pdf(
    file: UploadFile = File(...),
    pages_per_sheet: int = Form(6),   # 6, 9, 12, 15
    page_size: str = Form("a4"),       # a4 | letter
    orientation: str = Form("portrait"),
):
    data = await file.read()
    doc = fitz.open(stream=data, filetype="pdf")
    total = doc.page_count

    # Determine grid layout
    grid_map = {6: (2, 3), 9: (3, 3), 12: (3, 4), 15: (3, 5)}
    cols, rows = grid_map.get(pages_per_sheet, (2, 3))

    paper_mm = {"a4": (210.0, 297.0), "letter": (215.9, 279.4)}
    pw_mm, ph_mm = paper_mm.get(page_size.lower(), (210.0, 297.0))
    if orientation == "landscape":
        pw_mm, ph_mm = ph_mm, pw_mm

    # Convert to points (1mm = 2.8346 pt)
    pt_per_mm = 2.8346
    pw_pt = pw_mm * pt_per_mm
    ph_pt = ph_mm * pt_per_mm

    cell_w = pw_pt / cols
    cell_h = ph_pt / rows

    out = fitz.open()
    page_idx = 0
    while page_idx < total:
        out_page = out.new_page(width=pw_pt, height=ph_pt)
        for row in range(rows):
            for col in range(cols):
                if page_idx >= total:
                    break
                src_page = doc[page_idx]
                dest_rect = fitz.Rect(
                    col * cell_w,
                    row * cell_h,
                    (col + 1) * cell_w,
                    (row + 1) * cell_h,
                )
                out_page.show_pdf_page(dest_rect, doc, page_idx)
                page_idx += 1

    buf = io.BytesIO()
    out.save(buf, garbage=4, deflate=True)
    buf.seek(0)
    doc.close()
    out.close()
    return pdf_bytes_to_stream(buf.getvalue(), "micro_pdf.pdf")


# ─────────────────────────────────────────────
# PDF-NEW-03: PDF TO DOCX CONVERTER
# ─────────────────────────────────────────────
@router.post("/pdf-to-docx")
async def pdf_to_docx(file: UploadFile = File(...)):
    data = await file.read()
    
    import uuid
    import tempfile
    
    temp_dir = tempfile.gettempdir()
    unique_id = str(uuid.uuid4())
    pdf_path = os.path.join(temp_dir, f"{unique_id}.pdf")
    docx_path = os.path.join(temp_dir, f"{unique_id}.docx")
    
    try:
        with open(pdf_path, "wb") as f:
            f.write(data)
            
        from pdf2docx import Converter
        cv = Converter(pdf_path)
        cv.convert(docx_path, start=0, end=None)
        cv.close()
        
        with open(docx_path, "rb") as f:
            docx_data = f.read()
            
        return StreamingResponse(
            io.BytesIO(docx_data),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={
                "Content-Disposition": 'attachment; filename="converted.docx"',
                "X-Original-Size": str(len(data)),
                "X-Compressed-Size": str(len(docx_data)),
            },
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF to Docx conversion failed: {str(e)}")
    finally:
        if os.path.exists(pdf_path):
            os.remove(pdf_path)
        if os.path.exists(docx_path):
            os.remove(docx_path)


# ─────────────────────────────────────────────
# PDF-NEW-04: DOCX TO PDF CONVERTER
# ─────────────────────────────────────────────
@router.post("/docx-to-pdf")
async def docx_to_pdf(file: UploadFile = File(...)):
    data = await file.read()
    import uuid
    import tempfile
    import subprocess
    
    temp_dir = tempfile.gettempdir()
    unique_id = str(uuid.uuid4())
    docx_path = os.path.join(temp_dir, f"{unique_id}.docx")
    
    try:
        with open(docx_path, "wb") as f:
            f.write(data)
            
        # Run LibreOffice conversion
        cmd = [
            "libreoffice",
            "--headless",
            "--convert-to",
            "pdf",
            "--outdir",
            temp_dir,
            docx_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            raise HTTPException(status_code=500, detail=f"LibreOffice conversion failed: {result.stderr}")
            
        pdf_path = os.path.join(temp_dir, f"{unique_id}.pdf")
        if not os.path.exists(pdf_path):
            raise HTTPException(status_code=500, detail="Converted PDF file not found")
            
        with open(pdf_path, "rb") as f:
            pdf_data = f.read()
            
        return StreamingResponse(
            io.BytesIO(pdf_data),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="converted.pdf"'},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Docx to PDF conversion failed: {str(e)}")
    finally:
        if os.path.exists(docx_path):
            os.remove(docx_path)
        pdf_path = os.path.join(temp_dir, f"{unique_id}.pdf")
        if os.path.exists(pdf_path):
            os.remove(pdf_path)


# ─────────────────────────────────────────────
# PDF-NEW-05: SIGN PDF WITH IMAGE
# ─────────────────────────────────────────────
@router.post("/sign-pdf")
async def sign_pdf(
    file: UploadFile = File(...),
    signature: UploadFile = File(...),
    page_number: int = Form(0),
    rotation: int = Form(0),
    x_pct: float = Form(...),
    y_pct: float = Form(...),
    w_pct: float = Form(...),
    h_pct: float = Form(...),
):
    try:
        pdf_data = await file.read()
        sig_data = await signature.read()
        
        if rotation != 0:
            sig_img = Image.open(io.BytesIO(sig_data))
            # Negative rotation because CSS transform: rotate(deg) is clockwise,
            # and Pillow's rotate is counter-clockwise.
            sig_img = sig_img.rotate(-rotation, expand=True, resample=Image.BICUBIC)
            b = io.BytesIO()
            sig_img.save(b, format="PNG")
            sig_data = b.getvalue()
            
        doc = fitz.open(stream=pdf_data, filetype="pdf")
        if page_number < 0 or page_number >= len(doc):
            doc.close()
            raise HTTPException(status_code=400, detail="Invalid page number")
            
        page = doc[page_number]
        pw, ph = page.rect.width, page.rect.height
        
        # Calculate absolute coordinates
        x1 = (x_pct / 100.0) * pw
        y1 = (y_pct / 100.0) * ph
        x2 = ((x_pct + w_pct) / 100.0) * pw
        y2 = ((y_pct + h_pct) / 100.0) * ph
        
        rect = fitz.Rect(x1, y1, x2, y2)
        
        # Insert the signature image
        page.insert_image(rect, stream=sig_data)
        
        buf = io.BytesIO()
        doc.save(buf, garbage=4, deflate=True)
        buf.seek(0)
        doc.close()
        
        return StreamingResponse(
            buf,
            media_type="application/pdf",
            headers={"Content-Disposition": 'attachment; filename="signed.pdf"'},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to sign PDF: {str(e)}")

