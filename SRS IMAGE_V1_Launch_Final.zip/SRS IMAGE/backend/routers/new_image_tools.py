"""
New Image Tools Router - Image to PDF, BG Color Changer, Passport Photo Generator
"""
from PIL import ImageFilter
import io
import os
import re
import zipfile
from typing import List, Optional

import cv2
import numpy as np
from PIL import Image, ImageDraw
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from reportlab.lib.pagesizes import A4, letter, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as rl_canvas

router = APIRouter()


PASSPORT_STANDARDS = {
    "india":   {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#FFFFFF", "name": "India Passport"},
    "usa":     {"width_mm": 51, "height_mm": 51, "dpi": 300, "bg": "#FFFFFF", "name": "USA Passport"},
    "uk":      {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#F0EDE8", "name": "UK Passport"},
    "eu":      {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#FFFFFF", "name": "EU/Schengen"},
    "uae":     {"width_mm": 40, "height_mm": 60, "dpi": 300, "bg": "#FFFFFF", "name": "UAE/Gulf"},
    "custom":  {"width_mm": None, "height_mm": None, "dpi": 300, "bg": "#FFFFFF", "name": "Custom"},
}

PAPER_SIZES = {
    "4r":  (101.6, 152.4),   # 4×6 inches in mm
    "a4":  (210.0, 297.0),
    "letter": (215.9, 279.4),
}


def mm_to_px(mm_val: float, dpi: int = 300) -> int:
    return int(mm_val * dpi / 25.4)


def hex_to_rgb(hex_color: str):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


# ─────────────────────────────────────────────
# 13. IMAGE TO PDF CONVERTER
# ─────────────────────────────────────────────
@router.post("/image-to-pdf")
async def image_to_pdf(
    files: List[UploadFile] = File(...),
    page_size: str = Form("a4"),
    orientation: str = Form("auto"),
    margin_mm: float = Form(5.0),
):
    if not files:
        raise HTTPException(400, "No files uploaded")

    buf = io.BytesIO()
    page_sizes = {
        "a4": A4, "letter": letter,
        "a3": (841.89, 1190.55), "a5": (419.53, 595.28),
    }
    base_size = page_sizes.get(page_size.lower(), A4)

    c = rl_canvas.Canvas(buf, pagesize=base_size)

    for upload in files:
        data = await upload.read()
        img = Image.open(io.BytesIO(data))
        if img.mode in ("RGBA", "LA", "P"):
            bg = Image.new("RGB", img.size, (255, 255, 255))
            if img.mode == "P":
                img = img.convert("RGBA")
            bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
            img = bg
        else:
            img = img.convert("RGB")

        iw, ih = img.size
        # Determine orientation
        if orientation == "landscape" or (orientation == "auto" and iw > ih):
            pw, ph = max(base_size), min(base_size)
        else:
            pw, ph = min(base_size), max(base_size)

        c.setPageSize((pw, ph))
        margin = margin_mm * mm
        avail_w = pw - 2 * margin
        avail_h = ph - 2 * margin
        ratio = min(avail_w / iw, avail_h / ih)
        draw_w, draw_h = iw * ratio, ih * ratio
        x = margin + (avail_w - draw_w) / 2
        y = margin + (avail_h - draw_h) / 2

        img_buf = io.BytesIO()
        img.save(img_buf, format="JPEG", quality=90)
        img_buf.seek(0)
        from reportlab.lib.utils import ImageReader
        c.drawImage(ImageReader(img_buf), x, y, draw_w, draw_h)
        c.showPage()

    c.save()
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/pdf",
        headers={"Content-Disposition": 'attachment; filename="images.pdf"'},
    )


# ─────────────────────────────────────────────
# 14. BACKGROUND COLOR CHANGER
# ─────────────────────────────────────────────
@router.post("/change-bg-color")
async def change_bg_color(
    file: UploadFile = File(...),
    new_color: str = Form("#FFFFFF"),
    feather: int = Form(0),
    output_format: str = Form("png"),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "png"

    # Parse target color
    color_str = new_color.strip().lstrip("#")
    if not re.match(r'^[0-9a-fA-F]{6}$', color_str):
        raise HTTPException(400, "Invalid hex color")
    r, g, b = hex_to_rgb(new_color)

    if img.mode == "RGBA" or (ext == "png" and img.mode in ("RGBA", "LA", "P")):
        # PNG: fill transparent areas with new color
        img = img.convert("RGBA")
        background = Image.new("RGBA", img.size, (r, g, b, 255))
        if new_color.upper() in ("#00000000", "TRANSPARENT"):
            result = img
        else:
            background.paste(img, mask=img.split()[3])
            result = background
        if output_format.lower() == "jpeg":
            result = result.convert("RGB")
            fmt = "JPEG"
            out_ext = "jpg"
        else:
            fmt = "PNG"
            out_ext = "png"
    else:
        # JPEG: use AI BG removal + recolor
        try:
            from rembg import remove
            removed = remove(data)
            img_no_bg = Image.open(io.BytesIO(removed)).convert("RGBA")
        except Exception:
            img_no_bg = img.convert("RGBA")

        if feather > 0:
            # Simple feathering by applying slight blur to alpha channel
            r_ch, g_ch, b_ch, alpha = img_no_bg.split()
            alpha = alpha.filter(ImageFilter.GaussianBlur(feather))
            img_no_bg = Image.merge("RGBA", (r_ch, g_ch, b_ch, alpha))

        background = Image.new("RGBA", img_no_bg.size, (r, g, b, 255))
        background.paste(img_no_bg, mask=img_no_bg.split()[3])

        if output_format.lower() in ("jpeg", "jpg"):
            result = background.convert("RGB")
            fmt = "JPEG"
            out_ext = "jpg"
        else:
            result = background
            fmt = "PNG"
            out_ext = "png"

    buf = io.BytesIO()
    result.save(buf, format=fmt, quality=90)
    buf.seek(0)
    mime = "image/png" if fmt == "PNG" else "image/jpeg"
    return StreamingResponse(
        buf,
        media_type=mime,
        headers={"Content-Disposition": f'attachment; filename="bg_changed.{out_ext}"'},
    )


def draw_dotted_v_line(draw, x, y1, y2, color="#888888", step=4):
    for y in range(y1, y2, step):
        draw.line([(x, y), (x, min(y + step // 2, y2))], fill=color, width=1)


def draw_dotted_h_line(draw, x1, x2, y, color="#888888", step=4):
    for x in range(x1, x2, step):
        draw.line([(x, y), (min(x + step // 2, x2), y)], fill=color, width=1)


# ─────────────────────────────────────────────
# 15. PASSPORT SIZE PHOTO GENERATOR
# ─────────────────────────────────────────────
@router.post("/passport-photo")
async def generate_passport_photo(
    file: UploadFile = File(...),
    standard: str = Form("india"),
    custom_width_mm: Optional[float] = Form(None),
    custom_height_mm: Optional[float] = Form(None),
    custom_dpi: Optional[int] = Form(None),
    custom_size: Optional[str] = Form(""),
    bg_color: str = Form("#FFFFFF"),
    photos_per_sheet: int = Form(6),
    paper_size: str = Form("4r"),
    paper_orientation: str = Form("portrait"),
    output_type: str = Form("jpeg"),  # jpeg or pdf
    brightness: float = Form(1.0),
    contrast: float = Form(1.0),
    sharpness: float = Form(1.0),
    cutline: bool = Form(False),
):
    data = await file.read()
    img = Image.open(io.BytesIO(data))

    std = PASSPORT_STANDARDS.get(standard.lower(), PASSPORT_STANDARDS["india"])
    if custom_size and custom_size.strip():
        match = re.match(r"([\d\.]+)\s*[\*xX\s]\s*([\d\.]+)", custom_size.strip())
        if match:
            # assumed centimeters, convert to mm
            w_mm = float(match.group(1)) * 10
            h_mm = float(match.group(2)) * 10
            dpi = 300
        else:
            raise HTTPException(400, "Invalid custom size format. Please use format like '4*3' or '4.5*3.5'")
    elif standard.lower() == "custom":
        if not custom_width_mm or not custom_height_mm:
            raise HTTPException(400, "Custom standard requires width and height")
        w_mm = custom_width_mm
        h_mm = custom_height_mm
        dpi = custom_dpi or 300
    else:
        w_mm = std["width_mm"]
        h_mm = std["height_mm"]
        dpi = std["dpi"]

    photo_w_px = mm_to_px(w_mm, dpi)
    photo_h_px = mm_to_px(h_mm, dpi)

    # Detect and center face
    img_rgb = img.convert("RGB")
    cv_img = np.array(img_rgb)
    cv_img_bgr = cv2.cvtColor(cv_img, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(cv_img_bgr, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(30, 30))

    if len(faces) > 0:
        x, y, fw, fh = faces[0]
        # Add padding around face (50% of face size)
        pad = int(fh * 0.5)
        x1 = max(0, x - pad)
        y1 = max(0, y - int(pad * 1.2))
        x2 = min(img_rgb.width, x + fw + pad)
        y2 = min(img_rgb.height, y + fh + int(pad * 1.8))
        face_region = img_rgb.crop((x1, y1, x2, y2))
    else:
        # No face detected - use center crop
        cw, ch = img_rgb.size
        aspect = photo_w_px / photo_h_px
        if cw / ch > aspect:
            new_w = int(ch * aspect)
            face_region = img_rgb.crop(((cw - new_w) // 2, 0, (cw + new_w) // 2, ch))
        else:
            new_h = int(cw / aspect)
            face_region = img_rgb.crop((0, (ch - new_h) // 2, cw, (ch + new_h) // 2))

    # Apply enhancements
    from PIL import ImageEnhance as IE
    face_region = IE.Brightness(face_region).enhance(brightness)
    face_region = IE.Contrast(face_region).enhance(contrast)
    face_region = IE.Sharpness(face_region).enhance(sharpness)

    # Resize to passport dimensions
    photo = face_region.resize((photo_w_px, photo_h_px), Image.LANCZOS)

    # Apply background color
    bg_r, bg_g, bg_b = hex_to_rgb(bg_color)
    bg_img = Image.new("RGB", (photo_w_px, photo_h_px), (bg_r, bg_g, bg_b))
    bg_img.paste(photo)
    
    # Draw thin black border around each passport photo
    draw = ImageDraw.Draw(bg_img)
    draw.rectangle([0, 0, photo_w_px - 1, photo_h_px - 1], outline="black", width=2)

    photo = bg_img

    # Build printable sheet
    paper = PAPER_SIZES.get(paper_size.lower(), PAPER_SIZES["4r"])
    if paper_orientation.lower() == "landscape":
        paper = (paper[1], paper[0])
        
    sheet_w_px = mm_to_px(paper[0], dpi)
    sheet_h_px = mm_to_px(paper[1], dpi)
    gutter_px = mm_to_px(2, dpi)  # 2mm gutter

    sheet = Image.new("RGB", (sheet_w_px, sheet_h_px), (255, 255, 255))

    cols = max(1, (sheet_w_px + gutter_px) // (photo_w_px + gutter_px))
    rows = max(1, (sheet_h_px + gutter_px) // (photo_h_px + gutter_px))
    total = min(photos_per_sheet, cols * rows)

    placed = 0
    for row in range(rows):
        for col in range(cols):
            if placed >= total:
                break
            px = gutter_px + col * (photo_w_px + gutter_px)
            py = gutter_px + row * (photo_h_px + gutter_px)
            sheet.paste(photo, (px, py))
            placed += 1
        if placed >= total:
            break

    # Draw dotted cutlines in the middle of each gutter/margin
    if cutline:
        sheet_draw = ImageDraw.Draw(sheet)
        half_gutter = gutter_px // 2
        placed = 0
        for row in range(rows):
            for col in range(cols):
                if placed >= total:
                    break
                px = gutter_px + col * (photo_w_px + gutter_px)
                py = gutter_px + row * (photo_h_px + gutter_px)
                
                # Left cutline
                draw_dotted_v_line(sheet_draw, px - half_gutter, py, py + photo_h_px)
                # Right cutline
                draw_dotted_v_line(sheet_draw, px + photo_w_px + half_gutter, py, py + photo_h_px)
                # Top cutline
                draw_dotted_h_line(sheet_draw, px, px + photo_w_px, py - half_gutter)
                # Bottom cutline
                draw_dotted_h_line(sheet_draw, px, px + photo_w_px, py + photo_h_px + half_gutter)
                
                placed += 1

    if output_type.lower() == "pdf":
        buf = io.BytesIO()
        paper_mm = paper
        c = rl_canvas.Canvas(buf, pagesize=(paper_mm[0] * mm, paper_mm[1] * mm))
        img_buf = io.BytesIO()
        sheet.save(img_buf, format="JPEG", quality=95)
        img_buf.seek(0)
        from reportlab.lib.utils import ImageReader
        c.drawImage(ImageReader(img_buf), 0, 0, paper_mm[0] * mm, paper_mm[1] * mm)
        c.save()
        buf.seek(0)
        return StreamingResponse(buf, media_type="application/pdf",
                                 headers={"Content-Disposition": 'attachment; filename="passport_sheet.pdf"'})
    else:
        buf = io.BytesIO()
        sheet.save(buf, format="JPEG", quality=95, dpi=(dpi, dpi))
        buf.seek(0)
        return StreamingResponse(buf, media_type="image/jpeg",
                                 headers={"Content-Disposition": 'attachment; filename="passport_sheet.jpg"'})


@router.get("/passport-standards")
def get_passport_standards():
    return JSONResponse(PASSPORT_STANDARDS)
