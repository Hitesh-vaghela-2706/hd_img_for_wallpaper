import io
from fastapi.responses import StreamingResponse

def pdf_bytes_to_stream(data: bytes, filename: str = "output.pdf") -> StreamingResponse:
    """Returns a FastAPI StreamingResponse for PDF bytes."""
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
