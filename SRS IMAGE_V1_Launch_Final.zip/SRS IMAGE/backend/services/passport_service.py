PASSPORT_STANDARDS = {
    "india":   {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#FFFFFF", "name": "India Passport"},
    "usa":     {"width_mm": 51, "height_mm": 51, "dpi": 300, "bg": "#FFFFFF", "name": "USA Passport"},
    "uk":      {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#F0EDE8", "name": "UK Passport"},
    "eu":      {"width_mm": 35, "height_mm": 45, "dpi": 300, "bg": "#FFFFFF", "name": "EU/Schengen"},
    "uae":     {"width_mm": 40, "height_mm": 60, "dpi": 300, "bg": "#FFFFFF", "name": "UAE/Gulf"},
    "custom":  {"width_mm": None, "height_mm": None, "dpi": 300, "bg": "#FFFFFF", "name": "Custom"},
}

PAPER_SIZES_MM = {
    "4r":  (101.6, 152.4),   # 4×6 inches in mm
    "a4":  (210.0, 297.0),
    "letter": (215.9, 279.4),
}

def mm_to_px(mm_val: float, dpi: int = 300) -> int:
    return int(mm_val * dpi / 25.4)

def hex_to_rgb(hex_color: str):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
