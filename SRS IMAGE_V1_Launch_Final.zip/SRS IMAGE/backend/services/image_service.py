import io
from PIL import Image

def pil_to_bytes(img: Image.Image, fmt: str = "JPEG", quality: int = 85) -> bytes:
    """Convert PIL Image to bytes."""
    buf = io.BytesIO()
    fmt = fmt.upper()
    if fmt == "JPG":
        fmt = "JPEG"
    if fmt == "JPEG" and img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGB")
    save_kwargs = {}
    if fmt == "JPEG":
        save_kwargs["quality"] = quality
        save_kwargs["optimize"] = True
    elif fmt == "PNG":
        save_kwargs["optimize"] = True
    elif fmt == "WEBP":
        save_kwargs["quality"] = quality
    img.save(buf, format=fmt, **save_kwargs)
    buf.seek(0)
    return buf.read()

def get_mime_type(ext: str) -> str:
    MIME_MAP = {
        "jpeg": "image/jpeg", "jpg": "image/jpeg",
        "png": "image/png", "webp": "image/webp",
        "gif": "image/gif", "bmp": "image/bmp",
        "tiff": "image/tiff", "tif": "image/tiff",
    }
    return MIME_MAP.get(ext.lower(), "image/jpeg")
