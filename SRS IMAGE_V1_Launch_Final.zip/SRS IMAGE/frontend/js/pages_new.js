'use strict';
// Wait, GenericToolPage isn't exported from pages_image. I should just define it or copy it.
// Actually, I can just use a similar implementation or assume they are combined in pages.js.
// Since babel runs these sequentially, I will just redefine a simple one for PDF.

const { useState } = React;
const C = window.Components;

window.GenPage = function ({ title, endpoint, fileLimit = 1, options = [], requireFile = true, disableLivePreview = false }) {
  const [files, setFiles] = useState([]);
  const [opts, setOpts] = useState({});
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  React.useEffect(() => {
    if (disableLivePreview) return;
    if (requireFile && files.length > 0 && options.length > 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const fd = new FormData();
        files.forEach(f => fd.append(fileLimit > 1 ? 'files' : 'file', f));
        Object.keys(opts).forEach(k => fd.append(k, opts[k]));
        try {
          const res = await fetch('/api' + endpoint, { method: 'POST', body: fd });
          if (res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if (old) URL.revokeObjectURL(old); return url; });
          }
        } catch (e) { }
      }, 500);
    }
  }, [opts, files]);

  React.useEffect(() => {
    return () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }
  }, [previewUrl]);

  const handleRun = () => {
    if (requireFile && !files.length) return;
    const fd = new FormData();
    files.forEach(f => fd.append(fileLimit > 1 ? 'files' : 'file', f));
    Object.keys(opts).forEach(k => fd.append(k, opts[k]));
    process(endpoint, fd);
  };

  const isPdf = (files.length > 0 && files[0].type === 'application/pdf') || (previewUrl && endpoint.includes('pdf'));
  // docx-to-pdf always produces a PDF; handle it explicitly before the generic isPdf check
  const defaultExt = endpoint.includes('docx-to-pdf')
    ? '.pdf'
    : endpoint.includes('to-docx')
      ? '.docx'
      : (endpoint.includes('to-image') || endpoint.includes('split'))
        ? '.zip'
        : (isPdf ? '.pdf' : '');

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">{title}</h2>
      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div className="tool-card" style={{ flex: '1 1 350px', margin: 0 }}>
          {requireFile && <C.DropZone multiple={fileLimit > 1} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setFiles(f.slice(0, fileLimit));
          }} />}
          {requireFile && <C.FileList files={files} onRemove={i => setFiles(fs => fs.filter((_, j) => i !== j))} />}

          {(!requireFile || files.length > 0) && options.length > 0 && (
            <div className="controls-grid" style={{ marginTop: 20 }}>
              {options.map(opt => (
                <C.FormGroup key={opt.key} label={opt.label}>
                  {opt.type === 'select' ? (
                    <select className="form-select" value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} onChange={e => setOpts({ ...opts, [opt.key]: e.target.value })}>
                      {opt.choices.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                  ) : opt.type === 'number' ? (
                    <input type="number" className="form-input" value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} onChange={e => setOpts({ ...opts, [opt.key]: e.target.value })} />
                  ) : opt.type === 'text' ? (
                    <input type="text" className="form-input" value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} onChange={e => setOpts({ ...opts, [opt.key]: e.target.value })} />
                  ) : opt.type === 'color' ? (
                    <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                      <input type="color" className="form-color" value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} onChange={e => setOpts({ ...opts, [opt.key]: e.target.value })} style={{ width: 50, height: 40, padding: 0, cursor: 'pointer' }} />
                      <input type="text" className="form-input" value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} onChange={e => setOpts({ ...opts, [opt.key]: e.target.value })} style={{ flex: 1 }} />
                    </div>
                  ) : opt.type === 'slider' ? (
                    <C.Slider value={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} min={opt.min} max={opt.max} onChange={v => setOpts({ ...opts, [opt.key]: v })} displayValue={opts[opt.key] !== undefined ? opts[opt.key] : opt.default} />
                  ) : null}
                </C.FormGroup>
              ))}
            </div>
          )}

          <div className="action-row" style={{ marginTop: 20 }}>
            <button className="btn btn-primary" onClick={handleRun} disabled={requireFile && !files.length}>Process & Download</button>
          </div>

          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}

          {resultUrl && (
            <div style={{ marginTop: 24, textAlign: 'center' }}>
              <h3 style={{ marginBottom: 15 }}>Success!</h3>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename(title, files, defaultExt)} />
                <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); setOpts({}); setPreviewUrl(''); }}>Process Another</button>
              </div>
            </div>
          )}
        </div>

        {requireFile && files.length > 0 && (
          <div className="tool-card" style={{ flex: '2 1 400px', margin: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <h3 style={{ marginBottom: 15 }}>Live Preview</h3>
            {/* After conversion: show resultUrl as PDF for docx-to-pdf; otherwise live preview */}
            {resultUrl && endpoint.includes('docx-to-pdf') ? (
              <iframe src={resultUrl} width="100%" height="600px" style={{ border: '1px solid #ccc', borderRadius: 8 }} />
            ) : isPdf ? (
              <iframe src={previewUrl || URL.createObjectURL(files[0])} width="100%" height="600px" style={{ border: '1px solid #ccc', borderRadius: 8 }} />
            ) : (
              <img src={previewUrl || URL.createObjectURL(files[0])} style={{ maxWidth: '100%', maxHeight: '600px', objectFit: 'contain', borderRadius: 8 }} onLoad={e => URL.revokeObjectURL(e.target.src)} />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ── DOCX TO PDF — with live PDF preview on upload ──────────
window.DocxToPdfPage = function () {
  const [file, setFile] = useState(null);
  const [previewPdfUrl, setPreviewPdfUrl] = useState('');
  const [converting, setConverting] = useState(false);
  const [previewError, setPreviewError] = useState('');
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  React.useEffect(() => {
    return () => { if (previewPdfUrl) URL.revokeObjectURL(previewPdfUrl); };
  }, [previewPdfUrl]);

  const handleFile = async (f) => {
    reset();
    setFile(f);
    setPreviewError('');
    if (previewPdfUrl) URL.revokeObjectURL(previewPdfUrl);
    setPreviewPdfUrl('');
    setConverting(true);
    try {
      const fd = new FormData();
      fd.append('file', f);
      const res = await fetch('/api/pdf/docx-to-pdf', { method: 'POST', body: fd });
      if (res.ok) {
        const blob = await res.blob();
        setPreviewPdfUrl(URL.createObjectURL(blob));
      } else {
        setPreviewError('Preview generation failed. You can still click Process & Download.');
      }
    } catch (e) {
      setPreviewError('Preview generation failed. You can still click Process & Download.');
    } finally {
      setConverting(false);
    }
  };

  const handleRun = () => {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    process('/pdf/docx-to-pdf', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Docx to PDF</h2>
      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        {/* Left: controls */}
        <div className="tool-card" style={{ flex: '1 1 350px', margin: 0 }}>
          <C.DropZone multiple={false} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            if (f[0]) handleFile(f[0]);
          }} />
          {file && <C.FileList files={[file]} onRemove={() => { setFile(null); reset(); if (previewPdfUrl) URL.revokeObjectURL(previewPdfUrl); setPreviewPdfUrl(''); }} />}

          <div className="action-row" style={{ marginTop: 20 }}>
            <button className="btn btn-primary" onClick={handleRun} disabled={!file || loading || converting}>Process &amp; Download</button>
          </div>

          {(loading || converting) && <C.Progress value={converting ? 30 : progress} />}
          {previewError && <C.Alert type="warning">{previewError}</C.Alert>}
          {error && <C.Alert type="error">{error}</C.Alert>}

          {resultUrl && (
            <div style={{ marginTop: 24, textAlign: 'center' }}>
              <h3 style={{ marginBottom: 15 }}>✅ Success!</h3>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename('Docx_to_PDF', [file], '.pdf')} />
                <button className="btn btn-outline" onClick={() => { reset(); setFile(null); if (previewPdfUrl) URL.revokeObjectURL(previewPdfUrl); setPreviewPdfUrl(''); }}>Convert Another</button>
              </div>
            </div>
          )}
        </div>

        {/* Right: live PDF preview */}
        {file && (
          <div className="tool-card" style={{ flex: '2 1 400px', margin: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400 }}>
            <h3 style={{ marginBottom: 15 }}>Live Preview</h3>
            {converting ? (
              <div style={{ textAlign: 'center', padding: 40 }}>
                <div style={{ width: 48, height: 48, border: '4px solid var(--accent)', borderTop: '4px solid transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 16px' }}></div>
                <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Converting DOCX → PDF for preview…</p>
              </div>
            ) : (resultUrl || previewPdfUrl) ? (
              <iframe
                src={resultUrl || previewPdfUrl}
                width="100%"
                height="600px"
                style={{ border: '1px solid #ccc', borderRadius: 8 }}
              />
            ) : (
              <div style={{ textAlign: 'center', padding: 40, opacity: 0.6 }}>
                <div style={{ fontSize: 72 }}>📄</div>
                <h4 style={{ margin: '16px 0 8px' }}>{file.name}</h4>
                <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{(file.size / 1024).toFixed(1)} KB · Word Document</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ── SPLIT PDF — button-only, no auto-trigger ────────────
window.SplitPdfPage = function () {
  const [file, setFile] = useState(null);
  const [mode, setMode] = useState('range');
  const [pageRange, setPageRange] = useState('');
  const [everyN, setEveryN] = useState(1);
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  const handleRun = () => {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    fd.append('mode', mode);
    fd.append('page_range', pageRange);
    fd.append('every_n', everyN);
    fd.append('specific_pages', pageRange);
    process('/pdf/split', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Split PDF</h2>
      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div className="tool-card" style={{ flex: '1 1 350px', margin: 0 }}>
          <C.DropZone multiple={false} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            setFile(f[0]); reset();
          }} />
          {file && (
            <div style={{ marginTop: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'var(--bg-card)', borderRadius: 8, marginBottom: 16 }}>
                <span>📄</span>
                <span style={{ flex: 1, fontSize: 13 }}>{file.name}</span>
                <button style={{ background: 'none', border: 'none', color: 'var(--danger,#e55)', cursor: 'pointer', fontSize: 16 }} onClick={() => { setFile(null); reset(); }}>✕</button>
              </div>
              <div className="controls-grid">
                <C.FormGroup label="Split Mode">
                  <select className="form-select" value={mode} onChange={e => setMode(e.target.value)}>
                    <option value="range">Page Range (e.g. 1-5, 7)</option>
                    <option value="every_n">Every N Pages</option>
                    <option value="pages">Specific Pages</option>
                    <option value="all">Every Page (individual files)</option>
                  </select>
                </C.FormGroup>
                {(mode === 'range' || mode === 'pages') && (
                  <C.FormGroup label={mode === 'range' ? 'Range (e.g. 1-3, 5-7)' : 'Pages (e.g. 1, 3, 5)'}>
                    <input type="text" className="form-input" value={pageRange} onChange={e => setPageRange(e.target.value)} placeholder={mode === 'range' ? '1-3, 5-7' : '1, 3, 5'} />
                  </C.FormGroup>
                )}
                {mode === 'every_n' && (
                  <C.FormGroup label="Pages per chunk">
                    <input type="number" className="form-input" value={everyN} min={1} onChange={e => setEveryN(e.target.value)} />
                  </C.FormGroup>
                )}
              </div>
              <div className="action-row" style={{ marginTop: 16 }}>
                <button className="btn btn-primary" onClick={handleRun} disabled={loading}>Split & Download ZIP</button>
              </div>
            </div>
          )}
          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}
          {resultUrl && (
            <div style={{ marginTop: 24, textAlign: 'center' }}>
              <h3 style={{ marginBottom: 15 }}>Success!</h3>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Split PDF", [file], ".zip")} />
                <button className="btn btn-outline" onClick={() => { reset(); setFile(null); setPageRange(''); setMode('range'); }}>Split Another</button>
              </div>
            </div>
          )}
        </div>
        {file && (
          <div className="tool-card" style={{ flex: '2 1 400px', margin: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <h3 style={{ marginBottom: 15 }}>PDF Preview</h3>
            <iframe src={URL.createObjectURL(file)} width="100%" height="600px" style={{ border: '1px solid #ccc', borderRadius: 8 }} />
          </div>
        )}
      </div>
    </div>
  );
};

// ── MERGE PDF with drag-to-reorder ──────────────────────
window.MergePdfPage = function () {
  const [files, setFiles] = useState([]);
  const [dragIdx, setDragIdx] = useState(null);
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  const onDragStart = (i) => setDragIdx(i);
  const onDragOver = (e, i) => { e.preventDefault(); if (dragIdx === null || dragIdx === i) return; const arr = [...files]; const [item] = arr.splice(dragIdx, 1); arr.splice(i, 0, item); setFiles(arr); setDragIdx(i); };
  const onDragEnd = () => setDragIdx(null);

  const handleRun = () => {
    if (files.length < 2) return;
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    fd.append('order', files.map((_, i) => i).join(','));
    process('/pdf/merge', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Merge PDF</h2>
      <div className="tool-card">
        <C.DropZone multiple={true} onFiles={f => {
          const sizeErr = C.validateFiles(f);
          if (sizeErr) { setError(sizeErr); return; }
          reset();
          setFiles(prev => [...prev, ...f]);
        }} />
        {files.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 8 }}>Drag rows to reorder. Files will merge in this order:</p>
            {files.map((f, i) => (
              <div key={i} draggable onDragStart={() => onDragStart(i)} onDragOver={e => onDragOver(e, i)} onDragEnd={onDragEnd}
                style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', marginBottom: 6, background: 'var(--bg-card)', borderRadius: 8, cursor: 'grab', border: dragIdx === i ? '2px solid var(--accent)' : '2px solid transparent' }}>
                <span style={{ fontSize: 18 }}>☰</span>
                <span style={{ flex: 1, fontSize: 13 }}>{i + 1}. {f.name}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{(f.size / 1024).toFixed(0)} KB</span>
                <button style={{ background: 'none', border: 'none', color: 'var(--danger,#e55)', cursor: 'pointer', fontSize: 16 }} onClick={() => setFiles(prev => prev.filter((_, j) => j !== i))}>✕</button>
              </div>
            ))}
            <div className="action-row" style={{ marginTop: 16 }}>
              <button className="btn btn-outline" style={{ marginRight: 10 }} onClick={() => { setFiles([]); reset(); }}>Clear All</button>
              <button className="btn btn-primary" onClick={handleRun} disabled={files.length < 2 || loading}>Merge & Download</button>
            </div>
          </div>
        )}
        {loading && <C.Progress value={progress} />}
        {error && <C.Alert type="error">{error}</C.Alert>}
        {resultUrl && (
          <div style={{ marginTop: 24, textAlign: 'center' }}>
            <h3 style={{ marginBottom: 15 }}>Success!</h3>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
              <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Merge PDF", files, ".pdf")} />
              <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); }}>Merge Another</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── PDF ROTATE with icon buttons ─────────────────────────
window.PdfRotatePage = function () {
  const [file, setFile] = useState(null);
  const [angle, setAngle] = useState(0);
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  const rotate = (deg) => setAngle(a => (a + deg + 360) % 360);

  const handleRun = () => {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    fd.append('rotation', angle || 90);
    process('/pdf/rotate', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Rotate PDF</h2>
      <div className="tool-card">
        <C.DropZone multiple={false} onFiles={f => {
          const sizeErr = C.validateFiles(f);
          if (sizeErr) { setError(sizeErr); return; }
          setFile(f[0]); reset(); setAngle(0);
        }} />
        {file && (
          <div style={{ marginTop: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'var(--bg-card)', borderRadius: 8, marginBottom: 16 }}>
              <span>📄</span><span style={{ flex: 1, fontSize: 13 }}>{file.name}</span>
              <button style={{ background: 'none', border: 'none', color: 'var(--danger,#e55)', cursor: 'pointer', fontSize: 16 }} onClick={() => { setFile(null); reset(); }}>✕</button>
            </div>
            <div style={{ display: 'flex', gap: 20, justifyContent: 'center', alignItems: 'center' }}>
              <button className="btn btn-outline" style={{ fontSize: 28, padding: '12px 24px' }} onClick={() => rotate(-90)}>↺</button>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{angle}°</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Current rotation</div>
              </div>
              <button className="btn btn-outline" style={{ fontSize: 28, padding: '12px 24px' }} onClick={() => rotate(90)}>↻</button>
            </div>
            <div className="action-row" style={{ marginTop: 20 }}>
              <button className="btn btn-primary" onClick={handleRun} disabled={loading}>Apply Rotation & Download</button>
            </div>
          </div>
        )}
        {loading && <C.Progress value={progress} />}
        {error && <C.Alert type="error">{error}</C.Alert>}
        {resultUrl && (
          <div style={{ marginTop: 24, textAlign: 'center' }}>
            <h3 style={{ marginBottom: 15 }}>Success!</h3>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
              <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Rotate PDF", [file], ".pdf")} />
              <button className="btn btn-outline" onClick={() => { reset(); setFile(null); setAngle(0); }}>Process Another</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

window.PassportPhotoPage = function () {
  const [files, setFiles] = useState([]);
  const [standard, setStandard] = useState('india');
  const [customWidth, setCustomWidth] = useState('3.5');
  const [customHeight, setCustomHeight] = useState('4.5');
  const [paperSize, setPaperSize] = useState('4r');
  const [paperOrientation, setPaperOrientation] = useState('landscape');
  const [photosPerSheet, setPhotosPerSheet] = useState(6);
  const [bgColor, setBgColor] = useState('#FFFFFF');
  const [cutline, setCutline] = useState(true);

  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  React.useEffect(() => {
    if (files.length > 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const fd = new FormData();
        fd.append('file', files[0]);
        fd.append('standard', standard);
        fd.append('paper_size', paperSize);
        fd.append('paper_orientation', paperOrientation);
        fd.append('photos_per_sheet', photosPerSheet);
        fd.append('bg_color', bgColor);
        fd.append('cutline', cutline ? 'true' : 'false');
        if (standard === 'custom') {
          fd.append('custom_width_mm', parseFloat(customWidth) * 10 || 35);
          fd.append('custom_height_mm', parseFloat(customHeight) * 10 || 45);
        }
        try {
          const res = await fetch('/api/new-image/passport-photo', { method: 'POST', body: fd });
          if (res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if (old) URL.revokeObjectURL(old); return url; });
          }
        } catch (e) { }
      }, 500);
    }
  }, [files, standard, customWidth, customHeight, paperSize, paperOrientation, photosPerSheet, bgColor, cutline]);

  React.useEffect(() => {
    return () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }
  }, [previewUrl]);

  const handleRun = () => {
    if (!files.length) return;
    const fd = new FormData();
    fd.append('file', files[0]);
    fd.append('standard', standard);
    fd.append('paper_size', paperSize);
    fd.append('paper_orientation', paperOrientation);
    fd.append('photos_per_sheet', photosPerSheet);
    fd.append('bg_color', bgColor);
    fd.append('cutline', cutline ? 'true' : 'false');
    if (standard === 'custom') {
      fd.append('custom_width_mm', parseFloat(customWidth) * 10 || 35);
      fd.append('custom_height_mm', parseFloat(customHeight) * 10 || 45);
    }
    process('/new-image/passport-photo', fd);
  };

  const handlePrint = () => {
    const url = resultUrl || previewUrl;
    if (!url) return;
    const win = window.open('');
    win.document.write(`
      <html>
        <head>
          <title>Print Passport Photo Sheet</title>
          <style>
            @page { size: auto; margin: 0mm; }
            body { margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #ffffff; }
            img { max-width: 100%; max-height: 100vh; object-fit: contain; }
            @media print {
              body { background: none; }
              img { max-width: 100%; max-height: 100%; }
            }
          </style>
        </head>
        <body onload="setTimeout(function(){ window.print(); window.close(); }, 500);">
          <img src="${url}" />
        </body>
      </html>
    `);
    win.document.close();
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Passport Photo Generator</h2>
      <p className="page-subtitle">Generate printable sheets of passport size photos with custom dimensions, orientation, and borders.</p>

      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <div className="tool-card" style={{ flex: '1 1 350px', margin: 0 }}>
          <C.DropZone multiple={false} accept="image/*" onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setFiles(f);
          }} />
          <C.FileList files={files} onRemove={() => { setFiles([]); reset(); setPreviewUrl(''); }} />

          {files.length > 0 && (
            <div className="controls-grid" style={{ marginTop: 20 }}>
              <C.FormGroup label="Standard Preset">
                <select className="form-select" value={standard} onChange={e => setStandard(e.target.value)}>
                  <option value="india">India (35x45 mm)</option>
                  <option value="usa">USA (2x2 inch)</option>
                  <option value="uk">UK (35x45 mm)</option>
                  <option value="eu">EU (35x45 mm)</option>
                  <option value="custom">Custom Size</option>
                </select>
              </C.FormGroup>

              {standard === 'custom' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <C.FormGroup label="Width (cm)">
                    <input
                      type="number"
                      className="form-input"
                      value={customWidth}
                      step="0.1"
                      onChange={e => setCustomWidth(e.target.value)}
                    />
                  </C.FormGroup>
                  <C.FormGroup label="Height (cm)">
                    <input
                      type="number"
                      className="form-input"
                      value={customHeight}
                      step="0.1"
                      onChange={e => setCustomHeight(e.target.value)}
                    />
                  </C.FormGroup>
                </div>
              )}

              <C.FormGroup label="Paper Size">
                <select className="form-select" value={paperSize} onChange={e => setPaperSize(e.target.value)}>
                  <option value="4r">4R (4x6")</option>
                  <option value="a4">A4</option>
                </select>
              </C.FormGroup>

              <C.FormGroup label="Paper Orientation">
                <select className="form-select" value={paperOrientation} onChange={e => setPaperOrientation(e.target.value)}>
                  <option value="landscape">Landscape</option>
                  <option value="portrait">Portrait</option>
                </select>
              </C.FormGroup>

              <C.FormGroup label="Photos Per Sheet">
                <input
                  type="number"
                  className="form-input"
                  value={photosPerSheet}
                  min="1"
                  max="100"
                  onChange={e => setPhotosPerSheet(parseInt(e.target.value) || 1)}
                />
              </C.FormGroup>

              <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '16px 0' }}>
                <input
                  type="checkbox"
                  id="chk-cutline"
                  checked={cutline}
                  onChange={e => setCutline(e.target.checked)}
                  style={{ width: 16, height: 16, cursor: 'pointer' }}
                />
                <label htmlFor="chk-cutline" style={{ fontSize: 13, cursor: 'pointer', userSelect: 'none', color: 'var(--text-primary)' }}>
                  Add dotted cutlines for cutting
                </label>
              </div>
            </div>
          )}

          <div className="action-row" style={{ marginTop: 20, display: 'flex', gap: 10 }}>
            <button className="btn btn-primary" onClick={handleRun} disabled={!files.length} style={{ flex: 1 }}>
              Generate Sheet
            </button>
            {(resultUrl || previewUrl) && (
              <button className="btn btn-outline" onClick={handlePrint} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                🖨️ Print
              </button>
            )}
          </div>

          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}

          {resultUrl && (
            <div style={{ marginTop: 24, textAlign: 'center' }}>
              <h3 style={{ marginBottom: 15 }}>Success!</h3>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center' }}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Passport Photo", files, ".jpg")} />
                <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); setPreviewUrl(''); }}>Process Another</button>
              </div>
            </div>
          )}
        </div>

        {files.length > 0 && (
          <div className="tool-card" style={{ flex: '2 1 400px', margin: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <h3 style={{ marginBottom: 15 }}>Live Preview</h3>
            <img src={previewUrl || URL.createObjectURL(files[0])} style={{ maxWidth: '100%', maxHeight: '600px', objectFit: 'contain', borderRadius: 8 }} onLoad={e => { if (!previewUrl) URL.revokeObjectURL(e.target.src); }} />
          </div>
        )}
      </div>
    </div>
  );
};

window.PagesNew = {
  'img-to-pdf': () => <window.GenPage title="Image to PDF" endpoint="/new-image/image-to-pdf" fileLimit={50} options={[
    { key: 'page_size', label: 'Page Size', type: 'select', default: 'a4', choices: [{ label: 'A4', value: 'a4' }, { label: 'Letter', value: 'letter' }] },
    { key: 'orientation', label: 'Orientation', type: 'select', default: 'auto', choices: [{ label: 'Auto', value: 'auto' }, { label: 'Portrait', value: 'portrait' }, { label: 'Landscape', value: 'landscape' }] }
  ]} />,
  'bg-color': () => <window.GenPage title="BG Color Changer" endpoint="/new-image/change-bg-color" options={[
    { key: 'new_color', label: 'Background Color', type: 'color', default: '#FFFFFF' }
  ]} />,
  'passport-img': () => <window.PassportPhotoPage />,
  // 'remove-watermark': () => <window.RemoveWatermarkPage />, // disabled — upcoming tool
  'micro-pdf': () => <window.GenPage title="Micro PDF (N-Up Layout)" endpoint="/pdf/micro-pdf" options={[
    { key: 'pages_per_sheet', label: 'Pages Per Sheet', type: 'select', default: '6', choices: [{ label: '6 pages', value: '6' }, { label: '9 pages', value: '9' }, { label: '12 pages', value: '12' }, { label: '15 pages', value: '15' }] },
    { key: 'page_size', label: 'Output Size', type: 'select', default: 'a4', choices: [{ label: 'A4', value: 'a4' }, { label: 'Letter', value: 'letter' }] },
    { key: 'orientation', label: 'Orientation', type: 'select', default: 'portrait', choices: [{ label: 'Portrait', value: 'portrait' }, { label: 'Landscape', value: 'landscape' }] }
  ]} />
};

window.CompressPdfPage = function() {
  const [files, setFiles] = useState([]);
  const [quality, setQuality] = useState('ebook');
  const [useTargetSize, setUseTargetSize] = useState(false);
  const [targetSize, setTargetSize] = useState('');
  const [targetUnit, setTargetUnit] = useState('mb');

  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  React.useEffect(() => {
    if (files.length > 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const fd = new FormData();
        files.forEach(f => fd.append('file', f));
        fd.append('quality', quality);
        if (useTargetSize && targetSize) {
          fd.append('target_size', targetSize);
          fd.append('target_unit', targetUnit);
        }
        try {
          const res = await fetch('/api/pdf/compress', { method: 'POST', body: fd });
          if(res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if(old) URL.revokeObjectURL(old); return url; });
          }
        } catch(e) {}
      }, 500);
    }
  }, [files, quality, useTargetSize, targetSize, targetUnit]);

  React.useEffect(() => {
    return () => { if(previewUrl) URL.revokeObjectURL(previewUrl); }
  }, [previewUrl]);

  const handleRun = () => {
    if(!files.length) return;
    const fd = new FormData();
    files.forEach(f => fd.append('file', f));
    fd.append('quality', quality);
    if (useTargetSize && targetSize) {
      fd.append('target_size', targetSize);
      fd.append('target_unit', targetUnit);
    }
    process('/pdf/compress', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Compress PDF</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 350px', margin:0}}>
          <C.DropZone multiple={false} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setFiles(f.slice(0, 1));
          }} />
          <C.FileList files={files} onRemove={i => setFiles([])} />

          {files.length > 0 && (
            <div className="controls-grid" style={{marginTop:20}}>
              <C.FormGroup label="Quality Preset">
                <select className="form-select" value={quality} onChange={e => setQuality(e.target.value)}>
                  <option value="screen">Screen (Lowest quality)</option>
                  <option value="ebook">Ebook (Medium)</option>
                  <option value="printer">Printer (High)</option>
                </select>
              </C.FormGroup>

              <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '16px 0' }}>
                <input
                  type="checkbox"
                  id="chk-target-size-pdf"
                  checked={useTargetSize}
                  onChange={e => setUseTargetSize(e.target.checked)}
                  style={{ width: 16, height: 16, cursor: 'pointer' }}
                />
                <label htmlFor="chk-target-size-pdf" style={{ fontSize: 13, cursor: 'pointer', userSelect: 'none', color: 'var(--text-primary)', fontWeight: 600 }}>
                  Compress to specific target size
                </label>
              </div>

              {useTargetSize && (
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12, alignItems: 'end' }}>
                  <C.FormGroup label="Target Size">
                    <input
                      type="number"
                      className="form-input"
                      value={targetSize}
                      placeholder="e.g. 1"
                      onChange={e => setTargetSize(e.target.value)}
                    />
                  </C.FormGroup>
                  <C.FormGroup label="Unit">
                    <select
                      className="form-select"
                      value={targetUnit}
                      onChange={e => setTargetUnit(e.target.value)}
                    >
                      <option value="mb">MB</option>
                      <option value="kb">KB</option>
                    </select>
                  </C.FormGroup>
                </div>
              )}
            </div>
          )}

          <div className="action-row" style={{marginTop:20}}>
            <button className="btn btn-primary" onClick={handleRun} disabled={!files.length}>Process & Download</button>
          </div>

          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}

          {resultUrl && (
            <div style={{marginTop:24, textAlign:'center'}}>
              <h3 style={{marginBottom:15}}>Success!</h3>
              <div style={{display:'flex', gap:10, justifyContent:'center', alignItems:'center'}}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Compress PDF", files, ".pdf")} />
                <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); setQuality('ebook'); setUseTargetSize(false); setTargetSize(''); setPreviewUrl(''); }}>Process Another</button>
              </div>
            </div>
          )}
        </div>

        {files.length > 0 && (
          <div className="tool-card" style={{flex:'2 1 400px', margin:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center'}}>
             <h3 style={{marginBottom:15}}>Live Preview</h3>
             <iframe src={previewUrl || URL.createObjectURL(files[0])} width="100%" height="600px" style={{ border: '1px solid #ccc', borderRadius: 8 }} />
          </div>
        )}
      </div>
    </div>
  );
};

window.PagesPdf = {
  'pdf-to-docx': () => <window.GenPage title="PDF to Docx" endpoint="/pdf/pdf-to-docx" disableLivePreview={true} />,
  'docx-to-pdf': () => <window.DocxToPdfPage />,
  'pdf-compress': () => <window.CompressPdfPage />,
  'pdf-merge': () => <window.MergePdfPage />,
  'pdf-split': () => <window.SplitPdfPage />,
  'pdf-to-img': () => <window.GenPage title="PDF to Image" endpoint="/pdf/to-image" disableLivePreview={true} options={[
    { key: 'pages', label: 'Page Range (e.g. 1,2,3 or all)', type: 'text', default: 'all' },
    { key: 'dpi', label: 'DPI', type: 'number', default: 150 },
    { key: 'output_format', label: 'Format', type: 'select', default: 'jpeg', choices: [{ label: 'JPEG', value: 'jpeg' }, { label: 'PNG', value: 'png' }] }
  ]} />,
  'pdf-watermark': () => <window.GenPage title="Watermark PDF" endpoint="/pdf/watermark" options={[
    { key: 'text', label: 'Text', type: 'text', default: 'CONFIDENTIAL' },
    { key: 'font_size', label: 'Font Size', type: 'slider', min: 10, max: 200, default: 48 },
    { key: 'opacity', label: 'Opacity (0.0-1.0)', type: 'slider', min: 0.1, max: 1.0, default: 0.3 },
    { key: 'color', label: 'Color', type: 'color', default: '#FF0000' },
    { key: 'rotation', label: 'Rotation (Degrees)', type: 'slider', min: 0, max: 360, default: 45 },
    { key: 'x_pct', label: 'X Offset (%) [Custom]', type: 'slider', min: -1, max: 100, default: -1 },
    { key: 'y_pct', label: 'Y Offset (%) [Custom]', type: 'slider', min: -1, max: 100, default: -1 }
  ]} />,
  'pdf-remove-watermark': () => <window.GenPage title="Remove PDF Watermark" endpoint="/pdf/remove-watermark" options={[
    { key: 'text', label: 'Text to Remove', type: 'text', default: 'CONFIDENTIAL' }
  ]} />,
  'pdf-protect': () => <window.GenPage title="Protect PDF" endpoint="/pdf/protect" options={[
    { key: 'user_password', label: 'Password', type: 'text', default: '' }
  ]} />,
  'pdf-rotate': () => <window.PdfRotatePage />,
  'pdf-unlock': () => <window.GenPage title="Unlock PDF" endpoint="/pdf/unlock" options={[
    { key: 'password', label: 'Password', type: 'text', default: '' }
  ]} />
};
