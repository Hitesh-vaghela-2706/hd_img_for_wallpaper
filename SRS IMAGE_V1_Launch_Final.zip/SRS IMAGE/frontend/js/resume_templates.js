'use strict';
/* ═══════════════════════════════════════
   Resume Templates — 15 Modern HTML generators
═══════════════════════════════════════ */
(function(){

function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function nl2br(s){ return (s||'').replace(/\n/g,'<br>'); }
const RB_BLK = 'display:block;margin:0 0 6px 0;padding:0;line-height:1.6;position:static;min-height:1.5em;word-wrap:break-word;';
const RB_LI = 'display:list-item;margin:0 0 6px 0;padding:0;line-height:1.6;position:static;min-height:1.5em;';
const RB_UL = 'display:block;margin:6px 0 10px 0;padding:0 0 0 20px;list-style-type:disc;list-style-position:outside;';
const RB_HD = 'display:block;font-weight:700;margin:8px 0 4px 0;line-height:1.5;position:static;';
const RB_EM = 'display:block;font-style:italic;margin:0 0 6px 0;line-height:1.6;position:static;';

function rich(s){
  if(!s) return '';
  let h=String(s);
  if(!/<[a-z][\s\S]*>/i.test(h)) return nl2br(esc(h));
  h=h.replace(/<script[^>]*>[\s\S]*?<\/script>/gi,'').replace(/on\w+="[^"]*"/gi,'');
  h=h.replace(/<b>([^<]*)<\/b>\s*<ul>/gi,'<div class="rb-rich-heading" style="'+RB_HD+'"><b style="'+RB_HD+'">$1</b></div><ul style="'+RB_UL+'">');
  h=h.replace(/<\/ul>\s*<b>([^<]*)<\/b>/gi,'</ul><div class="rb-rich-heading" style="'+RB_HD+'"><b style="'+RB_HD+'">$1</b></div>');
  return applyRichLayout(h);
}

function applyRichLayout(h){
  if(!h) return '';
  return h
    .replace(/<ul>/gi,'<ul style="'+RB_UL+'">')
    .replace(/<ol>/gi,'<ol style="display:block;margin:6px 0 10px 0;padding:0 0 0 20px;list-style-type:decimal;list-style-position:outside;">')
    .replace(/<li>/gi,'<li style="'+RB_LI+'">')
    .replace(/<div class="rb-rich-heading">/gi,'<div class="rb-rich-heading" style="'+RB_HD+'">')
    .replace(/<div(?![^>]*\bstyle=)(?![^>]*\bclass=)/gi,'<div style="'+RB_BLK+'">')
    .replace(/<p(?![^>]*\bstyle=)/gi,'<p style="'+RB_BLK+'">')
    .replace(/<b(?![^>]*\bstyle=)/gi,'<b style="'+RB_HD+'">')
    .replace(/<strong(?![^>]*\bstyle=)/gi,'<strong style="'+RB_HD+'">')
    .replace(/<i(?![^>]*\bstyle=)/gi,'<i style="'+RB_EM+'">')
    .replace(/<em(?![^>]*\bstyle=)/gi,'<em style="'+RB_EM+'">');
}

function richBlock(s){
  return '<div class="rb-rich-block" style="display:block;line-height:1.6;word-wrap:break-word;overflow-wrap:break-word;">'+rich(s)+'</div>';
}

window.ResumeRichPreviewCSS = '<style>.rb-resume-frame .rb-rich-block *{box-sizing:border-box;position:static!important;max-height:none!important;}.rb-resume-frame .rb-rich-block ul,.rb-resume-frame .rb-rich-block ol{display:block!important;}.rb-resume-frame .rb-rich-block li{display:list-item!important;}[data-rb-block],[data-rb-entry]{break-inside:avoid;page-break-inside:avoid;}</style>';
function sectionEnabled(d,id){ return !(d._disabled&&d._disabled[id]); }
function dots(n,max,c,empty){
  const e=empty||'#e2e8f0';
  let h='<span class="rb-dots" style="display:inline-flex;gap:5px;align-items:center;flex-shrink:0">';
  for(let i=1;i<=max;i++) h+=`<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${i<=n?c:e}"></span>`;
  return h+'</span>';
}
function skillProficiencyRow(name,level,t,light){
  const dotCol=light?'rgba(255,255,255,0.85)':t.primary;
  const emptyCol=light?'rgba(255,255,255,0.25)':'#e2e8f0';
  const lvl=level||3;
  return `<div style="margin-bottom:10px">
    <div style="font-size:0.82em;line-height:1.4;margin-bottom:5px;word-break:break-word;color:${light?'rgba(255,255,255,0.95)':'#334155'}">${esc(name)}</div>
    <div style="display:flex;align-items:center;gap:8px">${dots(lvl,5,dotCol,emptyCol)}<span style="font-size:0.72em;opacity:0.7;color:${light?'rgba(255,255,255,0.6)':'#94a3b8'}">${lvl}/5</span></div>
  </div>`;
}
function sidebarSkills(skills,t,light){
  const list=(skills||[]).filter(s=>s.enabled!==false);
  if(!list.length) return '';
  const hasCat=list.some(s=>s.category);
  if(!hasCat) return list.map(s=>skillProficiencyRow(s.name,s.level,t,light)).join('');
  const groups={};
  list.forEach(s=>{const c=s.category||'General';if(!groups[c])groups[c]=[];groups[c].push(s);});
  return Object.entries(groups).map(([cat,items])=>`
    <div style="margin-bottom:14px">
      <div style="font-size:0.72em;font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;opacity:${light?0.65:1};color:${light?'rgba(255,255,255,0.7)':t.primary}">${esc(cat)}</div>
      ${items.map(s=>skillProficiencyRow(s.name,s.level,t,light)).join('')}
    </div>`).join('');
}
function bar(n,max,c,accent){
  const grad = accent ? `linear-gradient(90deg,${c},${accent})` : c;
  return `<div style="height:5px;background:#f1f5f9;border-radius:99px;overflow:hidden"><div style="height:100%;width:${n/max*100}%;background:${grad};border-radius:99px"></div></div>`;
}
function padNeg(t){ return t.spacing==='compact'?'16px':t.spacing==='spacious'?'36px':'24px'; }
function initials(name){ return ((name||'R').trim().charAt(0)||'R').toUpperCase(); }

function contactLine(d, light){
  let parts=[];
  if(d.phone) parts.push(esc(d.phone));
  if(d.email) parts.push(esc(d.email));
  if(d.location) parts.push(esc(d.location));
  if(d.linkedin) parts.push(esc(d.linkedin));
  if(d.website) parts.push(esc(d.website));
  const col = light ? 'rgba(255,255,255,0.85)' : '#64748b';
  return `<div style="font-size:0.82em;color:${col};display:flex;flex-wrap:wrap;gap:6px 14px;justify-content:inherit">${parts.map(p=>`<span>${p}</span>`).join('')}</div>`;
}

function contactPills(d,t,light){
  const items=[];
  if(d.phone) items.push(['📞',d.phone]);
  if(d.email) items.push(['✉',d.email]);
  if(d.location) items.push(['📍',d.location]);
  if(d.linkedin) items.push(['🔗',d.linkedin]);
  if(d.website) items.push(['🌐',d.website]);
  const bg = light ? 'rgba(255,255,255,0.15)' : `${t.primary}12`;
  const col = light ? '#fff' : t.primary;
  const border = light ? 'rgba(255,255,255,0.25)' : `${t.primary}30`;
  return `<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:10px">${items.map(([ic,v])=>`<span style="display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:99px;background:${bg};color:${col};border:1px solid ${border};font-size:0.78em;font-weight:500">${ic} ${esc(v)}</span>`).join('')}</div>`;
}

/* ── Section blocks ── */
function secTitle(title,t,variant){
  const v = variant || 'underline';
  if(v==='pill') return `<div style="display:inline-block;padding:5px 14px;border-radius:99px;background:${t.primary};color:#fff;font-size:0.72em;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:12px">${esc(title)}</div>`;
  if(v==='sidebar') return `<h3 style="font-size:0.75em;color:${t.primary};text-transform:uppercase;letter-spacing:2px;font-weight:700;margin:0 0 12px 0;padding-bottom:6px;border-bottom:2px solid ${t.accent||t.primary}40">${esc(title)}</h3>`;
  if(v==='accent-bar') return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px"><div style="width:4px;height:22px;background:linear-gradient(180deg,${t.primary},${t.secondary||t.accent||t.primary});border-radius:2px"></div><h3 style="margin:0;font-size:0.95em;font-weight:700;color:#1e293b;text-transform:uppercase;letter-spacing:0.8px">${esc(title)}</h3></div>`;
  if(v==='minimal') return `<h3 style="margin:0 0 10px;font-size:0.7em;font-weight:700;color:${t.primary};text-transform:uppercase;letter-spacing:3px">${esc(title)}</h3>`;
  return `<h3 style="font-size:0.92em;color:${t.primary};font-weight:700;margin:0 0 10px;padding-bottom:6px;border-bottom:2px solid ${t.primary}25;display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:50%;background:${t.primary};flex-shrink:0"></span>${esc(title)}</h3>`;
}

function sectionWrap(title,content,t,variant){
  if(!content||!content.trim()) return '';
  return `<div data-rb-block="1" style="margin-bottom:22px;break-inside:avoid;page-break-inside:avoid">${secTitle(title,t,variant)}${content}</div>`;
}

function expTimeline(entries,t){
  return (entries||[]).filter(e=>e.enabled!==false).map((e,i)=>`
    <div data-rb-entry="1" style="display:flex;gap:14px;margin-bottom:18px;position:relative;break-inside:avoid;page-break-inside:avoid">
      <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;width:14px">
        <div style="width:12px;height:12px;border-radius:50%;background:${t.primary};border:3px solid ${t.primary}30;flex-shrink:0"></div>
        ${i<(entries.filter(x=>x.enabled!==false).length-1)?`<div style="width:2px;flex:1;min-height:20px;background:linear-gradient(180deg,${t.primary}40,transparent);margin-top:4px"></div>`:''}
      </div>
      <div style="flex:1;padding-bottom:4px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap">
          <strong style="color:#1e293b;font-size:0.95em">${esc(e.title)}</strong>
          <span style="font-size:0.75em;color:#fff;background:${t.primary};padding:3px 10px;border-radius:99px;font-weight:600;white-space:nowrap">${esc(e.date)}</span>
        </div>
        <div style="font-size:0.85em;color:${t.primary};font-weight:600;margin:3px 0 6px">${esc(e.company||'')}${e.location?` <span style="color:#94a3b8;font-weight:400">· ${esc(e.location)}</span>`:''}</div>
        <div style="font-size:0.88em;color:#475569;line-height:1.55">${richBlock(e.description||'')}</div>
      </div>
    </div>`).join('');
}

function expCards(entries,t){
  return (entries||[]).filter(e=>e.enabled!==false).map(e=>`
    <div data-rb-entry="1" style="margin-bottom:14px;padding:14px 16px;border-radius:10px;background:#f8fafc;border-left:4px solid ${t.primary};box-shadow:0 1px 3px rgba(0,0,0,0.04);break-inside:avoid;page-break-inside:avoid">
      <div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px">
        <strong style="color:#1e293b;font-size:0.92em">${esc(e.title)}</strong>
        <span style="font-size:0.75em;color:#64748b;font-weight:600">${esc(e.date)}</span>
      </div>
      <div style="font-size:0.84em;color:${t.primary};font-weight:600;margin:4px 0 6px">${esc(e.company||'')}${e.location?' · '+esc(e.location):''}</div>
      <div style="font-size:0.86em;color:#475569;line-height:1.5">${richBlock(e.description||'')}</div>
    </div>`).join('');
}

function eduHTML(entries,t){
  return (entries||[]).filter(e=>e.enabled!==false).map(e=>`
    <div data-rb-entry="1" style="margin-bottom:14px;padding:12px 14px;border-radius:8px;background:linear-gradient(135deg,${t.primary}08,transparent);break-inside:avoid;page-break-inside:avoid">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <strong style="color:#1e293b;font-size:0.92em">${esc(e.degree)}</strong>
        <span style="font-size:0.75em;color:#64748b;font-weight:600">${esc(e.date)}</span>
      </div>
      <div style="font-size:0.84em;color:${t.primary};margin-top:3px;font-weight:500">${esc(e.institution||'')}</div>
      ${e.description?`<div style="margin-top:4px;font-size:0.82em;color:#64748b;line-height:1.6">${(/<[a-z]/i.test(e.description))?richBlock(e.description):nl2br(esc(e.description))}</div>`:''}
    </div>`).join('');
}

function skillsCategorized(skills,t,mode){
  if(!skills||!skills.length) return '';
  const hasCat = skills.some(s=>s.category);
  if(!hasCat) return skillsHTML(skills,t,mode);
  const groups={};
  skills.filter(s=>s.enabled!==false).forEach(s=>{
    const c=s.category||'General';
    if(!groups[c]) groups[c]=[];
    groups[c].push(s);
  });
  return Object.entries(groups).map(([cat,items])=>`
    <div style="margin-bottom:14px">
      <div style="font-size:0.78em;font-weight:700;color:${t.primary};text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">${esc(cat)}</div>
      ${mode==='bar'||mode==='dots'?skillsHTML(items,t,mode):skillTags(items,t)}
    </div>`).join('');
}

function skillTags(skills,t){
  return `<div style="display:flex;flex-wrap:wrap;gap:6px">${skills.filter(s=>s.enabled!==false).map(s=>`<span style="padding:5px 12px;border-radius:99px;background:linear-gradient(135deg,${t.primary}18,${t.secondary||t.accent||t.primary}12);color:${t.primary};font-size:0.8em;font-weight:600;border:1px solid ${t.primary}25">${esc(s.name)}</span>`).join('')}</div>`;
}

function skillsHTML(skills,t,mode){
  if(!skills||!skills.length) return '';
  if(mode==='bar') return skills.filter(s=>s.enabled!==false).map(s=>`
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:0.82em;margin-bottom:4px"><span style="font-weight:600;color:#334155">${esc(s.name)}</span><span style="color:#94a3b8;font-size:0.9em">${s.level}/5</span></div>
      ${bar(s.level,5,t.primary,t.secondary)}
    </div>`).join('');
  if(mode==='dots') return skills.filter(s=>s.enabled!==false).map(s=>skillProficiencyRow(s.name,s.level,t,false)).join('');
  return skillTags(skills,t);
}

function projectCards(arr,t){
  if(!arr||!arr.length) return '';
  return arr.filter(e=>e.enabled!==false).map(e=>`
    <div data-rb-entry="1" style="margin-bottom:12px;padding:14px;border-radius:10px;border:1px solid ${t.primary}20;background:#fff;break-inside:avoid;page-break-inside:avoid">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <strong style="color:#1e293b;font-size:0.9em">${esc(e.title||'')}</strong>
        ${e.date?`<span style="font-size:0.72em;padding:2px 8px;border-radius:99px;background:${t.primary}15;color:${t.primary};font-weight:600">${esc(e.date)}</span>`:''}
      </div>
      ${e.description?`<div style="font-size:0.84em;color:#475569;line-height:1.6">${richBlock(e.description)}</div>`:''}
    </div>`).join('');
}

function simpleList(arr,t){
  if(!arr||!arr.length) return '';
  return arr.filter(e=>e.enabled!==false).map(e=>`
    <div data-rb-entry="1" style="margin-bottom:10px;padding-left:12px;border-left:2px solid ${t.primary}30;break-inside:avoid;page-break-inside:avoid">
      <strong style="color:#1e293b;font-size:0.88em">${esc(e.title||e.name||'')}</strong>
      ${e.date?`<span style="color:#94a3b8;font-size:0.78em;margin-left:6px">${esc(e.date)}</span>`:''}
      ${e.description?`<div style="font-size:0.84em;color:#475569;margin-top:3px;line-height:1.5">${richBlock(e.description)}</div>`:''}
    </div>`).join('');
}

function rootStyle(t,extra){
  const sz = t.fontSize==='small'?'13px':t.fontSize==='large'?'16px':'14px';
  const sp = t.spacing==='compact'?'16px':t.spacing==='spacious'?'36px':'24px';
  return `font-family:'${t.fontFamily}',sans-serif;font-size:${sz};padding:${sp};color:#334155;line-height:1.55;box-sizing:border-box;${extra||''}`;
}

function getSections(d){
  return d._sectionOrder || ['summary','experience','education','skills','projects','certifications','awards','languages','volunteer','custom'];
}

function renderSections(d,t,opts){
  const secs = getSections(d);
  const v = opts.sectionVariant || 'underline';
  const expFn = opts.expStyle==='cards' ? expCards : expTimeline;
  let html = '';
  secs.forEach(s=>{
    if(d._disabled && d._disabled[s]) return;
    switch(s){
      case 'summary':
        if(d.summary) html += sectionWrap('Professional Summary',`<p style="margin:0;color:#475569;font-size:0.92em;line-height:1.65;padding:12px 16px;border-radius:8px;background:#f8fafc;border-left:3px solid ${t.primary}">${nl2br(esc(d.summary))}</p>`,t,v);
        break;
      case 'experience': html += sectionWrap('Experience',expFn(d.experience,t),t,v); break;
      case 'education': html += sectionWrap('Education',eduHTML(d.education,t),t,v); break;
      case 'skills':
        if(opts._skipSkills) break;
        html += sectionWrap('Skills',skillsCategorized(d.skills,t,opts.skillMode||'tags'),t,v);
        break;
      case 'projects': if(d.projects&&d.projects.length) html += sectionWrap('Projects',projectCards(d.projects,t),t,v); break;
      case 'certifications': if(d.certifications&&d.certifications.length) html += sectionWrap('Certifications',simpleList(d.certifications,t),t,v); break;
      case 'awards': if(d.awards&&d.awards.length) html += sectionWrap('Awards',simpleList(d.awards,t),t,v); break;
      case 'languages':
        if(opts._skipLangs) break;
        if(d.languages&&d.languages.length) html += sectionWrap('Languages',skillsHTML(d.languages,t,'dots'),t,v);
        break;
      case 'volunteer': if(d.volunteer&&d.volunteer.length) html += sectionWrap('Volunteer',simpleList(d.volunteer,t),t,v); break;
      case 'custom':
        if(d.customSections) d.customSections.forEach(cs=>{
          if(cs.enabled!==false) html += sectionWrap(cs.label||'Other',`<div style="font-size:0.88em;color:#475569;line-height:1.6">${richBlock(cs.content||'')}</div>`,t,v);
        });
        break;
    }
  });
  return html;
}

function avatar(size,t,name){
  return `<div style="width:${size}px;height:${size}px;border-radius:50%;background:linear-gradient(135deg,${t.primary},${t.secondary||t.accent||t.primary});color:#fff;display:flex;align-items:center;justify-content:center;font-size:${size*0.38}px;font-weight:800;flex-shrink:0;box-shadow:0 4px 14px ${t.primary}40">${initials(name)}</div>`;
}

/* ══════════════════════════════════════════
   TEMPLATE DEFINITIONS
══════════════════════════════════════════ */
const TEMPLATES = {};

// 1. Classic — Refined professional
TEMPLATES.classic = function(d,t){
  const n = padNeg(t);
  return `<div style="${rootStyle(t)}">
    <div style="text-align:center;margin:-${n} -${n} 24px;padding:28px 24px;background:linear-gradient(180deg,${t.primary}08 0%,transparent 100%)">
      <div style="display:flex;justify-content:center;margin-bottom:14px">${avatar(72,t,d.name)}</div>
      <h1 style="margin:0;color:#1e293b;font-size:1.75em;font-weight:800;letter-spacing:-0.5px">${esc(d.name)}</h1>
      ${d.title?`<div style="color:${t.primary};font-size:0.95em;margin-top:6px;font-weight:600">${esc(d.title)}</div>`:''}
      <div style="width:50px;height:3px;background:linear-gradient(90deg,${t.primary},${t.secondary||t.accent||t.primary});margin:12px auto;border-radius:2px"></div>
      <div style="display:flex;justify-content:center">${contactLine(d)}</div>
    </div>
    ${renderSections(d,t,{skillMode:'tags',sectionVariant:'underline'})}
  </div>`;
};

// 2. Modern — Split hero header
TEMPLATES.modern = function(d,t){
  const n = padNeg(t);
  return `<div style="${rootStyle(t,'padding:0;')}">
    <div style="display:flex;align-items:center;gap:24px;padding:32px 28px;background:linear-gradient(135deg,${t.primary},${t.secondary||'#6366f1'});color:#fff;margin-bottom:24px">
      ${avatar(80,t,d.name)}
      <div style="flex:1">
        <h1 style="margin:0;font-size:1.7em;font-weight:800;letter-spacing:-0.5px">${esc(d.name)}</h1>
        ${d.title?`<div style="opacity:0.92;font-size:0.95em;margin-top:5px;font-weight:500">${esc(d.title)}</div>`:''}
        ${contactPills(d,t,true)}
      </div>
    </div>
    <div style="padding:0 28px 28px">${renderSections(d,t,{skillMode:'bar',sectionVariant:'accent-bar'})}</div>
  </div>`;
};

// 3. Minimal — Editorial left accent
TEMPLATES.minimal = function(d,t){
  return `<div data-rb-layout="flex-sidebar" style="${rootStyle(t)}display:flex;gap:0;padding:0;min-height:100%;">
    <div data-rb-sidebar="1" style="width:6px;background:linear-gradient(180deg,${t.primary},${t.secondary||t.accent||t.primary});flex-shrink:0"></div>
    <div data-rb-main="1" style="flex:1;padding:36px 32px;min-width:0">
      <h1 style="margin:0;font-weight:300;font-size:2.2em;color:#1e293b;letter-spacing:-1px">${esc(d.name)}</h1>
      ${d.title?`<div style="color:${t.primary};font-size:0.9em;margin-top:8px;font-weight:600;letter-spacing:1px;text-transform:uppercase">${esc(d.title)}</div>`:''}
      <div style="font-size:0.8em;color:#94a3b8;margin:12px 0 28px">${contactLine(d)}</div>
      ${renderSections(d,t,{skillMode:'tags',sectionVariant:'minimal'})}
    </div>
  </div>`;
};

// 4. Bold — Diagonal hero
TEMPLATES.bold = function(d,t){
  const n = padNeg(t);
  return `<div style="${rootStyle(t,'padding:0;')}">
    <div style="position:relative;padding:40px 28px 50px;background:${t.primary};color:#fff;overflow:hidden;margin-bottom:24px">
      <div style="position:absolute;top:-30px;right:-30px;width:180px;height:180px;border-radius:50%;background:rgba(255,255,255,0.08)"></div>
      <div style="position:absolute;bottom:-40px;left:30%;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,0.05)"></div>
      <h1 style="margin:0;font-size:2.2em;font-weight:900;text-transform:uppercase;letter-spacing:2px;position:relative">${esc(d.name)}</h1>
      ${d.title?`<div style="font-size:1em;margin-top:10px;font-weight:400;opacity:0.9;position:relative;text-transform:uppercase;letter-spacing:3px">${esc(d.title)}</div>`:''}
      <div style="position:relative;margin-top:14px">${contactLine(d,true)}</div>
    </div>
    <div style="padding:0 28px 28px">${renderSections(d,t,{skillMode:'bar',sectionVariant:'pill',expStyle:'cards'})}</div>
  </div>`;
};

// 5. Creative — Dark sidebar
TEMPLATES.creative = function(d,t){
  const sideSkills = sectionEnabled(d,'skills') ? sidebarSkills(d.skills,t,true) : '';
  const sideLangs = sectionEnabled(d,'languages') && d.languages&&d.languages.length
    ? d.languages.filter(l=>l.enabled!==false).map(l=>skillProficiencyRow(l.name,l.level,t,true)).join('')
    : '';
  return `<div data-rb-layout="flex-sidebar" style="${rootStyle(t,'display:flex;padding:0;min-height:100%;')}">
    <div data-rb-sidebar="1" style="width:34%;background:linear-gradient(180deg,#1e293b 0%,#0f172a 100%);color:#fff;padding:32px 22px;flex-shrink:0">
      <div style="margin-bottom:20px">${avatar(64,t,d.name)}</div>
      <h1 style="margin:0;font-size:1.25em;font-weight:800;line-height:1.3">${esc(d.name)}</h1>
      ${d.title?`<div style="opacity:0.75;margin-top:8px;font-size:0.82em;line-height:1.4;color:${t.accent||'#60a5fa'}">${esc(d.title)}</div>`:''}
      <div style="height:1px;background:rgba(255,255,255,0.15);margin:18px 0"></div>
      <div style="font-size:0.78em;opacity:0.85;line-height:1.8">
        ${d.email?`<div>✉ ${esc(d.email)}</div>`:''}
        ${d.phone?`<div>📞 ${esc(d.phone)}</div>`:''}
        ${d.location?`<div>📍 ${esc(d.location)}</div>`:''}
        ${d.linkedin?`<div>🔗 ${esc(d.linkedin)}</div>`:''}
      </div>
      ${sideSkills?`<div style="height:1px;background:rgba(255,255,255,0.15);margin:18px 0"></div>${secTitle('Skills',t,'sidebar').replace(/color:[^;]+/,'color:rgba(255,255,255,0.9)').replace(/border-bottom:[^"]+/,'border-bottom:2px solid rgba(255,255,255,0.2)')}${sideSkills}`:''}
      ${sideLangs?`<div style="height:1px;background:rgba(255,255,255,0.15);margin:18px 0"></div>${secTitle('Languages',t,'sidebar').replace(/color:[^;]+/,'color:rgba(255,255,255,0.9)').replace(/border-bottom:[^"]+/,'border-bottom:2px solid rgba(255,255,255,0.2)')}${sideLangs}`:''}
    </div>
    <div data-rb-main="1" style="flex:1;padding:32px 26px;background:#fff;min-width:0">
      ${renderSections(d,t,{skillMode:'tags',sectionVariant:'accent-bar',_skipSkills:true,_skipLangs:true})}
    </div>
  </div>`;
};

// 6. Executive — Premium structured
TEMPLATES.executive = function(d,t){
  return `<div style="${rootStyle(t)}">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid ${t.primary};padding-bottom:18px;margin-bottom:24px">
      <div>
        <h1 style="margin:0;color:#1e293b;font-size:1.65em;font-weight:800">${esc(d.name)}</h1>
        ${d.title?`<div style="color:${t.primary};font-size:0.95em;margin-top:5px;font-weight:600">${esc(d.title)}</div>`:''}
      </div>
      <div style="text-align:right;font-size:0.78em;color:#64748b;line-height:1.7">
        ${d.phone?`<div>${esc(d.phone)}</div>`:''}
        ${d.email?`<div>${esc(d.email)}</div>`:''}
        ${d.location?`<div>${esc(d.location)}</div>`:''}
      </div>
    </div>
    ${renderSections(d,t,{skillMode:'bar',sectionVariant:'underline',expStyle:'cards'})}
  </div>`;
};

// 7. Tech — Developer terminal aesthetic
TEMPLATES.tech = function(d,t){
  const n = padNeg(t);
  return `<div style="${rootStyle(t,'background:#0f172a;color:#e2e8f0;padding:0;')}">
    <div style="padding:24px 28px;background:#1e293b;border-bottom:1px solid #334155;font-family:'Courier New',monospace">
      <div style="display:flex;gap:6px;margin-bottom:14px">
        <span style="width:12px;height:12px;border-radius:50%;background:#ef4444"></span>
        <span style="width:12px;height:12px;border-radius:50%;background:#fbbf24"></span>
        <span style="width:12px;height:12px;border-radius:50%;background:#22c55e"></span>
      </div>
      <div style="font-size:0.85em"><span style="color:#22d3ee">const</span> <span style="color:#f472b6">developer</span> = {</div>
      <div style="font-size:0.85em;padding-left:20px"><span style="color:#a5b4fc">name</span>: <span style="color:#86efac">"${esc(d.name)}"</span>,</div>
      ${d.title?`<div style="font-size:0.85em;padding-left:20px"><span style="color:#a5b4fc">role</span>: <span style="color:#86efac">"${esc(d.title)}"</span>,</div>`:''}
      <div style="font-size:0.85em;padding-left:20px"><span style="color:#a5b4fc">contact</span>: <span style="color:#86efac">"${esc(d.email||d.phone||'')}"</span></div>
      <div style="font-size:0.85em">};</div>
    </div>
    <div style="padding:24px 28px">
      ${renderSections(d,{...t,primary:'#22d3ee',secondary:'#a78bfa'}, {skillMode:'tags',sectionVariant:'minimal'}).replace(/#1e293b/g,'#f1f5f9').replace(/#334155/g,'#475569').replace(/#475569/g,'#cbd5e1').replace(/#64748b/g,'#94a3b8').replace(/#f8fafc/g,'#1e293b').replace(/#fff/g,'#0f172a')}
    </div>
  </div>`;
};

// 8. Gradient — Mesh gradient hero
TEMPLATES.gradient = function(d,t){
  return `<div style="${rootStyle(t,'padding:0;')}">
    <div style="padding:36px 28px;background:linear-gradient(135deg,${t.primary} 0%,${t.secondary||'#8b5cf6'} 50%,${t.accent||'#06b6d4'} 100%);color:#fff;position:relative;overflow:hidden">
      <div style="position:absolute;inset:0;background:radial-gradient(circle at 20% 80%,rgba(255,255,255,0.15) 0%,transparent 50%),radial-gradient(circle at 80% 20%,rgba(255,255,255,0.1) 0%,transparent 40%)"></div>
      <div style="position:relative;display:flex;align-items:center;gap:20px">
        ${avatar(70,t,d.name)}
        <div>
          <h1 style="margin:0;font-size:1.8em;font-weight:800">${esc(d.name)}</h1>
          ${d.title?`<div style="opacity:0.9;font-size:0.95em;margin-top:6px">${esc(d.title)}</div>`:''}
          ${contactPills(d,t,true)}
        </div>
      </div>
    </div>
    <div style="padding:24px 28px">${renderSections(d,t,{skillMode:'bar',sectionVariant:'accent-bar'})}</div>
  </div>`;
};

// 9. Elegant — Serif luxury
TEMPLATES.elegant = function(d,t){
  return `<div style="${rootStyle(t,'font-family:\'Playfair Display\',serif;')}">
    <div style="text-align:center;margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid ${t.primary}30">
      <h1 style="margin:0;color:#1e293b;font-size:2em;font-weight:600;font-style:italic;letter-spacing:1px">${esc(d.name)}</h1>
      ${d.title?`<div style="color:${t.primary};font-size:0.9em;margin-top:8px;font-style:normal;font-weight:500;letter-spacing:2px;text-transform:uppercase">${esc(d.title)}</div>`:''}
      <div style="display:flex;align-items:center;justify-content:center;gap:12px;margin-top:14px">
        <div style="width:40px;height:1px;background:${t.primary}"></div>
        <div style="font-size:0.75em;color:#94a3b8;font-family:'${t.fontFamily}',sans-serif">${contactLine(d)}</div>
        <div style="width:40px;height:1px;background:${t.primary}"></div>
      </div>
    </div>
    ${renderSections(d,t,{skillMode:'dots',sectionVariant:'minimal'})}
  </div>`;
};

// 10. Compact — Two-column efficient
TEMPLATES.compact = function(d,t){
  const leftSecs = ['summary','skills','education','languages'];
  const rightSecs = ['experience','projects','certifications','awards','volunteer','custom'];
  const order = getSections(d);
  const renderOne = (sid)=>{
    if(d._disabled&&d._disabled[sid]) return '';
    const opts={skillMode:'tags',sectionVariant:'minimal',_skipSkills:false,_skipLangs:false};
    switch(sid){
      case 'summary': return d.summary?sectionWrap('Summary',`<p style="margin:0;font-size:0.85em;color:#475569;line-height:1.5">${nl2br(esc(d.summary))}</p>`,t,'minimal'):'';
      case 'experience': return sectionWrap('Experience',expCards(d.experience,t),t,'minimal');
      case 'education': return sectionWrap('Education',eduHTML(d.education,t),t,'minimal');
      case 'skills': return sectionWrap('Skills',skillsCategorized(d.skills,t,'tags'),t,'minimal');
      case 'projects': return d.projects&&d.projects.length?sectionWrap('Projects',projectCards(d.projects,t),t,'minimal'):'';
      case 'certifications': return d.certifications&&d.certifications.length?sectionWrap('Certs',simpleList(d.certifications,t),t,'minimal'):'';
      case 'awards': return d.awards&&d.awards.length?sectionWrap('Awards',simpleList(d.awards,t),t,'minimal'):'';
      case 'languages': return d.languages&&d.languages.length?sectionWrap('Languages',skillsHTML(d.languages,t,'dots'),t,'minimal'):'';
      case 'volunteer': return d.volunteer&&d.volunteer.length?sectionWrap('Volunteer',simpleList(d.volunteer,t),t,'minimal'):'';
      case 'custom': return (d.customSections||[]).map(cs=>cs.enabled!==false?sectionWrap(cs.label||'Other',`<div style="font-size:0.84em;color:#475569;line-height:1.6">${richBlock(cs.content||'')}</div>`,t,'minimal'):'').join('');
      default: return '';
    }
  };
  const left = order.filter(s=>leftSecs.includes(s)).map(renderOne).join('');
  const right = order.filter(s=>rightSecs.includes(s)).map(renderOne).join('');
  return `<div data-rb-layout="grid-2col" style="${rootStyle(t,'font-size:12px;padding:18px;line-height:1.4;')}">
    <div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:12px;margin-bottom:14px;border-bottom:2px solid ${t.primary}">
      <h1 style="margin:0;color:#1e293b;font-size:1.5em;font-weight:800">${esc(d.name)}</h1>
      <div style="font-size:0.78em;color:#64748b;text-align:right;line-height:1.5">${d.email?`<div>${esc(d.email)}</div>`:''}${d.phone?`<div>${esc(d.phone)}</div>`:''}</div>
    </div>
    ${d.title?`<div style="color:${t.primary};font-size:0.85em;font-weight:600;margin-bottom:14px">${esc(d.title)}</div>`:''}
    <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:20px">
      <div>${left}</div>
      <div>${right}</div>
    </div>
  </div>`;
};

// 11. Vibrant — Color-block sections
TEMPLATES.vibrant = function(d,t){
  const colors=[t.primary,t.secondary||'#f59e0b',t.accent||'#10b981','#8b5cf6','#ec4899'];
  let ci=0;
  const vibrantSections = (d,t2,opts)=>{
    const secs=getSections(d);
    let html='';
    secs.forEach(s=>{
      if(d._disabled&&d._disabled[s]) return;
      const col=colors[ci++%colors.length];
      const block=(title,content)=>{
        if(!content||!content.trim()) return '';
        return `<div data-rb-block="1" style="margin-bottom:16px;padding:16px;border-radius:12px;background:${col}10;border-left:4px solid ${col};break-inside:avoid;page-break-inside:avoid">
          <h3 style="margin:0 0 10px;font-size:0.82em;font-weight:800;color:${col};text-transform:uppercase;letter-spacing:1px">${esc(title)}</h3>
          ${content}
        </div>`;
      };
      switch(s){
        case 'summary': if(d.summary) html+=block('Summary',`<p style="margin:0;color:#475569;font-size:0.88em;line-height:1.55">${nl2br(esc(d.summary))}</p>`); break;
        case 'experience': html+=block('Experience',expTimeline(d.experience,{...t2,primary:col})); break;
        case 'education': html+=block('Education',eduHTML(d.education,{...t2,primary:col})); break;
        case 'skills': if(!opts._skipSkills) html+=block('Skills',skillsCategorized(d.skills,{...t2,primary:col},'tags')); break;
        case 'projects': if(d.projects&&d.projects.length) html+=block('Projects',projectCards(d.projects,{...t2,primary:col})); break;
        case 'certifications': if(d.certifications&&d.certifications.length) html+=block('Certifications',simpleList(d.certifications,{...t2,primary:col})); break;
        case 'awards': if(d.awards&&d.awards.length) html+=block('Awards',simpleList(d.awards,{...t2,primary:col})); break;
        case 'languages': if(!opts._skipLangs&&d.languages&&d.languages.length) html+=block('Languages',skillsHTML(d.languages,{...t2,primary:col},'dots')); break;
        case 'volunteer': if(d.volunteer&&d.volunteer.length) html+=block('Volunteer',simpleList(d.volunteer,{...t2,primary:col})); break;
        case 'custom': if(d.customSections) d.customSections.forEach(cs=>{if(cs.enabled!==false) html+=block(cs.label||'Other',`<div style="font-size:0.86em;color:#475569;line-height:1.6">${richBlock(cs.content||'')}</div>`);}); break;
      }
    });
    return html;
  };
  return `<div style="${rootStyle(t,'padding:0;')}">
    <div style="padding:30px 28px;background:linear-gradient(135deg,#ff6b6b,#feca57,#48dbfb,#ff9ff3);color:#1e293b">
      <h1 style="margin:0;font-size:2em;font-weight:900">${esc(d.name)}</h1>
      ${d.title?`<div style="font-size:1em;margin-top:6px;font-weight:600">${esc(d.title)}</div>`:''}
      <div style="margin-top:10px;font-size:0.82em;opacity:0.8">${contactLine(d)}</div>
    </div>
    <div style="padding:20px 24px">${vibrantSections(d,t,{})}</div>
  </div>`;
};

// 12. Corporate — Clean grid with avatar
TEMPLATES.corporate = function(d,t){
  return `<div style="${rootStyle(t)}">
    <div style="display:grid;grid-template-columns:auto 1fr;gap:22px;align-items:center;padding:20px;border-radius:12px;background:linear-gradient(135deg,${t.primary}08,${t.secondary||t.primary}05);margin-bottom:24px">
      ${avatar(72,t,d.name)}
      <div>
        <h1 style="margin:0;color:#1e293b;font-size:1.55em;font-weight:800">${esc(d.name)}</h1>
        ${d.title?`<div style="color:${t.primary};font-size:0.92em;margin-top:4px;font-weight:600">${esc(d.title)}</div>`:''}
        <div style="margin-top:8px">${contactPills(d,t,false)}</div>
      </div>
    </div>
    ${renderSections(d,t,{skillMode:'dots',sectionVariant:'accent-bar',expStyle:'cards'})}
  </div>`;
};

// 13. Academic — Publication style
TEMPLATES.academic = function(d,t){
  return `<div style="${rootStyle(t)}">
    <div style="text-align:center;margin-bottom:26px">
      <div style="font-size:0.7em;color:#94a3b8;text-transform:uppercase;letter-spacing:4px;margin-bottom:8px">Curriculum Vitae</div>
      <h1 style="margin:0;font-size:1.75em;font-weight:700;color:#1e293b;font-family:'Playfair Display',serif">${esc(d.name)}</h1>
      ${d.title?`<div style="font-size:0.9em;color:#64748b;margin-top:6px;font-style:italic">${esc(d.title)}</div>`:''}
      <div style="width:60%;height:1px;background:linear-gradient(90deg,transparent,${t.primary},transparent);margin:14px auto"></div>
      <div style="font-size:0.78em;color:#94a3b8">${contactLine(d)}</div>
    </div>
    ${renderSections(d,t,{skillMode:'dots',sectionVariant:'underline',expStyle:'cards'})}
  </div>`;
};

// 14. Designer — Magazine layout
TEMPLATES.designer = function(d,t){
  return `<div data-rb-layout="flex-sidebar" style="${rootStyle(t,'display:flex;padding:0;min-height:100%;')}">
    <div data-rb-sidebar="1" style="width:32%;background:#fafafa;padding:30px 22px;border-right:1px solid #e2e8f0;flex-shrink:0">
      <div style="margin:0 auto 18px;width:fit-content">${avatar(90,t,d.name)}</div>
      <div style="text-align:center;margin-bottom:22px">
        <h1 style="margin:0;font-size:1.15em;font-weight:800;color:#1e293b">${esc(d.name)}</h1>
        ${d.title?`<div style="color:${t.primary};font-size:0.78em;margin-top:6px;font-weight:600;line-height:1.4">${esc(d.title)}</div>`:''}
      </div>
      <div style="font-size:0.76em;color:#64748b;line-height:1.8;margin-bottom:22px">
        ${d.email?`<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><span style="color:${t.primary}">✉</span>${esc(d.email)}</div>`:''}
        ${d.phone?`<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><span style="color:${t.primary}">📞</span>${esc(d.phone)}</div>`:''}
        ${d.location?`<div style="display:flex;gap:8px;align-items:center"><span style="color:${t.primary}">📍</span>${esc(d.location)}</div>`:''}
      </div>
      ${sectionEnabled(d,'skills')?`${secTitle('Expertise',t,'sidebar')}${sidebarSkills(d.skills,t,false)}`:''}
      ${sectionEnabled(d,'languages')&&d.languages&&d.languages.length?`<div style="margin-top:20px">${secTitle('Languages',t,'sidebar')}${d.languages.filter(l=>l.enabled!==false).map(l=>skillProficiencyRow(l.name,l.level,t,false)).join('')}</div>`:''}
    </div>
    <div data-rb-main="1" style="flex:1;padding:30px 28px;min-width:0">
      ${renderSections(d,t,{skillMode:'tags',sectionVariant:'accent-bar',_skipSkills:true,_skipLangs:true})}
    </div>
  </div>`;
};

// 15. Startup — Soft cards & rounded
TEMPLATES.startup = function(d,t){
  return `<div style="${rootStyle(t,'background:#f8fafc;padding:20px;')}">
    <div style="padding:28px 26px;background:#fff;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,0.06);margin-bottom:20px;border:1px solid #e2e8f0">
      <div style="display:flex;align-items:center;gap:18px">
        ${avatar(64,t,d.name)}
        <div>
          <h1 style="margin:0;font-size:1.6em;font-weight:800;color:#1e293b">${esc(d.name)}</h1>
          ${d.title?`<div style="color:${t.primary};font-size:0.9em;margin-top:4px;font-weight:600">${esc(d.title)}</div>`:''}
        </div>
      </div>
      ${contactPills(d,t,false)}
    </div>
    <div style="background:#fff;border-radius:16px;padding:24px 26px;box-shadow:0 2px 12px rgba(0,0,0,0.04);border:1px solid #e2e8f0">
      ${renderSections(d,t,{skillMode:'tags',sectionVariant:'pill',expStyle:'timeline'})}
    </div>
  </div>`;
};

const TEMPLATE_LIST = [
  {id:'classic',name:'Classic Pro',desc:'Centered header with avatar & accent line',emoji:'📄'},
  {id:'modern',name:'Modern Hero',desc:'Gradient split header with contact pills',emoji:'🔷'},
  {id:'minimal',name:'Editorial',desc:'Left accent strip, clean typography',emoji:'⬜'},
  {id:'bold',name:'Bold Impact',desc:'Full-width hero with geometric shapes',emoji:'🅱️'},
  // {id:'creative',name:'Dark Sidebar',desc:'Two-column dark/light contrast layout',emoji:'🎨'},
  {id:'executive',name:'Executive',desc:'Structured premium business layout',emoji:'💼'},
  // {id:'tech',name:'Dev Terminal',desc:'Code-style header, dark theme body',emoji:'💻'},
  {id:'gradient',name:'Mesh Gradient',desc:'Vivid gradient hero with mesh overlay',emoji:'🌈'},
  {id:'elegant',name:'Elegant Serif',desc:'Luxury serif with ornamental dividers',emoji:'✨'},
  {id:'compact',name:'Two-Column',desc:'Dense dual-column efficient layout',emoji:'📦'},
  {id:'vibrant',name:'Color Blocks',desc:'Each section in its own color block',emoji:'🎭'},
  {id:'corporate',name:'Corporate Grid',desc:'Avatar card header with pill contacts',emoji:'🏢'},
  {id:'academic',name:'Academic CV',desc:'Publication-style formal layout',emoji:'🎓'},
  // {id:'designer',name:'Magazine',desc:'Portfolio sidebar with expertise bars',emoji:'🖌️'},
  {id:'startup',name:'Startup Card',desc:'Soft shadows, rounded card sections',emoji:'🚀'},
];

window.ResumeTemplates = TEMPLATES;
window.ResumeTemplateList = TEMPLATE_LIST;
})();
