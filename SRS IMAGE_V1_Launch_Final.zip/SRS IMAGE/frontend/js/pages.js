'use strict';
window.Pages = {
  ...window.PagesImage,
  ...window.PagesNew,
  ...window.PagesPdf
};
