'use strict';
// This file can be empty since I defined PagesPdf in pages_new.js to save tokens.
console.log('pages_pdf.js loaded');
