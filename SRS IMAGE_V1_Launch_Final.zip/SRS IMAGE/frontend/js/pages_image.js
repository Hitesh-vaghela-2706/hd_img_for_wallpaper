'use strict';
const { useState } = React;
const C = window.Components;

window.GenericToolPage = function({ title, endpoint, fileLimit=1, options=[], requireFile=true }) {
  const [files, setFiles] = useState([]);
  const [opts, setOpts] = useState({});
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  const buildFormData = () => {
    const fd = new FormData();
    files.forEach(f => fd.append(fileLimit > 1 ? 'files' : 'file', f));
    options.forEach(opt => {
      const val = opts[opt.key] !== undefined ? opts[opt.key] : opt.default;
      fd.append(opt.key, val);
    });
    return fd;
  };

  React.useEffect(() => {
    if (requireFile && files.length > 0 && options.length > 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        try {
          const res = await fetch('/api' + endpoint, { method: 'POST', body: buildFormData() });
          if(res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if(old) URL.revokeObjectURL(old); return url; });
          }
        } catch(e) {}
      }, 500);
    }
  }, [opts, files]);

  React.useEffect(() => {
    return () => { if(previewUrl) URL.revokeObjectURL(previewUrl); }
  }, [previewUrl]);

  const handleRun = () => {
    if(requireFile && !files.length) return;
    process(endpoint, buildFormData());
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">{title}</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 350px', margin:0}}>
          {requireFile && <C.DropZone multiple={fileLimit>1} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setFiles(f.slice(0, fileLimit));
          }} />}
          {requireFile && <C.FileList files={files} onRemove={i => setFiles(fs=>fs.filter((_,j)=>i!==j))} />}
          
          {(!requireFile || files.length > 0) && options.length > 0 && (
            <div className="controls-grid" style={{marginTop:20}}>
              {options.map(opt => (
                <C.FormGroup key={opt.key} label={opt.label}>
                  {opt.type === 'select' ? (
                    <select className="form-select" value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} onChange={e=>setOpts({...opts, [opt.key]:e.target.value})}>
                      {opt.choices.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                  ) : opt.type === 'number' ? (
                    <input type="number" className="form-input" value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} onChange={e=>setOpts({...opts, [opt.key]:e.target.value})} />
                  ) : opt.type === 'text' ? (
                    <input type="text" className="form-input" value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} onChange={e=>setOpts({...opts, [opt.key]:e.target.value})} />
                  ) : opt.type === 'color' ? (
                    <div style={{display:'flex', gap:10, alignItems:'center'}}>
                      <input type="color" className="form-color" value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} onChange={e=>setOpts({...opts, [opt.key]:e.target.value})} style={{width:50, height:40, padding:0, cursor:'pointer'}} />
                      <input type="text" className="form-input" value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} onChange={e=>setOpts({...opts, [opt.key]:e.target.value})} style={{flex:1}} />
                    </div>
                  ) : opt.type === 'slider' ? (
                    <C.Slider value={opts[opt.key]!==undefined?opts[opt.key]:opt.default} min={opt.min} max={opt.max} onChange={v=>setOpts({...opts, [opt.key]:v})} displayValue={opts[opt.key]!==undefined?opts[opt.key]:opt.default} />
                  ) : null}
                </C.FormGroup>
              ))}
            </div>
          )}
          
          <div className="action-row" style={{marginTop:20}}>
            <button className="btn btn-primary" onClick={handleRun} disabled={requireFile && !files.length}>Process & Download</button>
          </div>

          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}
          
          {resultUrl && (
            <div style={{marginTop:24, textAlign:'center'}}>
              <h3 style={{marginBottom:15}}>Success!</h3>
              <div style={{display:'flex', gap:10, justifyContent:'center', alignItems:'center'}}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename(title, files)} />
                <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); setOpts({}); setPreviewUrl(''); }}>Process Another</button>
              </div>
            </div>
          )}
        </div>

        {requireFile && files.length > 0 && (
          <div className="tool-card" style={{flex:'2 1 400px', margin:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center'}}>
             <h3 style={{marginBottom:15}}>Live Preview</h3>
             {previewUrl ? (
                <img src={previewUrl} style={{maxWidth:'100%', maxHeight:'600px', objectFit:'contain', borderRadius:8}} />
             ) : (
                <img src={URL.createObjectURL(files[0])} style={{maxWidth:'100%', maxHeight:'600px', objectFit:'contain', borderRadius:8}} onLoad={e=>URL.revokeObjectURL(e.target.src)} />
             )}
          </div>
        )}
      </div>
    </div>
  );
};

window.CropToolPage = function({ title="Crop Image", endpoint="/image/crop" }) {
  const [file, setFile] = useState(null);
  const [imgUrl, setImgUrl] = useState('');
  const [imgLoaded, setImgLoaded] = useState(false);
  const imgRef = React.useRef(null);
  const cropperRef = React.useRef(null);
  const [cropperReady, setCropperReady] = useState(false);
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  React.useEffect(() => {
    if (!file) {
      setImgUrl('');
      setImgLoaded(false);
      return;
    }
    const url = URL.createObjectURL(file);
    setImgUrl(url);
    setImgLoaded(false);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const handleRun = () => {
    if (!cropperRef.current || !cropperReady || !file) return;
    const data = cropperRef.current.getData(true);
    const fd = new FormData();
    fd.append('file', file);
    fd.append('left', Math.round(Math.max(0, data.x)));
    fd.append('top', Math.round(Math.max(0, data.y)));
    fd.append('right', Math.round(data.x + data.width));
    fd.append('bottom', Math.round(data.y + data.height));
    process(endpoint, fd);
  };

  React.useEffect(() => {
    setCropperReady(false);
    if (!file || !imgUrl || !imgLoaded || !imgRef.current) return;
    if (cropperRef.current) cropperRef.current.destroy();
    cropperRef.current = new Cropper(imgRef.current, {
      viewMode: 1,
      autoCropArea: 1,
      responsive: true,
      background: false,
      ready() { setCropperReady(true); },
    });
    return () => {
      if (cropperRef.current) {
        cropperRef.current.destroy();
        cropperRef.current = null;
      }
    };
  }, [file, imgUrl, imgLoaded]);

  const setRatio = (ratio) => {
    if (cropperRef.current) cropperRef.current.setAspectRatio(ratio);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">{title}</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 300px', margin:0}}>
           <C.DropZone multiple={false} onFiles={f => {
             const sizeErr = C.validateFiles(f);
             if (sizeErr) { setError(sizeErr); return; }
             setFile(f[0]);
             reset();
           }} />
           {file && (
             <div style={{marginTop:20}}>
               <h4>Aspect Ratios</h4>
               <div style={{display:'flex', gap:10, flexWrap:'wrap', marginTop:10}}>
                 <button className="btn btn-outline" onClick={()=>setRatio(NaN)}>Free</button>
                 <button className="btn btn-outline" onClick={()=>setRatio(1)}>1:1</button>
                 <button className="btn btn-outline" onClick={()=>setRatio(16/9)}>16:9</button>
                 <button className="btn btn-outline" onClick={()=>setRatio(9/16)}>9:16</button>
                 <button className="btn btn-outline" onClick={()=>setRatio(4/3)}>4:3</button>
               </div>
               <div className="action-row" style={{marginTop:15}}>
                 <button className="btn btn-primary" onClick={handleRun} disabled={!cropperReady || loading}>Process & Download</button>
               </div>
             </div>
           )}
           {loading && <C.Progress value={progress} />}
           {error && <C.Alert type="error">{error}</C.Alert>}
           {resultUrl && (
             <div style={{marginTop:20, textAlign:'center'}}>
               <h3 style={{marginBottom:10}}>Success!</h3>
               <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename(title, [file])} />
             </div>
           )}
        </div>
        {file && imgUrl && (
          <div className="tool-card" style={{flex:'2 1 500px', margin:0, display:'flex', justifyContent:'center'}}>
             <div style={{maxHeight:'600px', maxWidth:'100%'}}>
                <img ref={imgRef} src={imgUrl} onLoad={() => setImgLoaded(true)} style={{maxWidth:'100%', display:'block'}} />
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* Remove Watermark — disabled (upcoming tool)
window.RemoveWatermarkPage = function() {
  const [file, setFile] = useState(null);
  const [imgUrl, setImgUrl] = useState('');
  const [watermarkText, setWatermarkText] = useState('');
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();

  React.useEffect(() => {
    if (!file) {
      setImgUrl('');
      return;
    }
    const url = URL.createObjectURL(file);
    setImgUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const handleRun = () => {
    if (!file) return;
    if (!watermarkText.trim()) {
      setError('Please enter the watermark text to remove.');
      return;
    }
    const fd = new FormData();
    fd.append('file', file);
    fd.append('text', watermarkText.trim());
    process('/image/remove-watermark', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Remove Watermark</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 350px', margin:0}}>
          <C.DropZone multiple={false} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setWatermarkText('');
            setFile(f[0]);
          }} />
          {file && (
            <>
              <C.FormGroup label="Watermark text to remove">
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. test, CONFIDENTIAL, DRAFT"
                  value={watermarkText}
                  onChange={e => setWatermarkText(e.target.value)}
                />
              </C.FormGroup>
              <p style={{fontSize:13, color:'var(--text-muted)', marginTop:8, lineHeight:1.5}}>
                Enter the exact watermark text. The tool will automatically find and remove it — no manual selection needed.
              </p>
              <div className="action-row" style={{marginTop:16}}>
                <button
                  className="btn btn-primary"
                  onClick={handleRun}
                  disabled={loading || !watermarkText.trim()}
                >
                  Remove Watermark & Download
                </button>
              </div>
            </>
          )}
          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}
          {resultUrl && file && (
            <div style={{marginTop:24, textAlign:'center'}}>
              <h3 style={{marginBottom:12}}>Watermark Removed</h3>
              <img
                src={resultUrl}
                alt="Cleaned result"
                style={{maxWidth:'100%', maxHeight:320, objectFit:'contain', borderRadius:8, marginBottom:12}}
              />
              <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename('Remove Watermark', [file])} />
            </div>
          )}
        </div>
        {file && imgUrl && (
          <div className="tool-card" style={{flex:'2 1 400px', margin:0, display:'flex', flexDirection:'column', alignItems:'center'}}>
            <h3 style={{marginBottom:12}}>Original Image</h3>
            <img
              src={imgUrl}
              alt="Original"
              style={{maxWidth:'100%', maxHeight:560, objectFit:'contain', borderRadius:8}}
            />
          </div>
        )}
      </div>
    </div>
  );
};
*/

window.RotateToolPage = function() {
  const [file, setFile] = useState(null);
  const [angle, setAngle] = useState(0);
  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  const rotate = (deg) => {
    setAngle(a => {
      let next = (a + deg) % 360;
      if (next < 0) next += 360;
      return next;
    });
  };

  React.useEffect(() => {
    if (file && angle !== 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const fd = new FormData();
        fd.append('file', file);
        fd.append('angle', angle);
        try {
          const res = await fetch('/api/image/rotate', { method: 'POST', body: fd });
          if(res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if(old) URL.revokeObjectURL(old); return url; });
          }
        } catch(e) {}
      }, 300);
    } else if (file && angle === 0) {
      setPreviewUrl('');
    }
  }, [file, angle]);

  const handleRun = () => {
    if(!file) return;
    const fd = new FormData();
    fd.append('file', file);
    fd.append('angle', angle);
    process('/image/rotate', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Rotate Image</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 300px', margin:0}}>
           <C.DropZone multiple={false} onFiles={f => {
             const sizeErr = C.validateFiles(f);
             if (sizeErr) { setError(sizeErr); return; }
             setFile(f[0]); setAngle(0); reset();
           }} />
           {file && (
             <div style={{marginTop:20}}>
               <div style={{display:'flex', gap:20, justifyContent:'center'}}>
                 <button className="btn btn-outline" style={{fontSize:24, padding:'10px 20px'}} onClick={()=>rotate(-90)}>↺</button>
                 <button className="btn btn-outline" style={{fontSize:24, padding:'10px 20px'}} onClick={()=>rotate(90)}>↻</button>
               </div>
               <div style={{textAlign:'center', marginTop:15, fontSize:18, fontWeight:600}}>Angle: {angle}°</div>
               <div className="action-row" style={{marginTop:20}}>
                 <button className="btn btn-primary" onClick={handleRun}>Process & Download</button>
               </div>
             </div>
           )}
           {loading && <C.Progress value={progress} />}
           {error && <C.Alert type="error">{error}</C.Alert>}
           {resultUrl && (
             <div style={{marginTop:20, textAlign:'center'}}>
               <h3 style={{marginBottom:10}}>Success!</h3>
               <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Rotate Image", [file])} />
             </div>
           )}
        </div>
        {file && (
          <div className="tool-card" style={{flex:'2 1 500px', margin:0, display:'flex', justifyContent:'center', alignItems:'center'}}>
             <img src={previewUrl ? previewUrl : URL.createObjectURL(file)} style={{maxWidth:'100%', maxHeight:'600px', objectFit:'contain', borderRadius:8}} />
          </div>
        )}
      </div>
    </div>
  );
};

window.CompressImagePage = function() {
  const [files, setFiles] = useState([]);
  const [quality, setQuality] = useState(75);
  const [format, setFormat] = useState('same');
  const [useTargetSize, setUseTargetSize] = useState(false);
  const [targetSize, setTargetSize] = useState('');
  const [targetUnit, setTargetUnit] = useState('kb');

  const { loading, progress, error, resultUrl, process, reset, setError } = C.useFileProcessor();
  const [previewUrl, setPreviewUrl] = useState('');
  const timeoutRef = React.useRef(null);

  React.useEffect(() => {
    if (files.length > 0) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(async () => {
        const fd = new FormData();
        files.forEach(f => fd.append('file', f));
        fd.append('quality', quality);
        fd.append('output_format', format);
        if (useTargetSize && targetSize) {
          fd.append('target_size', targetSize);
          fd.append('target_unit', targetUnit);
        }
        try {
          const res = await fetch('/api/image/compress', { method: 'POST', body: fd });
          if(res.ok) {
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            setPreviewUrl(old => { if(old) URL.revokeObjectURL(old); return url; });
          }
        } catch(e) {}
      }, 500);
    }
  }, [files, quality, format, useTargetSize, targetSize, targetUnit]);

  React.useEffect(() => {
    return () => { if(previewUrl) URL.revokeObjectURL(previewUrl); }
  }, [previewUrl]);

  const handleRun = () => {
    if(!files.length) return;
    const fd = new FormData();
    files.forEach(f => fd.append('file', f));
    fd.append('quality', quality);
    fd.append('output_format', format);
    if (useTargetSize && targetSize) {
      fd.append('target_size', targetSize);
      fd.append('target_unit', targetUnit);
    }
    process('/image/compress', fd);
  };

  return (
    <div className="page-body fade-in">
      <h2 className="page-title">Compress Image</h2>
      <div style={{display:'flex', gap:20, flexWrap:'wrap', alignItems:'flex-start'}}>
        <div className="tool-card" style={{flex:'1 1 350px', margin:0}}>
          <C.DropZone multiple={false} onFiles={f => {
            const sizeErr = C.validateFiles(f);
            if (sizeErr) { setError(sizeErr); return; }
            reset();
            setFiles(f.slice(0, 1));
          }} />
          <C.FileList files={files} onRemove={i => setFiles([])} />

          {files.length > 0 && (
            <div className="controls-grid" style={{marginTop:20}}>
              <C.FormGroup label="Quality (1-100)">
                <C.Slider value={quality} min={1} max={100} onChange={setQuality} displayValue={quality} />
              </C.FormGroup>

              <C.FormGroup label="Format">
                <select className="form-select" value={format} onChange={e => setFormat(e.target.value)}>
                  <option value="same">Same</option>
                  <option value="jpeg">JPEG</option>
                  <option value="png">PNG</option>
                  <option value="webp">WEBP</option>
                </select>
              </C.FormGroup>

              <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '16px 0' }}>
                <input
                  type="checkbox"
                  id="chk-target-size"
                  checked={useTargetSize}
                  onChange={e => setUseTargetSize(e.target.checked)}
                  style={{ width: 16, height: 16, cursor: 'pointer' }}
                />
                <label htmlFor="chk-target-size" style={{ fontSize: 13, cursor: 'pointer', userSelect: 'none', color: 'var(--text-primary)', fontWeight: 600 }}>
                  Compress to specific target size
                </label>
              </div>

              {useTargetSize && (
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12, alignItems: 'end' }}>
                  <C.FormGroup label="Target Size">
                    <input
                      type="number"
                      className="form-input"
                      value={targetSize}
                      placeholder="e.g. 200"
                      onChange={e => setTargetSize(e.target.value)}
                    />
                  </C.FormGroup>
                  <C.FormGroup label="Unit">
                    <select
                      className="form-select"
                      value={targetUnit}
                      onChange={e => setTargetUnit(e.target.value)}
                    >
                      <option value="kb">KB</option>
                      <option value="mb">MB</option>
                    </select>
                  </C.FormGroup>
                </div>
              )}
            </div>
          )}

          <div className="action-row" style={{marginTop:20}}>
            <button className="btn btn-primary" onClick={handleRun} disabled={!files.length}>Process & Download</button>
          </div>

          {loading && <C.Progress value={progress} />}
          {error && <C.Alert type="error">{error}</C.Alert>}

          {resultUrl && (
            <div style={{marginTop:24, textAlign:'center'}}>
              <h3 style={{marginBottom:15}}>Success!</h3>
              <div style={{display:'flex', gap:10, justifyContent:'center', alignItems:'center'}}>
                <C.DownloadButton url={resultUrl} filename={C.getDownloadFilename("Compress Image", files)} />
                <button className="btn btn-outline" onClick={() => { reset(); setFiles([]); setQuality(75); setFormat('same'); setUseTargetSize(false); setTargetSize(''); setPreviewUrl(''); }}>Process Another</button>
              </div>
            </div>
          )}
        </div>

        {files.length > 0 && (
          <div className="tool-card" style={{flex:'2 1 400px', margin:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center'}}>
             <h3 style={{marginBottom:15}}>Live Preview</h3>
             {previewUrl ? (
                <img src={previewUrl} style={{maxWidth:'100%', maxHeight:'600px', objectFit:'contain', borderRadius:8}} />
             ) : (
                <img src={URL.createObjectURL(files[0])} style={{maxWidth:'100%', maxHeight:'600px', objectFit:'contain', borderRadius:8}} />
             )}
          </div>
        )}
      </div>
    </div>
  );
};

window.PagesImage = {
  'compress': () => <window.CompressImagePage />,
  'resize': () => <window.GenericToolPage title="Resize Image" endpoint="/image/resize" options={[
    {key:'width', label:'Width (px)', type:'number', default:''},
    {key:'height', label:'Height (px)', type:'number', default:''},
    {key:'percent', label:'Scale (%)', type:'number', default:''}
  ]} />,
  'convert': () => <window.GenericToolPage title="Convert Format" endpoint="/image/convert" options={[
    {key:'output_format', label:'Target Format', type:'select', default:'jpeg', choices:[{label:'JPEG',value:'jpeg'},{label:'PNG',value:'png'},{label:'WEBP',value:'webp'},{label:'GIF',value:'gif'},{label:'BMP',value:'bmp'}]}
  ]} />,
  'edit': () => <window.GenericToolPage title="Photo Editing" endpoint="/image/edit" options={[
    {key:'brightness', label:'Brightness', type:'slider', min:0, max:3, default:1},
    {key:'contrast', label:'Contrast', type:'slider', min:0, max:3, default:1},
    {key:'saturation', label:'Saturation', type:'slider', min:0, max:3, default:1},
    {key:'sharpness', label:'Sharpness', type:'slider', min:0, max:3, default:1}
  ]} />,
  'upscale': () => <window.GenericToolPage title="Upscale Image" endpoint="/image/upscale" options={[
    {key:'scale', label:'Scale Factor', type:'select', default:'2', choices:[{label:'2x',value:'2'},{label:'4x',value:'4'}]}
  ]} />,
  'remove-bg': () => <window.GenericToolPage title="Remove Background" endpoint="/image/remove-bg" />,
  'watermark': () => <window.GenericToolPage title="Watermark Image" endpoint="/image/watermark" options={[
    {key:'text', label:'Text', type:'text', default:'CONFIDENTIAL'},
    {key:'font_size', label:'Font Size', type:'slider', min:10, max:200, default:40},
    {key:'opacity', label:'Opacity (0-100)', type:'slider', min:0, max:100, default:50},
    {key:'rotation', label:'Rotation (Degrees)', type:'slider', min:0, max:360, default:0},
    {key:'color', label:'Color', type:'color', default:'#FFFFFF'},
    {key:'x_pct', label:'X Offset (%) [Custom]', type:'slider', min:-1, max:100, default:-1},
    {key:'y_pct', label:'Y Offset (%) [Custom]', type:'slider', min:-1, max:100, default:-1},
    {key:'position', label:'Preset Position', type:'select', default:'center', choices:[{label:'Center',value:'center'},{label:'Top Left',value:'top-left'},{label:'Bottom Right',value:'bottom-right'}]}
  ]} />,
  'rotate': () => <window.RotateToolPage />,
  'crop': () => <window.CropToolPage title="Crop Image" endpoint="/image/crop" />,
  'html-to-img': () => <window.GenericToolPage title="HTML to Image" endpoint="/image/html-to-image" requireFile={false} options={[
    {key:'url', label:'Website URL (optional)', type:'text', default:''},
    {key:'html_content', label:'HTML Content (if no URL)', type:'text', default:'<h1>Hello World</h1>'},
    {key:'width', label:'Width (px)', type:'number', default:1280},
    {key:'height', label:'Height (px)', type:'number', default:720}
  ]} />,
  'blur-face': () => <window.GenericToolPage title="Blur Face" endpoint="/image/blur-face" options={[
    {key:'blur_strength', label:'Blur Strength', type:'slider', min:1, max:50, default:25}
  ]} />
};
