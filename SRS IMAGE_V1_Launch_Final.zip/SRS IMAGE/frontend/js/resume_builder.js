'use strict';
/* ═══════════════════════════════════════
   Resume Builder — Main Component
═══════════════════════════════════════ */
(function(){
const { useState, useEffect, useLayoutEffect, useRef, useCallback } = React;

const FONTS = ['Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Raleway','Playfair Display'];
const SECTION_META = [
  {id:'summary',label:'Professional Summary',icon:'📝'},
  {id:'experience',label:'Work Experience',icon:'💼'},
  {id:'education',label:'Education',icon:'🎓'},
  {id:'skills',label:'Skills',icon:'⚡'},
  {id:'projects',label:'Projects',icon:'🚀'},
  {id:'certifications',label:'Certifications',icon:'📜'},
  {id:'awards',label:'Awards',icon:'🏆'},
  {id:'languages',label:'Languages',icon:'🌐'},
  {id:'volunteer',label:'Volunteer Work',icon:'🤝'},
  {id:'custom',label:'Custom Sections',icon:'➕'},
];

function defaultData(){
  return {
    name:'Your Name', title:'Professional Title',
    email:'email@example.com', phone:'+1 234 567 8900',
    location:'City, Country', address:'', linkedin:'linkedin.com/in/yourname', website:'',
    summary:'Dedicated professional with expertise in…',
    experience:[{id:Date.now(),title:'Job Title',company:'Company Name',location:'',date:'2020 – Present',description:'Key achievements and responsibilities.',enabled:true}],
    education:[{id:Date.now()+1,degree:'Bachelor of Science',institution:'University Name',date:'2016 – 2020',description:'',enabled:true}],
    skills:[{id:Date.now()+2,name:'Skill 1',category:'',level:4,enabled:true},{id:Date.now()+3,name:'Skill 2',category:'',level:3,enabled:true}],
    projects:[],certifications:[],awards:[],languages:[],volunteer:[],
    customSections:[],
    _sectionOrder:SECTION_META.map(s=>s.id),
    _disabled:{},
  };
}

function sampleData(){
  return {
    name:'Hitesh Rameshbhai Vaghela',
    title:'Full-Stack Software Developer | Python | Django | Geospatial Systems | AI/LLM Integration',
    email:'vhitesh927@gmail.com', phone:'+91 78741 99585',
    location:'Surendranagar, Gujarat, India',
    address:'79, Siddhinagar Society, Ganpati Fatsar, Wadhwan, Surendranagar, Gujarat 363030',
    linkedin:'', website:'',
    summary:'Full-Stack Software Developer with 1+ year of experience at BISAG-N (Government of India), contributing to national-scale geospatial and groundwater management platforms. Specialist in Python, Django, Flask, PostgreSQL, Java, and JavaScript with deep expertise in 3D data visualization (CesiumJS), geospatial systems, and high-performance SQL engineering.',
    experience:[
      {id:1,title:'Software Developer & Project Lead – WARIMS',company:'BISAG-N (Bhaskaracharya National Institute for Space Applications and Geo-Informatics)',location:'Ahmedabad, India',date:'2024 – Present',description:'<b>3D Geospatial Visualization</b><ul><li>Developed 3D Borehole Visualization for NGDR platform using CesiumJS</li><li>Built Fence Diagram visualization system for WARIMS</li><li>Implemented India boundary clipping in 3D terrain visualization</li></ul><b>Backend & Performance</b><ul><li>Optimized SQL queries handling 130M+ records, reducing response time by 75%</li><li>Integrated QuestDB with Java and Python APIs for time-series data</li><li>Resolved NGDR MaxParameter limitation across 8 modules</li></ul>',enabled:true},
      {id:2,title:'Data Science Intern',company:'Maxgen Technologies',location:'India',date:'Feb 2021 – May 2021',description:'Contributed to Plant Disease Detection & Crop Recommendation System: data cleaning, ML/DL model development, feature engineering, and deployment.',enabled:true},
      {id:3,title:'Web Development Intern',company:'Oasis Infobyte',location:'India',date:'Jun 2022 – Jul 2022',description:'Developed web applications (To-Do App, Calculator, Tribute Page) using HTML, CSS, and JavaScript.',enabled:true},
    ],
    education:[
      {id:4,degree:'B.E. Computer Engineering',institution:'L.D. College of Engineering, Ahmedabad',date:'2019 – 2023',description:'CGPA: 8.66',enabled:true},
      {id:5,degree:'HSC (GSEB)',institution:'',date:'2019',description:'84%',enabled:true},
      {id:6,degree:'SSC (GSEB)',institution:'',date:'2017',description:'90.33%',enabled:true},
    ],
    skills:[
      {id:7,name:'Python, Java, JavaScript, SQL',category:'Languages',level:5,enabled:true},
      {id:8,name:'Django, Flask, REST APIs, Spring MVC',category:'Frameworks & Backend',level:5,enabled:true},
      {id:9,name:'CesiumJS, GeoServer, QGIS, OpenLayers, OGR2OGR',category:'Geospatial & 3D Viz',level:5,enabled:true},
      {id:10,name:'PostgreSQL, QuestDB, SQL Optimization',category:'Databases',level:5,enabled:true},
      {id:11,name:'LLM Integration, PyTorch, CNN (ResNet), ML/DL',category:'AI / ML / Data',level:4,enabled:true},
      {id:12,name:'Docker, Git, Project Management',category:'DevOps & Tools',level:4,enabled:true},
    ],
    projects:[
      {id:13,title:'Bird Species Classification Web Application',date:'2023',description:'Built ML/DL web application for real-time bird species recognition using PyTorch and ResNet (CNN). Technologies: Python, HTML, CSS, JavaScript.',enabled:true},
    ],
    certifications:[],awards:[],
    languages:[{id:14,name:'English',level:5,enabled:true},{id:15,name:'Gujarati',level:5,enabled:true},{id:16,name:'Hindi',level:4,enabled:true}],
    volunteer:[],
    customSections:[],
    _sectionOrder:SECTION_META.map(s=>s.id),
    _disabled:{},
  };
}

function defaultTheme(){
  return { primary:'#2563eb', secondary:'#7c3aed', accent:'#2563eb', fontFamily:'Inter', fontSize:'medium', spacing:'standard' };
}

function saveAll(data, theme, template){
  localStorage.setItem('rb_data',JSON.stringify(data));
  localStorage.setItem('rb_theme',JSON.stringify(theme));
  localStorage.setItem('rb_tmpl',template);
}

function buildShareUrl(data, theme, template){
  const payload = JSON.stringify({d:data,t:theme,m:template});
  const hash = 'resume=' + btoa(unescape(encodeURIComponent(payload)));
  return window.location.origin + window.location.pathname + '#' + hash;
}

function parseShareHash(){
  const hash = window.location.hash;
  if(!hash.startsWith('#resume=')) return null;
  try{
    const json = decodeURIComponent(escape(atob(hash.slice(8))));
    return JSON.parse(json);
  }catch(e){ return null; }
}

/* ── Rich text helpers ── */
function normalizeRichHtml(html){
  if(!html||!String(html).trim()) return '';
  let h=String(html).trim();
  if(!/<[a-z][\s\S]*>/i.test(h)){
    return h.split('\n').map(line=>{
      const t=line.trim();
      if(!t) return '<div><br></div>';
      return '<div>'+t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</div>';
    }).join('');
  }
  h=h.replace(/<b>([^<]*)<\/b>\s*<ul>/gi,'<div class="rb-rich-heading"><b>$1</b></div><ul>');
  h=h.replace(/<\/ul>\s*<b>([^<]*)<\/b>/gi,'</ul><div class="rb-rich-heading"><b>$1</b></div>');
  return h;
}

function readRichHtml(el){
  if(!el) return '';
  return normalizeRichHtml(el.innerHTML);
}

/* ── Rich Text Editor ── */
function RichTextEditor({ value, onChange, editorKey, wordLimit }){
  const ref = useRef(null);
  const focused = useRef(false);
  useEffect(()=>{
    if(!ref.current||focused.current) return;
    let norm = normalizeRichHtml(value||'');
    if(wordLimit) norm = normalizeRichHtml(limitRichWords(norm,wordLimit));
    if(ref.current.innerHTML!==norm) ref.current.innerHTML=norm;
  },[value,editorKey,wordLimit]);
  useEffect(()=>{
    if(ref.current){
      let norm = normalizeRichHtml(value||'');
      if(wordLimit) norm = normalizeRichHtml(limitRichWords(norm,wordLimit));
      ref.current.innerHTML=norm;
    }
  },[editorKey]);
  const sync=()=>{
    if(!ref.current) return;
    let html = readRichHtml(ref.current);
    if(wordLimit) html = limitRichWords(html,wordLimit);
    if(wordLimit && ref.current.innerHTML!==normalizeRichHtml(html)){
      ref.current.innerHTML=normalizeRichHtml(html);
    }
    onChange(html);
  };
  const exec=(cmd)=>{
    document.execCommand(cmd,false,null);
    if(cmd==='insertUnorderedList') document.execCommand('insertParagraph',false,null);
    ref.current&&ref.current.focus();
    sync();
  };
  const wc = wordLimit ? countWords(value) : 0;
  return React.createElement('div',{className:'rb-rich-editor'},
    React.createElement('div',{className:'rb-rich-toolbar'},
      React.createElement('button',{type:'button',title:'Bold',onMouseDown:e=>{e.preventDefault();exec('bold');}},'B'),
      React.createElement('button',{type:'button',title:'Italic',className:'italic',onMouseDown:e=>{e.preventDefault();exec('italic');}},'I'),
      React.createElement('button',{type:'button',title:'Bullet List',onMouseDown:e=>{e.preventDefault();exec('insertUnorderedList');}},'• List'),
    ),
    React.createElement('div',{
      ref,className:'rb-rich-area',contentEditable:true,
      onFocus:()=>{focused.current=true;},
      onBlur:()=>{focused.current=false;sync();},
      onInput:sync,
      suppressContentEditableWarning:true,
    }),
    wordLimit && React.createElement('div',{className:'rb-word-count'+(wc>=wordLimit?' at-limit':'')},wc+' / '+wordLimit+' words'),
  );
}

function isSectionEnabled(disabled,id){
  return !(disabled&&disabled[id]);
}

const A4_PAGE_W = 794;
const A4_PAGE_H = 1123;
const MAX_RESUME_PAGES = 3;
const A4_PAGE_GAP = 24;
const PAGE_FOOTER_H = 32;
const PAGE_HEADER_H = 32;

const DISABLED_TEMPLATES = ['creative','tech','designer'];

function resolveTemplate(id){
  if(!id||DISABLED_TEMPLATES.indexOf(id)>=0) return 'classic';
  const list=window.ResumeTemplateList||[];
  if(list.length&&!list.some(t=>t.id===id)) return 'classic';
  return id;
}

function usablePageHeight(pageIndex){
  if(pageIndex<=0) return A4_PAGE_H-PAGE_FOOTER_H;
  return A4_PAGE_H-PAGE_HEADER_H-PAGE_FOOTER_H;
}

const WORD_LIMITS = {
  summary: 100,
  education_desc: 50,
  experience_desc: 250,
  project_desc: 250,
  certification_desc: 100,
  award_desc: 100,
  volunteer_desc: 100,
  custom_desc: 150,
};

function stripHTML(s){
  return (s||'').replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').trim();
}
function countWords(text){
  const s=stripHTML(text);
  if(!s) return 0;
  return s.split(/\s+/).filter(Boolean).length;
}
function limitPlainWords(text,max){
  const raw=String(text||'');
  const words=stripHTML(raw).split(/\s+/).filter(Boolean);
  if(words.length<=max) return raw;
  return words.slice(0,max).join(' ');
}
function limitRichWords(html,max){
  if(countWords(html)<=max) return html;
  return limitPlainWords(html,max);
}

function createA4Page(){
  const page=document.createElement('div');
  page.className='rb-a4-page';
  const inner=document.createElement('div');
  inner.className='rb-a4-page-inner';
  page.appendChild(inner);
  return page;
}

function extractStyleAndSource(rawHTML){
  const tmp=document.createElement('div');
  tmp.innerHTML=rawHTML||'';
  const styleEl=tmp.querySelector('style');
  const styleHTML=styleEl?styleEl.outerHTML:'';
  const sourceEl=tmp.querySelector('.rb-resume-source');
  const sourceHTML=sourceEl?sourceEl.innerHTML:tmp.innerHTML.replace(styleHTML,'');
  return {styleHTML,sourceHTML};
}

function createMeasureHost(sourceHTML){
  const measureHost=document.createElement('div');
  measureHost.className='rb-measure-host';
  measureHost.style.cssText='position:fixed;left:0;top:0;width:'+A4_PAGE_W+'px;opacity:0;pointer-events:none;z-index:-1;overflow:visible;';
  const measureContent=document.createElement('div');
  measureContent.className='rb-resume-full';
  measureContent.style.cssText='width:'+A4_PAGE_W+'px;box-sizing:border-box;';
  measureContent.innerHTML=sourceHTML;
  measureHost.appendChild(measureContent);
  document.body.appendChild(measureHost);
  return measureHost;
}

function measureEl(el,rootTop){
  const r=el.getBoundingClientRect();
  const top=Math.round(r.top-rootTop);
  const height=el.offsetHeight;
  return {el,top,height,bottom:top+height};
}

function collectFromBlock(block,rootTop){
  const blockH=block.offsetHeight;
  const entries=block.querySelectorAll('[data-rb-entry]');
  const maxH=usablePageHeight(0);
  if(blockH<=maxH||entries.length<2) return [measureEl(block,rootTop)];
  const titleEl=block.querySelector('h3');
  const out=[];
  entries.forEach((entry,idx)=>{
    const eMet=measureEl(entry,rootTop);
    if(idx===0&&titleEl){
      const tMet=measureEl(titleEl,rootTop);
      out.push({el:block,top:tMet.top,bottom:eMet.bottom,height:eMet.bottom-tMet.top});
    }else{
      out.push(eMet);
    }
  });
  return out;
}

function walkUnits(el,rootTop,units,insideMain){
  if(!el||el.nodeType!==1) return;
  if(el.hasAttribute('data-rb-block')){
    units.push(...collectFromBlock(el,rootTop));
    return;
  }
  const children=Array.from(el.children).filter(c=>c.nodeType===1);
  if(!children.length){
    if(!insideMain) units.push(measureEl(el,rootTop));
    return;
  }
  const directBlocks=children.filter(c=>c.hasAttribute('data-rb-block'));
  if(directBlocks.length){
    children.forEach(c=>{
      if(c.hasAttribute('data-rb-block')) walkUnits(c,rootTop,units,insideMain);
      else if(c.hasAttribute('data-rb-sidebar')) units.push(measureEl(c,rootTop));
      else if(c.hasAttribute('data-rb-main')) walkUnits(c,rootTop,units,true);
      else if(!c.querySelector('[data-rb-block]')&&!insideMain) units.push(measureEl(c,rootTop));
      else walkUnits(c,rootTop,units,insideMain);
    });
    return;
  }
  if(children.length===1){ walkUnits(children[0],rootTop,units,insideMain); return; }
  children.forEach(c=>{
    if(c.hasAttribute('data-rb-sidebar')&&!insideMain) units.push(measureEl(c,rootTop));
    else if(c.hasAttribute('data-rb-main')) walkUnits(c,rootTop,units,true);
    else if(c.querySelector('[data-rb-block]')||c.querySelector('[data-rb-main]')) walkUnits(c,rootTop,units,insideMain);
    else if(!insideMain) units.push(measureEl(c,rootTop));
  });
}

function buildContinuationHTML(root,main,sidebar){
  let rootStyle=(root.getAttribute('style')||'');
  if(!/display\s*:\s*flex/i.test(rootStyle)) rootStyle+='display:flex;';
  rootStyle=rootStyle.replace(/min-height\s*:\s*100%[^;]*;?/gi,'');
  let mainStyle=(main.getAttribute('style')||'');
  if(!/flex\s*:\s*1/i.test(mainStyle)&&!/width\s*:/i.test(mainStyle)) mainStyle+='flex:1;';
  mainStyle+='min-width:0;box-sizing:border-box;';
  let spacerStyle='flex-shrink:0;background:transparent;min-height:1px;';
  if(sidebar){
    const sw=sidebar.offsetWidth;
    if(sw>0) spacerStyle+='width:'+sw+'px;';
    else{
      const sbStyle=sidebar.getAttribute('style')||'';
      const pct=sbStyle.match(/width\s*:\s*(\d+(?:\.\d+)?%)/i);
      spacerStyle+='width:'+(pct?pct[1]:'34%')+';';
    }
  }else{
    spacerStyle+='width:34%;';
  }
  return '<div data-rb-continuation="1" style="'+rootStyle+'padding:0;box-sizing:border-box;min-height:0;">'+
    '<div data-rb-sidebar-spacer="1" aria-hidden="true" style="'+spacerStyle+'"></div>'+
    '<div data-rb-main="1" style="'+mainStyle+'">'+main.innerHTML+'</div></div>';
}

function getLayoutInfo(sourceHTML){
  const measureHost=createMeasureHost(sourceHTML);
  const measureContent=measureHost.querySelector('.rb-resume-full');
  const root=measureContent&&measureContent.firstElementChild;
  if(!root){
    document.body.removeChild(measureHost);
    return {units:[],hasSidebar:false};
  }
  const rootTop=measureContent.getBoundingClientRect().top;
  const layoutType=root.getAttribute('data-rb-layout')||'';
  const main=root.querySelector('[data-rb-main]');
  const sidebar=root.querySelector('[data-rb-sidebar]');
  const isFlexSidebar=layoutType==='flex-sidebar'&&!!(main&&sidebar);
  const isGrid2Col=layoutType==='grid-2col';

  let chromeUnits=[];
  let mainUnits=[];

  if(isGrid2Col){
    walkUnits(root,rootTop,mainUnits,false);
    document.body.removeChild(measureHost);
    return {
      units:mainUnits.sort((a,b)=>a.top-b.top||a.bottom-b.bottom),
      layoutType:'grid-2col',
      hasSidebar:false,
    };
  }

  if(isFlexSidebar){
    function walkChrome(el){
      if(!el||el.nodeType!==1) return;
      if(main&&(el===main||main.contains(el))) return;
      if(sidebar&&el===sidebar){ chromeUnits.push(measureEl(el,rootTop)); return; }
      if(sidebar&&sidebar.contains(el)) return;
      const children=Array.from(el.children).filter(c=>c.nodeType===1);
      if(!children.length){ chromeUnits.push(measureEl(el,rootTop)); return; }
      children.forEach(walkChrome);
    }
    Array.from(root.children).forEach(walkChrome);
    walkUnits(main,rootTop,mainUnits,true);
    const mainTop=measureEl(main,rootTop).top;
    const continuationHTML=buildContinuationHTML(root,main,sidebar);
    document.body.removeChild(measureHost);
    return {
      units:mainUnits.sort((a,b)=>a.top-b.top||a.bottom-b.bottom),
      chromeUnits,
      layoutType:'flex-sidebar',
      hasSidebar:true,
      mainTop,
      continuationHTML,
      sidebarUnit:sidebar?measureEl(sidebar,rootTop):null,
    };
  }

  walkUnits(root,rootTop,mainUnits,false);
  document.body.removeChild(measureHost);
  return {
    units:mainUnits.sort((a,b)=>a.top-b.top||a.bottom-b.bottom),
    layoutType:'single',
    hasSidebar:false,
  };
}

function packUnitsIntoPages(units,layout){
  const chromeUnits=layout.chromeUnits||[];
  const isFlexSidebar=layout.layoutType==='flex-sidebar';
  const pages=[];

  if(!units.length&&!chromeUnits.length){
    return {pages:[{start:0,end:usablePageHeight(0),isContinuation:false}],truncated:false};
  }

  let i=0;
  const chromeBottom=chromeUnits.reduce((m,c)=>Math.max(m,c.bottom),0);

  if(units.length||chromeUnits.length){
    const usable0=usablePageHeight(0);
    let packedEnd=isFlexSidebar?0:chromeBottom;
    let j=0;

    while(j<units.length){
      const u=units[j];
      if(u.top>=usable0) break;
      const trialMain=Math.max(packedEnd,u.bottom);
      if(trialMain>usable0) break;
      packedEnd=trialMain;
      j++;
    }

    if(j===0&&units.length){
      packedEnd=Math.min(units[0].bottom,usable0);
      j=1;
    }else if(!units.length){
      packedEnd=Math.max(chromeBottom,1);
    }

    pages.push({start:0,end:Math.max(packedEnd,1),isContinuation:false});
    i=j;
  }

  while(i<units.length&&pages.length<MAX_RESUME_PAGES){
    const pageIdx=pages.length;
    const usable=usablePageHeight(pageIdx);
    const pageStart=units[i].top;
    let packedEnd=pageStart;
    let j=i;

    while(j<units.length){
      const trial=Math.max(packedEnd,units[j].bottom);
      if(trial-pageStart>usable&&j>i) break;
      packedEnd=trial;
      j++;
    }

    if(j===i){
      packedEnd=Math.min(units[i].bottom,pageStart+usable);
      j=i+1;
    }

    pages.push({start:pageStart,end:packedEnd,isContinuation:isFlexSidebar});
    i=j;
  }

  const truncated=i<units.length;
  return {pages:pages.slice(0,MAX_RESUME_PAGES),truncated};
}

/* Section-aware viewport slices — clip at unit boundaries, no duplicate sections */
function renderA4Pages(frame,rawHTML,opts){
  opts=opts||{};
  const forExport=!!opts.forExport;
  const {styleHTML,sourceHTML}=extractStyleAndSource(rawHTML||'');
  const layout=getLayoutInfo(sourceHTML);
  let {pages,truncated}=packUnitsIntoPages(layout.units,layout);

  if(!pages.length){
    const measureHost=createMeasureHost(sourceHTML);
    const totalH=measureHost.querySelector('.rb-resume-full').scrollHeight;
    document.body.removeChild(measureHost);
    let offset=0;
    pages=[];
    for(let idx=0;idx<MAX_RESUME_PAGES&&offset<totalH;idx++){
      const usable=usablePageHeight(idx);
      const end=Math.min(offset+usable,totalH);
      pages.push({start:offset,end,isContinuation:false});
      offset=end;
    }
    truncated=offset<totalH;
  }

  const pageCount=pages.length;

  frame.innerHTML='';
  if(styleHTML){
    const sh=document.createElement('div');
    sh.innerHTML=styleHTML;
    if(sh.firstChild) frame.appendChild(sh.firstChild);
  }

  const stack=document.createElement('div');
  stack.className='rb-pages-stack'+(forExport?' rb-pages-stack-export':'');

  for(let i=0;i<pageCount;i++){
    const pg=pages[i];
    const page=createA4Page();
    if(forExport) page.classList.add('rb-a4-export-page');
    const inner=page.querySelector('.rb-a4-page-inner');
    inner.style.height=A4_PAGE_H+'px';
    inner.style.maxHeight=A4_PAGE_H+'px';
    inner.style.display='flex';
    inner.style.flexDirection='column';
    inner.style.boxSizing='border-box';
    inner.style.padding='0';
    inner.style.overflow='hidden';

    if(i>0){
      const hdr=document.createElement('div');
      hdr.className='rb-page-margin-header';
      hdr.setAttribute('aria-hidden','true');
      inner.appendChild(hdr);
    }

    const usable=usablePageHeight(i);
    const contentSpan=Math.max(1,pg.end-pg.start);
    const clipH=Math.min(usable,contentSpan);
    const isLastPage=i===pageCount-1;
    const viewportH=forExport?usable:(isLastPage?clipH:usable);

    const viewport=document.createElement('div');
    viewport.className='rb-page-viewport';
    viewport.style.height=viewportH+'px';

    const clipbox=document.createElement('div');
    clipbox.className='rb-page-clip';
    clipbox.style.height=clipH+'px';

    const useContinuation=i>0&&pg.isContinuation&&layout.continuationHTML&&layout.layoutType==='flex-sidebar';
    const html=useContinuation?layout.continuationHTML:sourceHTML;
    const offsetY=useContinuation?-(pg.start-(layout.mainTop||0)):-pg.start;

    const slice=document.createElement('div');
    slice.className='rb-resume-slice'+(useContinuation?' rb-resume-slice-cont':'');
    if(forExport){
      slice.style.cssText='width:'+A4_PAGE_W+'px;box-sizing:border-box;transform:translateY('+offsetY+'px);';
    }else{
      slice.style.cssText='width:'+A4_PAGE_W+'px;box-sizing:border-box;margin-top:'+offsetY+'px;';
    }
    slice.innerHTML=html;
    clipbox.appendChild(slice);
    viewport.appendChild(clipbox);
    inner.appendChild(viewport);

    const ftr=document.createElement('div');
    ftr.className='rb-page-margin-footer';
    ftr.setAttribute('aria-hidden','true');
    inner.appendChild(ftr);

    page.setAttribute('data-page',String(i+1));
    if(!forExport){
      const label=document.createElement('div');
      label.className='rb-page-number';
      label.textContent='Page '+(i+1)+' of '+pageCount;
      page.appendChild(label);
    }
    stack.appendChild(page);
  }

  frame.appendChild(stack);
  frame.dataset.pageCount=String(pageCount);
  frame.dataset.truncated=truncated?'1':'0';
  if(!forExport) frame.style.minHeight=(pageCount*A4_PAGE_H+(pageCount-1)*A4_PAGE_GAP)+'px';
  return {pageCount,truncated,pages,layout,sourceHTML,styleHTML};
}

function paginateA4Preview(frame,rawHTML){
  if(!frame) return {pageCount:1,truncated:false};
  const result=renderA4Pages(frame,rawHTML,{forExport:false});
  return {pageCount:result.pageCount,truncated:result.truncated};
}

async function exportPagesToPDF(_pageEls,filename,rawHTML){
  if(!rawHTML) throw new Error('No resume content to export');
  if(!window.html2canvas&&!window.html2pdf) throw new Error('PDF libraries not loaded. Please refresh the page.');

  const jsPDFCls=(window.jspdf&&window.jspdf.jsPDF)||window.jsPDF||null;

  async function pageToCanvas(el){
    const scale=2;
    const opts={
      scale,useCORS:true,allowTaint:true,logging:false,
      width:A4_PAGE_W,height:A4_PAGE_H,
      windowWidth:A4_PAGE_W,windowHeight:A4_PAGE_H,
      backgroundColor:'#ffffff',
    };
    if(typeof window.html2canvas==='function') return window.html2canvas(el,opts);
    if(window.html2pdf){
      return window.html2pdf().set({margin:0,html2canvas:opts}).from(el).toCanvas().get('canvas');
    }
    throw new Error('Canvas library not available');
  }

  async function createPdfDoc(pageCount){
    if(jsPDFCls) return new jsPDFCls({unit:'px',format:[A4_PAGE_W,A4_PAGE_H],orientation:'portrait',compress:true,hotfixes:['px_scaling']});
    if(window.html2pdf){
      const stub=document.createElement('div');
      stub.style.width=A4_PAGE_W+'px';
      stub.style.height=A4_PAGE_H+'px';
      return window.html2pdf()
        .set({margin:0,jsPDF:{unit:'px',format:[A4_PAGE_W,A4_PAGE_H],orientation:'portrait',hotfixes:['px_scaling']}})
        .from(stub).toPdf().get('pdf');
    }
    throw new Error('jsPDF not available');
  }

  const host=document.createElement('div');
  host.id='rb-pdf-export-host';
  host.style.cssText='position:fixed;left:0;top:0;width:'+A4_PAGE_W+'px;z-index:2147483647;pointer-events:none;background:#fff;overflow:hidden;';
  const exportStyle=document.createElement('style');
  exportStyle.textContent='#rb-pdf-export-host .rb-a4-page{box-shadow:none!important;margin:0!important;}'+
    '#rb-pdf-export-host .rb-pages-stack{gap:0!important;padding:0!important;}'+
    '#rb-pdf-export-host *{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;color-adjust:exact!important;}';
  host.appendChild(exportStyle);

  const frame=document.createElement('div');
  frame.className='rb-resume-frame';
  host.appendChild(frame);
  document.body.appendChild(host);

  try{
    renderA4Pages(frame,rawHTML,{forExport:true});
    const pageEls=frame.querySelectorAll('.rb-a4-page');
    if(!pageEls.length) throw new Error('No pages to export');

    if(document.fonts&&document.fonts.ready) await document.fonts.ready;
    await new Promise(r=>setTimeout(r,350));

    const pdf=await createPdfDoc(pageEls.length);
    const usedHtml2pdfStub=!jsPDFCls;

    for(let i=0;i<pageEls.length;i++){
      const canvas=await pageToCanvas(pageEls[i]);
      if(i>0) pdf.addPage([A4_PAGE_W,A4_PAGE_H],'portrait');
      pdf.addImage(canvas.toDataURL('image/jpeg',0.95),'JPEG',0,0,A4_PAGE_W,A4_PAGE_H,undefined,'FAST');
    }

    if(usedHtml2pdfStub&&pdf.getNumberOfPages()>pageEls.length) pdf.deletePage(1);
    pdf.save(filename);
  }finally{
    if(host.parentNode) host.parentNode.removeChild(host);
  }
}
window.exportPagesToPDF=exportPagesToPDF;

function hexColor(c){ return (c||'2563eb').replace('#','').toUpperCase(); }

async function buildAndDownloadDocx(data,theme,template,filename){
  if(!window.docx) throw new Error('DOCX library not loaded');
  const D=window.docx;
  const {Document,Packer,Paragraph,TextRun,AlignmentType,BorderStyle,TabStopType,TabStopPosition,ShadingType,convertInchesToTwip,Table,TableRow,TableCell,WidthType}=D;

  const pc=hexColor(theme.primary);
  const sc=hexColor(theme.secondary||theme.primary);
  const ff=theme.fontFamily||'Calibri';
  const bodySize=22;
  const smallSize=18;
  const nameSize=52;
  const titleSize=24;
  const sectionSize=20;
  const noBorder={style:BorderStyle.NONE,size:0,color:'FFFFFF'};
  const tblNoBorder={top:noBorder,bottom:noBorder,left:noBorder,right:noBorder,insideHorizontal:noBorder,insideVertical:noBorder};
  const heroTemplates=['bold','modern','gradient','creative','designer','tech'];
  const useHero=heroTemplates.indexOf(template)>=0;

  const sectionPill=(text)=>new Paragraph({
    spacing:{before:240,after:120},
    shading:{fill:pc,type:ShadingType.CLEAR},
    children:[new TextRun({text:text.toUpperCase(),bold:true,size:sectionSize,font:ff,color:'FFFFFF',characterSpacing:40})]
  });

  const sectionHead=(text)=>useHero?sectionPill(text):new Paragraph({
    spacing:{before:280,after:120},
    border:{bottom:{style:BorderStyle.SINGLE,size:8,color:pc,space:4}},
    children:[new TextRun({text:text.toUpperCase(),bold:true,size:sectionSize,font:ff,color:pc,characterSpacing:60})]
  });

  const shadedBox=(paragraphs)=>new Table({
    width:{size:100,type:WidthType.PERCENTAGE},
    borders:tblNoBorder,
    rows:[new TableRow({children:[
      new TableCell({
        width:{size:1.2,type:WidthType.PERCENTAGE},
        shading:{fill:pc,type:ShadingType.CLEAR},
        borders:tblNoBorder,
        children:[new Paragraph({children:[new TextRun({text:' ',size:8})]})]
      }),
      new TableCell({
        width:{size:98.8,type:WidthType.PERCENTAGE},
        shading:{fill:'F8FAFC',type:ShadingType.CLEAR},
        borders:tblNoBorder,
        margins:{top:80,bottom:80,left:160,right:160},
        children:paragraphs
      })
    ]})]
  });

  const parseRichRuns=(html)=>{
    const runs=[];
    const walk=(node,style={})=>{
      if(!node) return;
      if(node.nodeType===3){ const t=node.textContent; if(t) runs.push({text:t,...style}); return; }
      if(node.nodeType!==1) return;
      const tag=node.tagName&&node.tagName.toLowerCase();
      const next={...style};
      if(tag==='b'||tag==='strong') next.bold=true;
      if(tag==='i'||tag==='em') next.italics=true;
      if(tag==='li') runs.push({text:'• ',...style});
      Array.from(node.childNodes).forEach(c=>walk(c,next));
      if(tag==='li') runs.push({text:'\n',...style});
    };
    const div=document.createElement('div');
    div.innerHTML=html||'';
    walk(div);
    return runs.length?runs:[{text:stripHTML(html)}];
  };

  const richToParagraphs=(html)=>{
    const runs=parseRichRuns(html);
    const paragraphs=[];
    let currentRuns=[];
    const flushRuns=()=>{
      if(currentRuns.length){
        paragraphs.push(new Paragraph({spacing:{after:40},children:currentRuns.map(r=>new TextRun({text:r.text,bold:!!r.bold,italics:!!r.italics,size:bodySize,font:ff,color:'475569'}))}));
        currentRuns=[];
      }
    };
    runs.forEach(r=>{
      if(r.text==='• '){
        flushRuns();
        currentRuns.push({...r,_bullet:true});
      }else if(r.text==='\n'){
        if(currentRuns.length&&currentRuns[0]._bullet){
          const bulletRuns=currentRuns.filter(x=>!x._bullet);
          paragraphs.push(new Paragraph({
            spacing:{after:40},
            indent:{left:convertInchesToTwip(0.3)},
            children:[
              new TextRun({text:'•  ',size:bodySize,font:ff,color:'475569'}),
              ...bulletRuns.map(br=>new TextRun({text:br.text,bold:!!br.bold,italics:!!br.italics,size:bodySize,font:ff,color:'475569'}))
            ]
          }));
          currentRuns=[];
        }else flushRuns();
      }else currentRuns.push(r);
    });
    flushRuns();
    return paragraphs;
  };

  let children=[];

  if(useHero){
    const heroParas=[
      new Paragraph({spacing:{after:100},children:[new TextRun({text:(data.name||'').toUpperCase(),bold:true,size:nameSize,font:ff,color:'FFFFFF'})]})
    ];
    if(data.title) heroParas.push(new Paragraph({spacing:{after:100},children:[new TextRun({text:data.title.toUpperCase(),size:titleSize,font:ff,color:'FFFFFF'})]}));
    const contact=[data.phone,data.email,data.location].filter(Boolean).join('    ');
    if(contact) heroParas.push(new Paragraph({children:[new TextRun({text:contact,size:smallSize,font:ff,color:'FFFFFF'})]}));
    children.push(new Table({
      width:{size:100,type:WidthType.PERCENTAGE},
      borders:tblNoBorder,
      rows:[new TableRow({children:[new TableCell({
        shading:{fill:template==='creative'?'1E293B':pc,type:ShadingType.CLEAR},
        margins:{top:280,bottom:280,left:280,right:280},
        borders:tblNoBorder,
        children:heroParas
      })]})]
    }));
    children.push(new Paragraph({spacing:{after:120},children:[new TextRun({text:'',size:8})]}));
  }else{
    children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:40},children:[new TextRun({text:data.name||'',bold:true,size:nameSize,font:ff,color:'1E293B'})]}));
    if(data.title) children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:60},children:[new TextRun({text:data.title,size:titleSize,font:ff,color:pc})]}));
    children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:60},border:{bottom:{style:BorderStyle.SINGLE,size:6,color:pc,space:6}},children:[new TextRun({text:' ',size:4})]}));
    const contactParts=[data.phone,data.email,data.location,data.linkedin,data.website].filter(Boolean);
    if(contactParts.length) children.push(new Paragraph({
      alignment:AlignmentType.CENTER,spacing:{after:200},
      children:contactParts.flatMap((p,i)=>{
        const parts=[new TextRun({text:p,size:smallSize,font:ff,color:'64748B'})];
        if(i<contactParts.length-1) parts.push(new TextRun({text:'   |   ',size:smallSize,font:ff,color:'CBD5E1'}));
        return parts;
      })
    }));
  }

  if(data.summary&&!(data._disabled&&data._disabled.summary)){
    children.push(sectionHead('Professional Summary'));
    if(useHero){
      children.push(shadedBox([new Paragraph({children:[new TextRun({text:data.summary,size:bodySize,font:ff,color:'475569'})]})]));
    }else{
      children.push(new Paragraph({
        spacing:{after:160},indent:{left:convertInchesToTwip(0.12)},
        border:{left:{style:BorderStyle.SINGLE,size:10,color:pc,space:8}},
        shading:{fill:'F8FAFC',type:ShadingType.CLEAR},
        children:[new TextRun({text:data.summary,size:bodySize,font:ff,color:'475569'})]
      }));
    }
  }

  if(data.skills&&data.skills.length&&!(data._disabled&&data._disabled.skills)){
    children.push(sectionHead('Skills'));
    const cats={};
    data.skills.filter(s=>s.enabled!==false).forEach(s=>{const c=s.category||'General';if(!cats[c])cats[c]=[];cats[c].push(s.name+(s.level?' ('+s.level+'/5)':''));});
    Object.entries(cats).forEach(([cat,items])=>{
      children.push(new Paragraph({spacing:{after:60},children:[
        new TextRun({text:cat+':  ',bold:true,size:bodySize,font:ff,color:pc}),
        new TextRun({text:items.join(',  '),size:bodySize,font:ff,color:'334155'})
      ]}));
    });
  }

  if(data.experience&&data.experience.length&&!(data._disabled&&data._disabled.experience)){
    children.push(sectionHead('Experience'));
    data.experience.filter(e=>e.enabled!==false).forEach((e,i)=>{
      const entryParas=[
        new Paragraph({
          spacing:{before:i>0?80:20,after:40},
          tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
          children:[
            new TextRun({text:e.title||'',bold:true,size:bodySize,font:ff,color:'1E293B'}),
            new TextRun({text:'\t',size:bodySize}),
            new TextRun({text:e.date||'',bold:true,size:smallSize,font:ff,color:pc})
          ]
        }),
        new Paragraph({spacing:{after:60},children:[
          new TextRun({text:e.company||'',italics:true,size:bodySize,font:ff,color:pc}),
          e.location?new TextRun({text:'  ·  '+e.location,size:smallSize,font:ff,color:'94A3B8'}):new TextRun({text:'',size:4})
        ]})
      ];
      richToParagraphs(e.description).forEach(p=>entryParas.push(p));
      if(useHero) children.push(shadedBox(entryParas));
      else entryParas.forEach(p=>children.push(p));
    });
  }

  if(data.education&&data.education.length&&!(data._disabled&&data._disabled.education)){
    children.push(sectionHead('Education'));
    data.education.filter(e=>e.enabled!==false).forEach((e,i)=>{
      const paras=[
        new Paragraph({
          spacing:{before:i>0?100:20,after:40},
          tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
          children:[
            new TextRun({text:e.degree||'',bold:true,size:bodySize,font:ff,color:'1E293B'}),
            new TextRun({text:'\t',size:bodySize}),
            new TextRun({text:e.date||'',bold:true,size:smallSize,font:ff,color:'64748B'})
          ]
        })
      ];
      if(e.institution) paras.push(new Paragraph({spacing:{after:40},children:[new TextRun({text:e.institution,italics:true,size:bodySize,font:ff,color:pc})]}));
      if(e.description) paras.push(new Paragraph({spacing:{after:80},children:[new TextRun({text:stripHTML(e.description),size:bodySize,font:ff,color:'64748B'})]}));
      if(useHero) children.push(shadedBox(paras));
      else paras.forEach(p=>children.push(p));
    });
  }

  if(data.projects&&data.projects.length&&!(data._disabled&&data._disabled.projects)){
    children.push(sectionHead('Projects'));
    data.projects.filter(e=>e.enabled!==false).forEach((e,i)=>{
      const paras=[
        new Paragraph({
          spacing:{before:i>0?100:20,after:40},
          tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
          children:[
            new TextRun({text:e.title||'',bold:true,size:bodySize,font:ff,color:'1E293B'}),
            e.date?new TextRun({text:'\t'+e.date,bold:true,size:smallSize,font:ff,color:pc}):new TextRun({text:'',size:4})
          ]
        })
      ];
      richToParagraphs(e.description).forEach(p=>paras.push(p));
      if(useHero) children.push(shadedBox(paras));
      else paras.forEach(p=>children.push(p));
    });
  }

  const secLabels={certifications:'Certifications',awards:'Awards',volunteer:'Volunteer'};
  ['certifications','awards','volunteer'].forEach(sec=>{
    if(data[sec]&&data[sec].length&&!(data._disabled&&data._disabled[sec])){
      children.push(sectionHead(secLabels[sec]||sec));
      data[sec].filter(e=>e.enabled!==false).forEach((e,i)=>{
        children.push(new Paragraph({spacing:{before:i>0?100:20,after:40},children:[
          new TextRun({text:e.title||e.name||'',bold:true,size:bodySize,font:ff,color:'1E293B'}),
          e.date?new TextRun({text:'  —  '+e.date,size:smallSize,font:ff,color:'64748B'}):new TextRun({text:'',size:4})
        ]}));
        if(e.description) children.push(new Paragraph({spacing:{after:80},children:[new TextRun({text:stripHTML(e.description),size:bodySize,font:ff,color:'475569'})]}));
      });
    }
  });

  if(data.languages&&data.languages.length&&!(data._disabled&&data._disabled.languages)){
    children.push(sectionHead('Languages'));
    children.push(new Paragraph({spacing:{after:160},children:data.languages.filter(l=>l.enabled!==false).flatMap((l,i,arr)=>{
      const parts=[new TextRun({text:l.name,bold:true,size:bodySize,font:ff,color:'334155'}),new TextRun({text:' ('+l.level+'/5)',size:smallSize,font:ff,color:'94A3B8'})];
      if(i<arr.length-1) parts.push(new TextRun({text:'   •   ',size:bodySize,font:ff,color:'CBD5E1'}));
      return parts;
    })}));
  }

  if(data.customSections&&data.customSections.length){
    data.customSections.forEach(cs=>{
      if(cs.enabled===false) return;
      children.push(sectionHead(cs.label||'Other'));
      children.push(new Paragraph({spacing:{after:120},children:[new TextRun({text:stripHTML(cs.content||''),size:bodySize,font:ff,color:'475569'})]}));
    });
  }

  const doc=new Document({
    styles:{default:{document:{run:{font:ff,size:bodySize,color:'334155'}}}},
    sections:[{properties:{page:{margin:{top:convertInchesToTwip(0.5),bottom:convertInchesToTwip(0.5),left:convertInchesToTwip(0.65),right:convertInchesToTwip(0.65)}}},children}]
  });
  const blob=await Packer.toBlob(doc);
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download=filename; a.click();
  URL.revokeObjectURL(url);
}

window.paginateA4Preview=paginateA4Preview;

/* ── Share Modal ── */
function ShareModal({ url, onClose }){
  const qrRef = useRef(null);
  const [copied,setCopied] = useState(false);
  useEffect(()=>{
    if(qrRef.current && window.QRCode){
      qrRef.current.innerHTML='';
      new window.QRCode(qrRef.current,{text:url,width:160,height:160,colorDark:'#1e293b',colorLight:'#ffffff'});
    }
  },[url]);
  const copyLink=()=>{
    navigator.clipboard.writeText(url).then(()=>{setCopied(true);setTimeout(()=>setCopied(false),2000);});
  };
  return React.createElement('div',{className:'rb-share-overlay',onClick:e=>{if(e.target===e.currentTarget)onClose();}},
    React.createElement('div',{className:'rb-share-modal'},
      React.createElement('h3',null,'Share Resume'),
      React.createElement('p',{className:'rb-share-desc'},'Anyone with this link can view and import your resume layout and data.'),
      React.createElement('div',{className:'rb-share-qr',ref:qrRef}),
      React.createElement('div',{className:'rb-share-url-row'},
        React.createElement('input',{className:'rb-input',readOnly:true,value:url}),
        React.createElement('button',{className:'rb-btn rb-btn-primary',onClick:copyLink},copied?'✓ Copied':'Copy Link'),
      ),
      React.createElement('button',{className:'rb-btn rb-btn-ghost',style:{marginTop:12,width:'100%'},onClick:onClose},'Close'),
    )
  );
}

/* ═══════════════════════════════════════
   RESUME BUILDER MODAL
═══════════════════════════════════════ */
window.ResumeBuilderModal = function({ isOpen, onClose }){
  const [data, setData] = useState(()=>{
    const shared = parseShareHash();
    if(shared && shared.d) return shared.d;
    try{ let s=localStorage.getItem('rb_data'); if(s) return JSON.parse(s); } catch(e){}
    return defaultData();
  });
  const [theme, setTheme] = useState(()=>{
    const shared = parseShareHash();
    if(shared && shared.t) return shared.t;
    try{ let s=localStorage.getItem('rb_theme'); if(s) return JSON.parse(s); } catch(e){}
    return defaultTheme();
  });
  const [template, setTemplate] = useState(()=>{
    const shared = parseShareHash();
    if(shared && shared.m) return resolveTemplate(shared.m);
    return resolveTemplate(localStorage.getItem('rb_tmpl') || 'classic');
  });
  const [tab, setTab] = useState('templates');
  const [openSec, setOpenSec] = useState('personal');
  const [saveStatus, setSaveStatus] = useState('');
  const [dragIdx, setDragIdx] = useState(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [pageCount, setPageCount] = useState(1);
  const [contentTruncated, setContentTruncated] = useState(false);
  const previewRef = useRef(null);
  const previewSourceRef = useRef('');

  let previewHTML = '';
  try{
    previewHTML = (window.ResumeRichPreviewCSS||'') + '<div class="rb-resume-source">'+window.ResumeTemplates[template](data,theme)+'</div>';
  }catch(e){ previewHTML='<p style="padding:20px;color:red">Preview error</p>'; }
  previewSourceRef.current = previewHTML;

  const runPagination = useCallback(()=>{
    if(!previewRef.current) return;
    const result=paginateA4Preview(previewRef.current, previewSourceRef.current);
    setPageCount(result.pageCount);
    setContentTruncated(!!result.truncated);
    return result;
  },[]);

  useLayoutEffect(()=>{
    if(!isOpen) return;
    runPagination();
    requestAnimationFrame(()=>{
      runPagination();
      setTimeout(runPagination, 120);
    });
  },[isOpen,data,theme,template,previewHTML,runPagination]);

  useEffect(()=>{
    if(!isOpen) return;
    const iv=setInterval(()=>{
      saveAll(data,theme,template);
      setSaveStatus('saved');
      setTimeout(()=>setSaveStatus(''),2000);
    },30000);
    return ()=>clearInterval(iv);
  },[isOpen,data,theme,template]);

  const handleClose = ()=>{
    saveAll(data,theme,template);
    onClose();
  };

  const upd = useCallback((key,val)=>setData(d=>({...d,[key]:val})),[]);
  const updEntry = useCallback((section,idx,key,val)=>{
    setData(d=>{
      let arr=[...(d[section]||[])];
      arr[idx]={...arr[idx],[key]:val};
      return {...d,[section]:arr};
    });
  },[]);
  const addEntry = useCallback((section,tmpl)=>{
    setData(d=>({...d,[section]:[...(d[section]||[]),{...tmpl,id:Date.now(),enabled:true}]}));
  },[]);
  const removeEntry = useCallback((section,idx)=>{
    setData(d=>{let arr=[...(d[section]||[])]; arr.splice(idx,1); return {...d,[section]:arr};});
  },[]);
  const toggleSection = useCallback((id)=>{
    setData(d=>{
      const disabled={...(d._disabled||{})};
      if(isSectionEnabled(disabled,id)){
        disabled[id]=true;
      }else{
        delete disabled[id];
      }
      return {...d,_disabled:disabled};
    });
  },[]);

  const onDragStart=(e,idx)=>{e.dataTransfer.effectAllowed='move'; setDragIdx(idx);};
  const onDragOver=(e)=>{e.preventDefault();};
  const onDrop=(e,idx)=>{
    e.preventDefault();
    if(dragIdx===null||dragIdx===idx) return;
    setData(d=>{
      let order=[...(d._sectionOrder||SECTION_META.map(s=>s.id))];
      let [item]=order.splice(dragIdx,1);
      order.splice(idx,0,item);
      return {...d,_sectionOrder:order};
    });
    setDragIdx(null);
  };

  const pdfFilename = ()=>{
    const dateSuffix = new Date().toISOString().slice(0,10);
    return `${(data.name||'Resume').replace(/\s+/g,'_')}_Resume_${dateSuffix}.pdf`;
  };

  const exportPDF = async ()=>{
    setExporting(true);
    try{
      if(window.exportPagesToPDF){
        await window.exportPagesToPDF(null, pdfFilename(), previewSourceRef.current);
      }else if(window.html2pdf){
        const el=previewRef.current;
        if(!el){ alert('Preview not ready.'); return; }
        await window.html2pdf().set({
          margin:0, filename:pdfFilename(),
          image:{type:'jpeg',quality:0.98},
          html2canvas:{scale:2,useCORS:true,letterRendering:true,width:A4_PAGE_W,windowWidth:A4_PAGE_W},
          jsPDF:{unit:'px',format:[A4_PAGE_W,A4_PAGE_H],orientation:'portrait'},
        }).from(el.querySelector('.rb-pages-stack')||el).save();
      }else{
        let html = window.ResumeTemplates[template](data,theme);
        let w = window.open('','_blank','width=900,height=1200');
        w.document.write(`<!DOCTYPE html><html><head><title>${pdfFilename()}</title>
          <link href="https://fonts.googleapis.com/css2?family=${theme.fontFamily.replace(/ /g,'+')}:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <style>*{margin:0;box-sizing:border-box}body{margin:0}@page{size:A4;margin:0}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}</style>
        </head><body><div style="width:794px;min-height:1123px;margin:0 auto;background:white">${html}</div>
        <script>setTimeout(function(){window.print();},500);<\/script></body></html>`);
        w.document.close();
      }
    }catch(err){
      console.error(err);
      alert('PDF export failed. Try again or use browser print.');
    }finally{
      setExporting(false);
    }
  };

  // Export DOCX — disabled
  // const exportDOCX = async ()=>{
  //   try{
  //     const dateSuffix=new Date().toISOString().slice(0,10);
  //     const fname=`${(data.name||'Resume').replace(/\s+/g,'_')}_Resume_${dateSuffix}.docx`;
  //     await buildAndDownloadDocx(data,theme,template,fname);
  //   }catch(err){
  //     console.error(err);
  //     alert('DOCX export failed. Please try again.');
  //   }
  // };

  if(!isOpen) return null;

  let sectionOrder = data._sectionOrder || SECTION_META.map(s=>s.id);
  const shareUrl = buildShareUrl(data,theme,template);

  return React.createElement('div',{className:'rb-overlay',onClick:e=>{if(e.target===e.currentTarget) handleClose();}},
    React.createElement('div',{className:'rb-modal'},
      React.createElement('div',{className:'rb-topbar'},
        React.createElement('span',{className:'rb-topbar-title'},'📄 Resume Builder'),
        React.createElement('div',{className:'rb-topbar-spacer'}),
        saveStatus && React.createElement('span',{className:'rb-autosave saved'},'✓ Auto-saved'),
        React.createElement('div',{className:'rb-topbar-actions'},
          React.createElement('button',{className:'rb-btn rb-btn-ghost',onClick:()=>{if(confirm('Load sample resume data?')) setData(sampleData());}},'📋 Sample'),
          React.createElement('button',{className:'rb-btn rb-btn-ghost',onClick:()=>setShareOpen(true)},'🔗 Share'),
          React.createElement('button',{className:'rb-btn rb-btn-primary',onClick:exportPDF,disabled:exporting},exporting?'⏳ Exporting…':'📥 Export PDF'),
          // React.createElement('button',{className:'rb-btn rb-btn-success',onClick:exportDOCX},'📄 Export DOCX'),
          React.createElement('button',{className:'rb-btn rb-btn-ghost',onClick:()=>{if(confirm('Reset all data?')){setData(defaultData());setTheme(defaultTheme());setTemplate('classic');localStorage.removeItem('rb_data');localStorage.removeItem('rb_theme');localStorage.removeItem('rb_tmpl');}}},'🗑 Reset'),
        ),
        React.createElement('button',{className:'rb-btn-close',onClick:handleClose},'✕'),
      ),
      React.createElement('div',{className:'rb-body'},
        React.createElement('div',{className:'rb-left'},
          React.createElement('div',{className:'rb-tabs'},
            ['templates','editor','style'].map(t=>
              React.createElement('button',{key:t,className:'rb-tab'+(tab===t?' active':''),onClick:()=>setTab(t)},t)
            )
          ),
          React.createElement('div',{className:'rb-tab-content'},
            tab==='templates' && renderTemplatesTab(template,setTemplate,data,theme),
            tab==='editor' && renderEditorTab(data,upd,updEntry,addEntry,removeEntry,toggleSection,openSec,setOpenSec,sectionOrder,dragIdx,onDragStart,onDragOver,onDrop),
            tab==='style' && renderStyleTab(theme,setTheme),
          ),
        ),
        React.createElement('div',{className:'rb-right'},
          React.createElement('div',{className:'rb-preview-toolbar'},
            React.createElement('span',null,'📋 Live Preview — ',template.charAt(0).toUpperCase()+template.slice(1),' · A4 · max ',MAX_RESUME_PAGES,' pages'),
            React.createElement('span',null,
              pageCount,' page',pageCount!==1?'s':'',
              pageCount>1?' (scroll ↓)':'',
              contentTruncated?' · ⚠ content exceeds 3 pages':'',
              ' · ',theme.fontFamily
            ),
          ),
          React.createElement('div',{className:'rb-preview-wrap'},
            React.createElement('div',{className:'rb-preview-scaler'},
              React.createElement('div',{ref:previewRef,className:'rb-resume-frame','data-resume-source':'1'}),
            ),
          ),
        ),
      ),
    ),
    shareOpen && React.createElement(ShareModal,{url:shareUrl,onClose:()=>setShareOpen(false)}),
  );
};

/* ── Template Picker Tab ── */
function renderTemplatesTab(active,setTemplate,data,theme){
  let list = window.ResumeTemplateList || [];
  return React.createElement('div',null,
    React.createElement('p',{className:'rb-tmpl-hint'},'Browse & apply any of 15 templates instantly. Your data is preserved when switching.'),
    React.createElement('div',{className:'rb-tmpl-grid'},
      list.map(t=>{
        let thumb='';
        try{ thumb = window.ResumeTemplates[t.id](data,theme); }catch(e){ thumb=''; }
        return React.createElement('div',{key:t.id,className:'rb-tmpl-card'+(active===t.id?' active':''),onClick:()=>setTemplate(t.id)},
          React.createElement('div',{className:'rb-tmpl-preview',dangerouslySetInnerHTML:{__html:thumb}}),
          React.createElement('div',{className:'rb-tmpl-info'},
            React.createElement('span',{className:'rb-tmpl-dot'},t.emoji),
            React.createElement('span',{className:'rb-tmpl-name'},t.name),
          ),
          React.createElement('span',{className:'rb-tmpl-desc'},t.desc),
          active===t.id && React.createElement('span',{className:'rb-tmpl-active-badge'},'✓ Active'),
        );
      })
    )
  );
}

/* ── Style Tab ── */
function renderStyleTab(theme,setTheme){
  const upT=(k,v)=>setTheme(t=>({...t,[k]:v}));
  const presets=[
    {name:'Ocean',primary:'#2563eb',secondary:'#7c3aed',accent:'#06b6d4'},
    {name:'Forest',primary:'#059669',secondary:'#10b981',accent:'#34d399'},
    {name:'Sunset',primary:'#dc2626',secondary:'#f97316',accent:'#fbbf24'},
    {name:'Slate',primary:'#334155',secondary:'#64748b',accent:'#94a3b8'},
  ];
  return React.createElement('div',null,
    React.createElement('div',{className:'rb-style-group'},
      React.createElement('div',{className:'rb-style-group-label'},'Color Presets'),
      React.createElement('div',{className:'rb-preset-row'},
        presets.map(p=>React.createElement('button',{key:p.name,className:'rb-preset-btn',style:{background:`linear-gradient(135deg,${p.primary},${p.secondary})`},title:p.name,onClick:()=>setTheme(t=>({...t,...p}))}))
      ),
    ),
    React.createElement('div',{className:'rb-style-group'},
      React.createElement('div',{className:'rb-style-group-label'},'Colors'),
      ...[['primary','Primary'],['secondary','Secondary'],['accent','Accent']].map(([k,l])=>
        React.createElement('div',{key:k,className:'rb-color-row',style:{marginBottom:8}},
          React.createElement('div',{className:'rb-color-swatch',style:{background:theme[k]}},
            React.createElement('input',{type:'color',value:theme[k],onChange:e=>upT(k,e.target.value)}),
          ),
          React.createElement('span',{className:'rb-color-label'},l),
          React.createElement('input',{className:'rb-input',style:{width:90,marginLeft:8},value:theme[k],onChange:e=>upT(k,e.target.value)}),
        )
      ),
    ),
    React.createElement('div',{className:'rb-style-group'},
      React.createElement('div',{className:'rb-style-group-label'},'Font Family (8 Google Fonts)'),
      React.createElement('div',{className:'rb-font-grid'},
        FONTS.map(f=>React.createElement('button',{key:f,className:'rb-font-btn'+(theme.fontFamily===f?' active':''),style:{fontFamily:f},onClick:()=>upT('fontFamily',f)},f)),
      ),
    ),
    React.createElement('div',{className:'rb-style-group'},
      React.createElement('div',{className:'rb-style-group-label'},'Font Size'),
      React.createElement('div',{className:'rb-option-row'},
        ['small','medium','large'].map(s=>React.createElement('button',{key:s,className:'rb-option-btn'+(theme.fontSize===s?' active':''),onClick:()=>upT('fontSize',s)},s)),
      ),
    ),
    React.createElement('div',{className:'rb-style-group'},
      React.createElement('div',{className:'rb-style-group-label'},'Spacing Density'),
      React.createElement('div',{className:'rb-option-row'},
        ['compact','standard','spacious'].map(s=>React.createElement('button',{key:s,className:'rb-option-btn'+(theme.spacing===s?' active':''),onClick:()=>upT('spacing',s)},s)),
      ),
    ),
  );
}

/* ── Editor Tab ── */
function renderEditorTab(data,upd,updEntry,addEntry,removeEntry,toggleSection,openSec,setOpenSec,sectionOrder,dragIdx,onDragStart,onDragOver,onDrop){
  let personalBlock = React.createElement('div',{className:'rb-section-row',style:{marginBottom:10}},
    React.createElement('div',{className:'rb-section-header',onClick:()=>setOpenSec(openSec==='personal'?null:'personal')},
      React.createElement('span',{className:'rb-section-icon'},'👤'),
      React.createElement('span',{className:'rb-section-label'},'Personal Info'),
      React.createElement('span',{className:'rb-section-chevron'+(openSec==='personal'?' open':'')},'▼'),
    ),
    openSec==='personal' && React.createElement('div',{className:'rb-section-body'},
      fg('Full Name',inp(data.name,v=>upd('name',v))),
      fg('Professional Title',inp(data.title,v=>upd('title',v))),
    ),
  );

  let contactBlock = React.createElement('div',{className:'rb-section-row',style:{marginBottom:10}},
    React.createElement('div',{className:'rb-section-header',onClick:()=>setOpenSec(openSec==='contact'?null:'contact')},
      React.createElement('span',{className:'rb-section-icon'},'📞'),
      React.createElement('span',{className:'rb-section-label'},'Contact Details'),
      React.createElement('span',{className:'rb-section-chevron'+(openSec==='contact'?' open':'')},'▼'),
    ),
    openSec==='contact' && React.createElement('div',{className:'rb-section-body'},
      React.createElement('div',{className:'rb-form-row'},
        fg('Email',inp(data.email,v=>upd('email',v))),
        fg('Phone',inp(data.phone,v=>upd('phone',v))),
      ),
      React.createElement('div',{className:'rb-form-row'},
        fg('Location',inp(data.location,v=>upd('location',v))),
        fg('LinkedIn',inp(data.linkedin,v=>upd('linkedin',v))),
      ),
      fg('Address',inp(data.address,v=>upd('address',v))),
      fg('Website',inp(data.website,v=>upd('website',v))),
    ),
  );

  let sectionBlocks = sectionOrder.map((sid,idx)=>{
    let meta = SECTION_META.find(s=>s.id===sid);
    if(!meta) return null;
    let isOpen = openSec===sid;
    let sectionEnabled = isSectionEnabled(data._disabled,sid);
    return React.createElement('div',{
      key:sid, className:'rb-section-row'+(dragIdx===idx?' drag-over':'')+(!sectionEnabled?' rb-section-hidden':''),
      draggable:true,
      onDragStart:e=>onDragStart(e,idx),
      onDragOver:e=>onDragOver(e,idx),
      onDrop:e=>onDrop(e,idx),
    },
      React.createElement('div',{className:'rb-section-header',onClick:()=>setOpenSec(isOpen?null:sid)},
        React.createElement('span',{className:'rb-drag-handle',title:'Drag to reorder',onClick:e=>e.stopPropagation()},'⠿'),
        React.createElement('span',{className:'rb-section-icon'},meta.icon),
        React.createElement('span',{className:'rb-section-label'},meta.label),
        !sectionEnabled && React.createElement('span',{className:'rb-section-off-badge'},'Hidden'),
        React.createElement('button',{
          type:'button',
          className:'rb-section-toggle'+(sectionEnabled?' on':''),
          title:sectionEnabled?'Hide from resume':'Show in resume',
          onClick:e=>{e.stopPropagation();toggleSection(sid);}
        }),
        React.createElement('span',{className:'rb-section-chevron'+(isOpen?' open':'')},'▼'),
      ),
      isOpen && React.createElement('div',{className:'rb-section-body'},
        renderSectionEditor(sid,data,upd,updEntry,addEntry,removeEntry)
      ),
    );
  });

  return React.createElement('div',{className:'rb-section-list'}, personalBlock, contactBlock, ...sectionBlocks);
}

/* ── Section Editors ── */
function renderSectionEditor(sid,data,upd,updEntry,addEntry,removeEntry){
  switch(sid){
    case 'summary':
      return fg('Summary',ta(data.summary,v=>upd('summary',v),WORD_LIMITS.summary),WORD_LIMITS.summary,data.summary);
    case 'experience':
      return React.createElement('div',null,
        (data.experience||[]).map((e,i)=>entryCard('Experience #'+(i+1),'experience',i,e,updEntry,removeEntry,[
          ['title','Job Title'],['company','Company'],['location','Location'],['date','Date Range'],
          ['description','Description (rich)']
        ],true,WORD_LIMITS.experience_desc)),
        React.createElement('button',{className:'rb-add-btn',onClick:()=>addEntry('experience',{title:'',company:'',location:'',date:'',description:''})},'+ Add Experience'),
      );
    case 'education':
      return React.createElement('div',null,
        (data.education||[]).map((e,i)=>entryCard('Education #'+(i+1),'education',i,e,updEntry,removeEntry,[
          ['degree','Degree'],['institution','Institution'],['date','Date Range'],['description','Details (textarea)']
        ],false,WORD_LIMITS.education_desc)),
        React.createElement('button',{className:'rb-add-btn',onClick:()=>addEntry('education',{degree:'',institution:'',date:'',description:''})},'+ Add Education'),
      );
    case 'skills':
      return React.createElement('div',null,
        (data.skills||[]).map((s,i)=>
          React.createElement('div',{key:s.id||i,className:'rb-entry-card'},
            React.createElement('div',{className:'rb-entry-header'},
              React.createElement('span',{className:'rb-entry-title'},'Skill #'+(i+1)),
              React.createElement('button',{className:'rb-entry-btn',onClick:()=>removeEntry('skills',i)},'✕'),
            ),
            fg('Category (e.g. Languages, Frameworks)',inp(s.category,v=>updEntry('skills',i,'category',v))),
            fg('Skills (comma-separated or single)',inp(s.name,v=>updEntry('skills',i,'name',v))),
            fg('Proficiency (1–5)',
              React.createElement('div',{className:'rb-skill-level'},
                [1,2,3,4,5].map(n=>React.createElement('div',{key:n,className:'rb-skill-dot-ui'+(s.level>=n?' filled':''),onClick:()=>updEntry('skills',i,'level',n),title:'Level '+n})),
                React.createElement('span',{className:'rb-skill-level-label'},(s.level||3)+'/5')
              )
            ),
          )
        ),
        React.createElement('button',{className:'rb-add-btn',onClick:()=>addEntry('skills',{name:'',category:'',level:3})},'+ Add Skill Group'),
      );
    case 'projects': return listEditor('projects',data,updEntry,addEntry,removeEntry,[['title','Title'],['date','Date'],['description','Description (rich)']],true,WORD_LIMITS.project_desc);
    case 'certifications': return listEditor('certifications',data,updEntry,addEntry,removeEntry,[['title','Name'],['date','Date'],['description','Details (textarea)']],false,WORD_LIMITS.certification_desc);
    case 'awards': return listEditor('awards',data,updEntry,addEntry,removeEntry,[['title','Award'],['date','Date'],['description','Details (textarea)']],false,WORD_LIMITS.award_desc);
    case 'languages':
      return React.createElement('div',null,
        (data.languages||[]).map((l,i)=>
          React.createElement('div',{key:l.id||i,className:'rb-entry-card'},
            React.createElement('div',{className:'rb-entry-header'},
              React.createElement('span',{className:'rb-entry-title'},'Language #'+(i+1)),
              React.createElement('button',{className:'rb-entry-btn',onClick:()=>removeEntry('languages',i)},'✕'),
            ),
            fg('Language',inp(l.name,v=>updEntry('languages',i,'name',v))),
            fg('Proficiency (1–5)',
              React.createElement('div',{className:'rb-skill-level'},
                [1,2,3,4,5].map(n=>React.createElement('div',{key:n,className:'rb-skill-dot-ui'+(l.level>=n?' filled':''),onClick:()=>updEntry('languages',i,'level',n),title:'Level '+n})),
                React.createElement('span',{className:'rb-skill-level-label'},(l.level||3)+'/5')
              )
            ),
          )
        ),
        React.createElement('button',{className:'rb-add-btn',onClick:()=>addEntry('languages',{name:'',level:3})},'+ Add Language'),
      );
    case 'volunteer': return listEditor('volunteer',data,updEntry,addEntry,removeEntry,[['title','Role'],['date','Date'],['description','Description (rich)']],true,WORD_LIMITS.volunteer_desc);
    case 'custom':
      return React.createElement('div',null,
        (data.customSections||[]).map((cs,i)=>
          React.createElement('div',{key:cs.id||i,className:'rb-entry-card'},
            React.createElement('div',{className:'rb-entry-header'},
              React.createElement('span',{className:'rb-entry-title'},'Custom #'+(i+1)),
              React.createElement('button',{className:'rb-entry-btn',onClick:()=>removeEntry('customSections',i)},'✕'),
            ),
            fg('Section Label',inp(cs.label,v=>updEntry('customSections',i,'label',v))),
            fg('Content',React.createElement(RichTextEditor,{editorKey:'custom-'+i,value:cs.content,onChange:v=>updEntry('customSections',i,'content',v),wordLimit:WORD_LIMITS.custom_desc})),
          )
        ),
        React.createElement('button',{className:'rb-add-btn',onClick:()=>addEntry('customSections',{label:'',content:''})},'+ Add Custom Section'),
      );
    default: return null;
  }
}

function listEditor(section,data,updEntry,addEntry,removeEntry,fields,rich,descLimit){
  return React.createElement('div',null,
    (data[section]||[]).map((e,i)=>entryCard(section.charAt(0).toUpperCase()+section.slice(1)+' #'+(i+1),section,i,e,updEntry,removeEntry,fields,rich,descLimit)),
    React.createElement('button',{className:'rb-add-btn',onClick:()=>{
      let tmpl={}; fields.forEach(f=>tmpl[f[0]]='');
      addEntry(section,tmpl);
    }},'+ Add Entry'),
  );
}

function entryCard(label,section,idx,entry,updEntry,removeEntry,fields,rich,descLimit){
  return React.createElement('div',{key:entry.id||idx,className:'rb-entry-card'},
    React.createElement('div',{className:'rb-entry-header'},
      React.createElement('span',{className:'rb-entry-title'},label),
      React.createElement('button',{className:'rb-entry-btn',onClick:()=>removeEntry(section,idx)},'✕'),
    ),
    ...fields.map(([k,lbl])=>{
      const isRich=lbl.includes('rich');
      const isTextarea=lbl.includes('textarea');
      const isDesc=k==='description'||k==='content';
      const limit=isDesc&&descLimit?descLimit:null;
      if(isRich) return fg(lbl.replace(' (rich)',''),React.createElement(RichTextEditor,{editorKey:section+'-'+idx+'-'+k,value:entry[k],onChange:v=>updEntry(section,idx,k,v),wordLimit:limit}));
      if(isTextarea) return fg(lbl.replace(' (textarea)',''),ta(entry[k],v=>updEntry(section,idx,k,v),limit),limit,entry[k]);
      return fg(lbl,inp(entry[k],v=>updEntry(section,idx,k,v)));
    }),
  );
}

function fg(label,child,wordLimit,currentText){
  const showCount=wordLimit&&!(child&&child.props&&child.props.wordLimit);
  return React.createElement('div',{className:'rb-form-group'},
    React.createElement('label',{className:'rb-form-label'},label),
    child,
    showCount&&React.createElement('div',{className:'rb-word-count'+(countWords(currentText||'')>=wordLimit?' at-limit':'')},countWords(currentText||'')+' / '+wordLimit+' words'),
  );
}
function inp(val,onChange){
  return React.createElement('input',{className:'rb-input',value:val||'',onChange:e=>onChange(e.target.value)});
}
function ta(val,onChange,wordLimit){
  const handleChange=(e)=>{
    let v=e.target.value;
    if(wordLimit) v=limitPlainWords(v,wordLimit);
    onChange(v);
  };
  return React.createElement('textarea',{className:'rb-textarea',value:val||'',onChange:handleChange});
}

/* Auto-open from shared link */
window.ResumeBuilderAutoOpen = function(){
  return !!parseShareHash();
};

})();
