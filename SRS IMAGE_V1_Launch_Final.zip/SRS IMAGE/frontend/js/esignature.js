/* =============================================
   E-SIGNATURE COMPONENT & SYSTEM
   ============================================= */
'use strict';

(function () {
  const { useState, useRef, useEffect } = React;
  const C = window.Components;

  // Initialize PDF.js worker
  if (window.pdfjsLib) {
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
  }

  function ESignatureModal({ isOpen, onClose }) {
    if (!isOpen) return null;

    // Steps: 1 (Upload), 2 (Signature Prep), 3 (Place & Stamp)
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [loadingText, setLoadingText] = useState('');
    const [error, setError] = useState('');

    // Document state
    const [docFile, setDocFile] = useState(null);
    const [pdfBlob, setPdfBlob] = useState(null); // Always PDF for rendering/signing
    const [pdfDoc, setPdfDoc] = useState(null);
    const [totalPages, setTotalPages] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);

    // Signature state
    const [sigFile, setSigFile] = useState(null);
    const [sigOriginalUrl, setSigOriginalUrl] = useState('');
    const [sigProcessedBlob, setSigProcessedBlob] = useState(null);
    const [sigProcessedUrl, setSigProcessedUrl] = useState('');
    const [isBgRemoved, setIsBgRemoved] = useState(false);

    // Cropper state
    const [isCropping, setIsCropping] = useState(false);
    const cropperRef = useRef(null);
    const cropImgRef = useRef(null);

    // Placement state
    const canvasRef = useRef(null);
    const containerRef = useRef(null);
    const sigElementRef = useRef(null);

    const [sigPosition, setSigPosition] = useState({ x: 20, y: 20 });
    const [sigSize, setSigSize] = useState({ width: 150, height: 75 });
    const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
    const [resizeStart, setResizeStart] = useState({ w: 0, h: 0, x: 0, y: 0 });
    const [sigAngle, setSigAngle] = useState(0);

    // Clean up urls on unmount
    useEffect(() => {
      return () => {
        if (sigOriginalUrl) URL.revokeObjectURL(sigOriginalUrl);
        if (sigProcessedUrl) URL.revokeObjectURL(sigProcessedUrl);
      };
    }, [sigOriginalUrl, sigProcessedUrl]);

    // Handle document upload
    const handleDocUpload = async (file) => {
      setError('');
      setDocFile(file);

      const isDocx = file.name.toLowerCase().endsWith('.docx');
      const isPdf = file.name.toLowerCase().endsWith('.pdf');

      if (!isDocx && !isPdf) {
        setError('Please upload a valid PDF or DOCX file.');
        return;
      }

      setLoading(true);
      setLoadingText(isDocx ? 'Converting DOCX to PDF...' : 'Loading PDF...');

      try {
        let blob = file;
        if (isDocx) {
          const fd = new FormData();
          fd.append('file', file);
          const response = await fetch(`${C.API}/pdf/docx-to-pdf`, {
            method: 'POST',
            body: fd
          });
          if (!response.ok) {
            throw new Error('Failed to convert DOCX. Make sure LibreOffice is installed and running.');
          }
          blob = await response.blob();
        }

        setPdfBlob(blob);
        const arrayBuf = await blob.arrayBuffer();
        const pdf = await window.pdfjsLib.getDocument({ data: arrayBuf }).promise;
        setPdfDoc(pdf);
        setTotalPages(pdf.numPages);
        setCurrentPage(1);
      } catch (err) {
        console.error(err);
        setError(err.message || 'Error processing document.');
        setDocFile(null);
        setPdfBlob(null);
      } finally {
        setLoading(false);
      }
    };

    // Handle signature upload
    const handleSigUpload = (file) => {
      setError('');
      if (!file.type.startsWith('image/')) {
        setError('Please upload a valid image file for signature.');
        return;
      }
      setSigFile(file);
      const url = URL.createObjectURL(file);
      setSigOriginalUrl(url);
      setSigProcessedBlob(file);
      setSigProcessedUrl(url);
      setIsBgRemoved(false);
      setIsCropping(false);
    };

    // Remove background from signature
    const handleRemoveBg = async () => {
      if (!sigProcessedBlob) return;
      setLoading(true);
      setLoadingText('Removing background...');
      setError('');

      try {
        const fd = new FormData();
        fd.append('file', sigProcessedBlob, 'signature.png');
        const response = await fetch(`${C.API}/image/remove-bg`, {
          method: 'POST',
          body: fd
        });
        if (!response.ok) {
          throw new Error('Failed to remove background. Ensure rembg backend is running.');
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);

        if (sigProcessedUrl) URL.revokeObjectURL(sigProcessedUrl);
        setSigProcessedBlob(blob);
        setSigProcessedUrl(url);
        setIsBgRemoved(true);
      } catch (err) {
        console.error(err);
        setError(err.message || 'Error removing background.');
      } finally {
        setLoading(false);
      }
    };

    // Start Cropping
    const startCropping = () => {
      setIsCropping(true);
      setTimeout(() => {
        if (cropImgRef.current) {
          cropperRef.current = new Cropper(cropImgRef.current, {
            viewMode: 1,
            autoCropArea: 1,
            background: false,
            responsive: true,
            checkOrientation: false
          });
        }
      }, 50);
    };

    // Save Crop
    const saveCrop = () => {
      if (!cropperRef.current) return;
      cropperRef.current.getCroppedCanvas().toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        if (sigProcessedUrl) URL.revokeObjectURL(sigProcessedUrl);
        setSigProcessedBlob(blob);
        setSigProcessedUrl(url);
        setIsCropping(false);
        cropperRef.current.destroy();
        cropperRef.current = null;
      }, 'image/png');
    };

    // Cancel Crop
    const cancelCrop = () => {
      setIsCropping(false);
      if (cropperRef.current) {
        cropperRef.current.destroy();
        cropperRef.current = null;
      }
    };

    // Render PDF page to canvas
    const renderPdfPage = async () => {
      if (!pdfDoc || !canvasRef.current) return;
      try {
        const page = await pdfDoc.getPage(currentPage);
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');

        canvas.width = viewport.width;
        canvas.height = viewport.height;
        setCanvasSize({ width: viewport.width, height: viewport.height });

        const renderContext = {
          canvasContext: context,
          viewport: viewport
        };
        await page.render(renderContext).promise;
      } catch (err) {
        console.error('Page render error:', err);
      }
    };

    // Trigger render when page or pdfDoc changes
    useEffect(() => {
      if (step === 3 && pdfDoc) {
        renderPdfPage();
      }
    }, [step, currentPage, pdfDoc]);

    // Handle mouse events for signature dragging
    const handleMouseDown = (e) => {
      if (e.target.classList.contains('esig-sig-resize-handle')) {
        setIsResizing(true);
        setResizeStart({
          w: sigSize.width,
          h: sigSize.height,
          x: e.clientX,
          y: e.clientY
        });
      } else if (e.target.classList.contains('esig-sig-delete-handle')) {
        // Just reset or hide
      } else {
        setIsDragging(true);
        setDragStart({
          x: e.clientX - sigPosition.x,
          y: e.clientY - sigPosition.y
        });
      }
      e.preventDefault();
    };

    const handleMouseMove = (e) => {
      if (isDragging) {
        let newX = e.clientX - dragStart.x;
        let newY = e.clientY - dragStart.y;

        // Boundaries
        newX = Math.max(0, Math.min(newX, canvasSize.width - sigSize.width));
        newY = Math.max(0, Math.min(newY, canvasSize.height - sigSize.height));

        setSigPosition({ x: newX, y: newY });
      } else if (isResizing) {
        const dw = e.clientX - resizeStart.x;
        const dh = e.clientY - resizeStart.y;

        let newW = Math.max(30, resizeStart.w + dw);
        let newH = Math.max(15, resizeStart.h + dh);

        // Constrain to canvas boundaries
        if (sigPosition.x + newW > canvasSize.width) {
          newW = canvasSize.width - sigPosition.x;
        }
        if (sigPosition.y + newH > canvasSize.height) {
          newH = canvasSize.height - sigPosition.y;
        }

        setSigSize({ width: newW, height: newH });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    // Size adjustment helpers (plus/minus)
    const adjustSize = (scale) => {
      let newW = sigSize.width * scale;
      let newH = sigSize.height * scale;

      newW = Math.max(30, Math.min(newW, canvasSize.width - sigPosition.x));
      newH = Math.max(15, Math.min(newH, canvasSize.height - sigPosition.y));

      setSigSize({ width: newW, height: newH });
    };

    // Call sign-pdf on the backend and download the result
    const handleSignAndDownload = async () => {
      if (!pdfBlob || !sigProcessedBlob) return;
      setLoading(true);
      setLoadingText('Generating signed document...');
      setError('');

      try {
        const fd = new FormData();
        fd.append('file', pdfBlob, docFile.name.replace(/\.[^/.]+$/, "") + ".pdf");
        fd.append('signature', sigProcessedBlob, 'signature.png');
        fd.append('page_number', currentPage - 1);

        // Calculate relative percentages
        const x_pct = (sigPosition.x / canvasSize.width) * 100;
        const y_pct = (sigPosition.y / canvasSize.height) * 100;
        const w_pct = (sigSize.width / canvasSize.width) * 100;
        const h_pct = (sigSize.height / canvasSize.height) * 100;

        fd.append('x_pct', x_pct);
        fd.append('y_pct', y_pct);
        fd.append('w_pct', w_pct);
        fd.append('h_pct', h_pct);
        fd.append('rotation', sigAngle);

        const response = await fetch(`${C.API}/pdf/sign-pdf`, {
          method: 'POST',
          body: fd
        });

        if (!response.ok) {
          throw new Error('Failed to generate signed document.');
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);

        // Create download link
        const a = document.createElement('a');
        a.href = url;
        a.download = `Signed_${docFile.name.replace(/\.[^/.]+$/, "")}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        onClose();
      } catch (err) {
        console.error(err);
        setError(err.message || 'Failed to download signed document.');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="esig-overlay" onMouseMove={handleMouseMove} onMouseUp={handleMouseUp}>
        <div className="esig-modal">
          {/* Modal Header */}
          <div className="esig-modal-header">
            <div className="esig-modal-title">
              <div className="esig-modal-title-icon"><svg className="esig-btn-icon" height="18" width="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 20h9" />
                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
              </svg></div>
              <div>
                <h2>E-Signature Suite</h2>
                <p>Upload a document, prep your signature, place and download securely</p>
              </div>
            </div>
            <button className="esig-close-btn" onClick={onClose}>✕</button>
          </div>

          {/* Steps Breadcrumbs */}
          <div className="esig-steps">
            <div className={`esig-step ${step === 1 ? 'active' : ''} ${step > 1 ? 'done' : ''}`} onClick={() => setStep(1)}>
              <span className="esig-step-num">1</span> Upload Files
            </div>
            <div className={`esig-step ${step === 2 ? 'active' : ''} ${step > 2 ? 'done' : ''}`} onClick={() => docFile && sigFile && setStep(2)}>
              <span className="esig-step-num">2</span> Prep Signature
            </div>
            <div className={`esig-step ${step === 3 ? 'active' : ''}`} onClick={() => docFile && sigProcessedBlob && setStep(3)}>
              <span className="esig-step-num">3</span> Place &amp; Download
            </div>
          </div>

          {/* Modal Body */}
          <div className="esig-modal-body">
            {error && <C.Alert type="error">{error}</C.Alert>}

            {/* Spinner Overlay */}
            {loading && (
              <div className="esig-loading-overlay">
                <div className="spinner"></div>
                <div>{loadingText}</div>
              </div>
            )}

            {/* STEP 1: UPLOADS */}
            <div className={`esig-panel ${step === 1 ? 'active' : ''}`}>
              <div className="esig-upload-row">
                {/* Doc Upload */}
                <div className={`esig-upload-card ${docFile ? 'has-file' : ''}`}>
                  <input type="file" accept=".pdf,.docx" onChange={(e) => e.target.files?.[0] && handleDocUpload(e.target.files[0])} />
                  <div className="esig-upload-icon">📄</div>
                  <h3>Upload Document</h3>
                  <p>PDF or Word Document (.docx)</p>
                  {docFile && <span className="esig-file-name">{docFile.name}</span>}
                </div>

                {/* Signature Upload */}
                <div className={`esig-upload-card ${sigFile ? 'has-file' : ''}`}>
                  <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && handleSigUpload(e.target.files[0])} />
                  <div className="esig-upload-icon">🖋️</div>
                  <h3>Upload Signature Image</h3>
                  <p>JPG, PNG or other image formats</p>
                  {sigFile && <span className="esig-file-name">{sigFile.name}</span>}
                </div>
              </div>

              <div style={{ textAlign: 'center', marginTop: 30 }}>
                <button
                  className="btn btn-primary"
                  disabled={!docFile || !sigFile}
                  onClick={() => setStep(2)}
                >
                  Continue to Signature Prep &rarr;
                </button>
              </div>
            </div>

            {/* STEP 2: PREP SIGNATURE */}
            <div className={`esig-panel ${step === 2 ? 'active' : ''}`}>
              {!isCropping ? (
                <div className="esig-sig-section">
                  <div className="esig-sig-header">
                    <h3>Signature Preview &amp; Enhancements</h3>
                    <div className="esig-sig-tools">
                      <button className={`esig-tool-btn ${isBgRemoved ? 'active' : ''}`} onClick={handleRemoveBg} disabled={isBgRemoved}>
                        ✨ Remove Background
                      </button>
                      <button className="esig-tool-btn" onClick={startCropping}>
                        ✂️ Crop Signature
                      </button>
                    </div>
                  </div>

                  <div className="esig-before-after">
                    <div className="esig-ba-card">
                      <div className="esig-ba-card-title">Original Upload</div>
                      <div className="esig-ba-card-body">
                        <img src={sigOriginalUrl} alt="Original Signature" />
                      </div>
                    </div>

                    <div className="esig-ba-card">
                      <div className="esig-ba-card-title">Processed (Transparent)</div>
                      <div className="esig-ba-card-body transparent">
                        <img src={sigProcessedUrl} alt="Processed Signature" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="esig-sig-section">
                  <div className="esig-sig-header">
                    <h3>Crop Signature</h3>
                    <div className="esig-sig-tools">
                      <button className="esig-tool-btn active" onClick={saveCrop}>Save Crop</button>
                      <button className="esig-tool-btn danger" onClick={cancelCrop}>Cancel</button>
                    </div>
                  </div>
                  <div className="esig-crop-area">
                    <div className="esig-crop-canvas-wrap">
                      <img ref={cropImgRef} src={sigProcessedUrl} alt="To Crop" />
                    </div>
                  </div>
                </div>
              )}

              {!isCropping && (
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 30 }}>
                  <button className="btn btn-outline" onClick={() => setStep(1)}>&larr; Back to Uploads</button>
                  <button className="btn btn-primary" onClick={() => setStep(3)}>Continue to Placement &rarr;</button>
                </div>
              )}
            </div>

            {/* STEP 3: PLACEMENT */}
            <div className={`esig-panel ${step === 3 ? 'active' : ''}`}>
              <div className="esig-placer-layout">
                {/* Placer Sidebar Controls */}
                <div className="esig-placer-sidebar">
                  <div className="esig-control-section">
                    <h4>Signature Thumb</h4>
                    <div className="esig-sig-thumb">
                      <img src={sigProcessedUrl} alt="Sig Thumb" />
                    </div>
                  </div>

                  <div className="esig-control-section">
                    <h4>Resize Signature</h4>
                    <div className="esig-size-controls">
                      <button className="esig-size-btn" onClick={() => adjustSize(0.9)}>-</button>
                      <span className="esig-size-value">{Math.round(sigSize.width)}px</span>
                      <button className="esig-size-btn" onClick={() => adjustSize(1.1)}>+</button>
                    </div>
                  </div>

                  <div className="esig-control-section">
                    <h4>Rotate Signature</h4>
                    <div className="esig-size-controls">
                      <button className="esig-size-btn" onClick={() => setSigAngle(a => (a - 15 + 360) % 360)}>↺</button>
                      <span className="esig-size-value">{sigAngle}°</span>
                      <button className="esig-size-btn" onClick={() => setSigAngle(a => (a + 15) % 360)}>↻</button>
                    </div>
                  </div>

                  <div className="esig-control-section">
                    <h4>Page Navigator</h4>
                    <div className="esig-page-nav">
                      <button className="esig-page-btn" disabled={currentPage <= 1} onClick={() => setCurrentPage(currentPage - 1)}>
                        Prev
                      </button>
                      <span className="esig-page-indicator">{currentPage} / {totalPages}</span>
                      <button className="esig-page-btn" disabled={currentPage >= totalPages} onClick={() => setCurrentPage(currentPage + 1)}>
                        Next
                      </button>
                    </div>
                  </div>
                </div>

                {/* PDF rendering viewport */}
                <div className="esig-doc-canvas-wrap">
                  <div className="esig-doc-canvas-header">
                    <span>📄 Document Preview (Page {currentPage})</span>
                  </div>
                  <div className="esig-canvas-viewport">
                    <div ref={containerRef} className="esig-canvas-container" style={{ width: canvasSize.width, height: canvasSize.height }}>
                      <canvas ref={canvasRef}></canvas>

                      {/* Placeable Signature */}
                      {sigProcessedUrl && (
                        <div
                          ref={sigElementRef}
                          className={`esig-sig-on-doc ${isDragging ? 'dragging' : ''}`}
                          onMouseDown={handleMouseDown}
                          style={{
                            left: sigPosition.x,
                            top: sigPosition.y,
                            width: sigSize.width,
                            height: sigSize.height,
                            zIndex: 10
                          }}
                        >
                          <img src={sigProcessedUrl} alt="Signature Placement" style={{ transform: `rotate(${sigAngle}deg)` }} />
                          <div className="esig-sig-resize-handle"></div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="esig-doc-info-bar">
                    💡 Drag to position. Drag the dot at bottom-right of signature to resize. Use buttons on left for precision control.
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 30 }}>
                <button className="btn btn-outline" onClick={() => setStep(2)}>&larr; Back to Signature Prep</button>
                <button className="btn btn-success" onClick={handleSignAndDownload}><svg className="esig-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M12 20h9" />
                  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
                </svg> Stamp &amp; Download Signed PDF</button>
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="esig-modal-footer">
            <span className="esig-footer-info">🔒 PixPDF Studio: Your files are processed securely in your browser and local server.</span>
            <div className="esig-footer-actions">
              <button className="btn btn-sm btn-outline" onClick={onClose}>Cancel</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Export to window so app.js can access it
  window.ESignatureModal = ESignatureModal;
})();
