/* =============================================
   SHARED REACT COMPONENTS
   Used by all tool pages via window.Components
   ============================================= */
'use strict';

const { useState, useRef, useCallback, useEffect } = React;

/* ─── API BASE ─── */
const API = 'http://localhost:8000/api';

/* ─────────────────────────────────────────────
   DropZone Component
──────────────────────────────────────────────*/
function DropZone({ onFiles, accept = "*", multiple = false, label = "Drop files here", subLabel }) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef();

  const handle = (files) => {
    if (!files || files.length === 0) return;
    onFiles(multiple ? Array.from(files) : [files[0]]);
  };

  return (
    <div
      className={`drop-zone ${dragging ? 'drag-over' : ''}`}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files); }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={e => handle(e.target.files)}
      />
      <div className="drop-zone-icon" style={{ marginBottom: 16, display: 'flex', justifyContent: 'center' }}>
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--accent)', filter: 'drop-shadow(0 0 8px rgba(100,120,255,0.4))' }}>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="17 8 12 3 7 8" />
          <line x1="12" y1="3" x2="12" y2="15" />
        </svg>
      </div>
      <div className="drop-zone-text">{label}</div>
      <div className="drop-zone-sub">{subLabel || (multiple ? 'Click or drag multiple files' : 'Click or drag a file')}</div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   FileList Component
──────────────────────────────────────────────*/
function FileList({ files, onRemove, onMove }) {
  if (!files || files.length === 0) return null;
  const fmt = (n) => n > 1024 * 1024 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1024).toFixed(0)} KB`;

  return (
    <div className="file-list">
      {files.map((f, i) => (
        <div key={i} className="file-item draggable-item">
          <span className="drag-handle">⠿</span>
          <span className="file-item-name">📄 {f.name}</span>
          <span className="file-item-size">{fmt(f.size)}</span>
          {onMove && i > 0 && (
            <button className="btn btn-sm btn-outline" style={{ padding: '4px 8px' }} onClick={() => onMove(i, i - 1)}>↑</button>
          )}
          {onMove && i < files.length - 1 && (
            <button className="btn btn-sm btn-outline" style={{ padding: '4px 8px' }} onClick={() => onMove(i, i + 1)}>↓</button>
          )}
          {onRemove && (
            <button className="file-item-remove" onClick={() => onRemove(i)}>✕</button>
          )}
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────────────────────────────
   Alert Component
──────────────────────────────────────────────*/
function Alert({ type = "info", children }) {
  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  return (
    <div className={`alert alert-${type}`}>
      <span>{icons[type]}</span>
      <span>{children}</span>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Progress Component
──────────────────────────────────────────────*/
function Progress({ value = 0, label = "Processing…" }) {
  return (
    <div className="progress-wrap">
      <div className="progress-label">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="progress-bar-bg">
        <div className="progress-bar-fill" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Spinner Component
──────────────────────────────────────────────*/
function Spinner({ text = "Processing…" }) {
  return (
    <div className="alert alert-info">
      <div className="spinner" />
      <span>{text}</span>
    </div>
  );
}

/* ─────────────────────────────────────────────
   FormGroup Component
──────────────────────────────────────────────*/
function FormGroup({ label, children, hint }) {
  return (
    <div className="form-group">
      {label && <label className="form-label">{label}</label>}
      {children}
      {hint && <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{hint}</span>}
    </div>
  );
}

/* ─────────────────────────────────────────────
   Slider Component
──────────────────────────────────────────────*/
function Slider({ label, min, max, step = 1, value, onChange, displayValue }) {
  return (
    <FormGroup label={label}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <input type="range" className="form-range" min={min} max={max} step={step}
          value={value} onChange={e => onChange(Number(e.target.value))} style={{ flex: 1 }} />
        <span className="range-value">{displayValue !== undefined ? displayValue : value}</span>
      </div>
    </FormGroup>
  );
}

/* ─────────────────────────────────────────────
   ImagePreview Component
──────────────────────────────────────────────*/
function ImagePreview({ src, title = "Preview", info }) {
  if (!src) return null;
  return (
    <div className="preview-panel fade-in">
      <div className="preview-header">
        <span>🖼 {title}</span>
        {info && <span style={{ color: 'var(--accent)' }}>{info}</span>}
      </div>
      <div className="preview-body">
        <img src={src} alt={title} className="preview-img" />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   DownloadButton Component
──────────────────────────────────────────────*/
function DownloadButton({ url, filename, children = "⬇ Download" }) {
  if (!url) return null;
  return (
    <a href={url} download={filename} className="btn btn-success fade-in">
      {children}
    </a>
  );
}

/* ─────────────────────────────────────────────
   API helpers
──────────────────────────────────────────────*/
async function apiPost(endpoint, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API}${endpoint}`);
    xhr.responseType = 'blob';
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve({ blob: xhr.response, headers: xhr });
      } else {
        const parseError = (t) => {
          try {
            const j = JSON.parse(t);
            if (j && j.detail) return reject(new Error(typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail)));
          } catch (_) {}
          reject(new Error(t || `HTTP ${xhr.status}`));
        };
        if (xhr.response && typeof xhr.response.text === 'function') {
          xhr.response.text().then(parseError).catch(() => reject(new Error(`HTTP ${xhr.status}`)));
        } else {
          reject(new Error(`HTTP ${xhr.status}`));
        }
      }
    };
    xhr.onerror = () => reject(new Error('Network error'));
    if (onProgress) {
      xhr.upload.onprogress = e => {
        if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 80));
      };
    }
    xhr.send(formData);
  });
}

async function apiPostJson(endpoint, formData) {
  const res = await fetch(`${API}${endpoint}`, { method: 'POST', body: formData });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function blobUrl(blob) {
  return URL.createObjectURL(blob);
}

function fmt(n) {
  return n > 1024 * 1024 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1024).toFixed(0)} KB`;
}

/* ─────────────────────────────────────────────
   useFileProcessor hook
──────────────────────────────────────────────*/
function useFileProcessor() {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [resultUrl, setResultUrl] = useState('');
  const [resultBlob, setResultBlob] = useState(null);

  const reset = () => { setError(''); setResultUrl(''); setResultBlob(null); setProgress(0); };

  const process = useCallback(async (endpoint, fd, filename) => {
    setLoading(true);
    setError('');
    setResultUrl('');
    setProgress(10);
    try {
      const { blob } = await apiPost(endpoint, fd, p => setProgress(p));
      setProgress(95);
      const url = blobUrl(blob);
      setResultUrl(url);
      setResultBlob(blob);
      setProgress(100);
    } catch (e) {
      setError(e.message || 'Processing failed');
    } finally {
      setLoading(false);
    }
  }, []);

  return { loading, progress, error, resultUrl, resultBlob, process, reset, setError };
}

function validateFiles(fileList) {
  const MAX_IMAGE_SIZE = 50 * 1024 * 1024; // 50MB
  const MAX_PDF_SIZE = 250 * 1024 * 1024; // 250MB
  for (let i = 0; i < fileList.length; i++) {
    const f = fileList[i];
    const isPdf = f.name.toLowerCase().endsWith('.pdf') || f.type === 'application/pdf';
    if (isPdf) {
      if (f.size > MAX_PDF_SIZE) {
        return `File "${f.name}" exceeds the maximum PDF size limit of 250MB.`;
      }
    } else {
      if (f.size > MAX_IMAGE_SIZE) {
        return `File "${f.name}" exceeds the maximum image size limit of 50MB.`;
      }
    }
  }
  return null;
}

function getDownloadFilename(title, files, defaultExt = '') {
  if (!files || files.length === 0) return 'output_file' + defaultExt;
  const originalName = files[0].name;
  const lastDot = originalName.lastIndexOf('.');
  const baseName = lastDot !== -1 ? originalName.substring(0, lastDot) : originalName;
  const origExt = lastDot !== -1 ? originalName.substring(lastDot) : '';
  const prefix = title.replace(/[^a-zA-Z0-9]/g, '_').replace(/_+/g, '_');

  if (defaultExt) {
    return `${prefix}_${baseName}${defaultExt}`;
  }
  return `${prefix}_${baseName}${origExt}`;
}

function ToolIcon({ id, size = 20, style = {} }) {
  const props = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: { display: 'inline-block', verticalAlign: 'middle', ...style }
  };

  switch (id) {
    case 'home':
      return (
        <svg {...props}>
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      );
    case 'about':
      return (
        <svg {...props}>
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="16" x2="12" y2="12" />
          <line x1="12" y1="8" x2="12.01" y2="8" />
        </svg>
      );
    case 'compress':
    case 'pdf-compress':
      return (
        <svg {...props}>
          <path d="M4 14h6v6M20 10h-6V4M14 10l7-7M10 14l-7 7" />
        </svg>
      );
    case 'resize':
      return (
        <svg {...props}>
          <rect x="2" y="2" width="16" height="16" rx="2" />
          <polyline points="21 15 21 21 15 21" />
          <line x1="10" y1="14" x2="21" y2="21" />
        </svg>
      );
    case 'crop':
    case 'pdf-split':
      return (
        <svg {...props}>
          <path d="M6 1v5h12M1 6h18v12M18 13v8M13 18h8" />
        </svg>
      );
    case 'convert':
    case 'pdf-to-img':
      return (
        <svg {...props}>
          <path d="M17 2.1l4 4-4 4M3 22v-6h6M21 2v6h-6M7 21.9l-4-4 4-4" />
          <path d="M3 16a9 9 0 0 1 14.3-7.3M21 8a9 9 0 0 1-14.3 7.3" />
        </svg>
      );
    case 'edit':
      return (
        <svg {...props}>
          <line x1="4" y1="21" x2="4" y2="14" />
          <line x1="4" y1="10" x2="4" y2="3" />
          <line x1="12" y1="21" x2="12" y2="12" />
          <line x1="12" y1="8" x2="12" y2="3" />
          <line x1="20" y1="21" x2="20" y2="16" />
          <line x1="20" y1="12" x2="20" y2="3" />
          <line x1="2" y1="14" x2="6" y2="14" />
          <line x1="10" y1="8" x2="14" y2="8" />
          <line x1="18" y1="16" x2="22" y2="16" />
        </svg>
      );
    case 'upscale':
      return (
        <svg {...props}>
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
          <line x1="11" y1="8" x2="11" y2="14" />
          <line x1="8" y1="11" x2="14" y2="11" />
        </svg>
      );
    case 'remove-bg':
    case 'remove-watermark':
      return (
        <svg {...props}>
          <path d="M18 2l4 4M2 18l12-12M6 22l12-12M10 22l4-4" />
          <path d="M3 6h2M6 3v2" />
        </svg>
      );
    case 'watermark':
    case 'pdf-watermark':
      return (
        <svg {...props}>
          <path d="M12 22a7 7 0 0 0 7-7c0-4.3-7-11-7-11S5 10.7 5 15a7 7 0 0 0 7 7z" />
        </svg>
      );
    case 'rotate':
    case 'pdf-rotate':
      return (
        <svg {...props}>
          <path d="M21.5 2v6h-6M21.34 8a10 10 0 1 0-.45 6.27" />
        </svg>
      );
    case 'html-to-img':
      return (
        <svg {...props}>
          <circle cx="12" cy="12" r="10" />
          <line x1="2" y1="12" x2="22" y2="12" />
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
        </svg>
      );
    case 'blur-face':
      return (
        <svg {...props}>
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
          <circle cx="12" cy="12" r="4" strokeDasharray="2,2" />
        </svg>
      );
    case 'img-to-pdf':
      return (
        <svg {...props}>
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <line x1="9" y1="15" x2="15" y2="15" />
          <line x1="9" y1="12" x2="15" y2="12" />
        </svg>
      );
    case 'bg-color':
      return (
        <svg {...props}>
          <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" />
          <path d="M12 18a6 6 0 1 0 0-12v12z" fill="currentColor" />
        </svg>
      );
    case 'passport-img':
      return (
        <svg {...props}>
          <rect x="3" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" />
          <rect x="14" y="14" width="7" height="7" rx="1" />
        </svg>
      );
    case 'micro-pdf':
      return (
        <svg {...props}>
          <rect x="3" y="3" width="18" height="18" rx="2" />
          <line x1="12" y1="3" x2="12" y2="21" />
          <line x1="3" y1="12" x2="21" y2="12" />
        </svg>
      );
    case 'pdf-merge':
      return (
        <svg {...props}>
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <path d="M9 15h6M9 12h6" />
        </svg>
      );
    case 'pdf-protect':
      return (
        <svg {...props}>
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
      );
    case 'pdf-unlock':
      return (
        <svg {...props}>
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0 1 9.9-1" />
        </svg>
      );
    default:
      return (
        <svg {...props}>
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="16" />
          <line x1="8" y1="12" x2="16" y2="12" />
        </svg>
      );
  }
}

/* ─── Export to window ─── */
window.Components = {
  DropZone, FileList, Alert, Progress, Spinner,
  FormGroup, Slider, ImagePreview, DownloadButton,
  useFileProcessor, apiPost, apiPostJson, blobUrl, fmt, API,
  validateFiles, getDownloadFilename, ToolIcon
};
