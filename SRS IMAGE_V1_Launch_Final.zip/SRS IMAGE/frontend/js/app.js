'use strict';
const { useState, useEffect } = React;
const C = window.Components;

/* ─── TOOL DEFINITIONS ─── */
const TOOLS = [
  { id: 'img-to-pdf', label: 'Image to PDF', icon: '📋', cat: 'image', desc: 'Multiple images → PDF' },
  { id: 'bg-color', label: 'BG Color Changer', icon: '🎭', cat: 'image', desc: 'Change background color' },
  { id: 'compress', label: 'Compress Image', icon: '🗜', cat: 'image', desc: 'Reduce image file size' },
  { id: 'resize', label: 'Resize Image', icon: '📐', cat: 'image', desc: 'Change dimensions' },
  { id: 'crop', label: 'Crop Image', icon: '✂️', cat: 'image', desc: 'Crop to selection' },
  { id: 'convert', label: 'Convert Format', icon: '🔄', cat: 'image', desc: 'JPG, PNG, WEBP, GIF…' },
  { id: 'edit', label: 'Photo Editing', icon: '🎨', cat: 'image', desc: 'Brightness, contrast, saturation' },
  { id: 'upscale', label: 'Upscale Image', icon: '🔍', cat: 'image', desc: '2× / 4× AI upscale' },
  { id: 'remove-bg', label: 'Remove Background', icon: '🪄', cat: 'image', desc: 'AI background removal' },
  { id: 'watermark', label: 'Watermark Image', icon: '💧', cat: 'image', desc: 'Add text watermark' },
  { id: 'rotate', label: 'Rotate Image', icon: '🔃', cat: 'image', desc: 'Rotate any angle' },
  { id: 'html-to-img', label: 'HTML to Image', icon: '🌐', cat: 'image', desc: 'URL/HTML screenshot' },
  { id: 'blur-face', label: 'Blur Face', icon: '😶', cat: 'image', desc: 'Auto face blurring' },
  { id: 'passport-img', label: 'Passport Photo', icon: '🪪', cat: 'new', desc: 'Printable passport sheet' },
  { id: 'remove-watermark', label: 'Remove Watermark', icon: '🧽', cat: 'new', desc: 'Erase watermarks with AI' },
  { id: 'micro-pdf', label: 'Micro PDF', icon: '🔢', cat: 'new', desc: 'N pages per sheet layout' },
  { id: 'pdf-to-docx', label: 'PDF to Docx', icon: '📝', cat: 'pdf', desc: 'Convert PDF to Word Document' },
  { id: 'docx-to-pdf', label: 'Docx to PDF', icon: '📄', cat: 'pdf', desc: 'Convert Word Document to PDF' },
  { id: 'pdf-compress', label: 'Compress PDF', icon: '🗜', cat: 'pdf', desc: 'Reduce PDF size' },
  { id: 'pdf-merge', label: 'Merge PDF', icon: '📎', cat: 'pdf', desc: 'Combine multiple PDFs' },
  { id: 'pdf-split', label: 'Split PDF', icon: '✂️', cat: 'pdf', desc: 'Extract pages' },
  { id: 'pdf-to-img', label: 'PDF to Image', icon: '🖼', cat: 'pdf', desc: 'Convert pages to JPG/PNG' },
  { id: 'pdf-watermark', label: 'Watermark PDF', icon: '💧', cat: 'pdf', desc: 'Add watermark to PDF' },
  { id: 'pdf-remove-watermark', label: 'Remove PDF Watermark', icon: '🧽', cat: 'pdf', desc: 'Remove text watermarks' },
  { id: 'pdf-protect', label: 'Protect PDF', icon: '🔒', cat: 'pdf', desc: 'Password encrypt PDF' },
  { id: 'pdf-rotate', label: 'Rotate PDF', icon: '🔃', cat: 'pdf', desc: 'Rotate PDF pages' },
  { id: 'pdf-unlock', label: 'Unlock PDF', icon: '🔓', cat: 'pdf', desc: 'Remove PDF password' },
];

const CAT_LABELS = { image: 'Image Tools', new: 'New Image/PDF Tools', pdf: 'PDF Tools' };
const CAT_CLASS = { image: 'cat-image', new: 'cat-new', pdf: 'cat-pdf' };
const UPCOMING_TOOLS = ['remove-watermark'];

/* ─── UPCOMING TOOL PAGE ─── */
function UpcomingToolPage({ toolLabel }) {
  return (
    <div className="page-body fade-in" style={{ maxWidth: 560, margin: '48px auto', textAlign: 'center' }}>
      <div style={{
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border)',
        borderRadius: 16,
        padding: '48px 32px',
        boxShadow: 'var(--shadow)'
      }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🚧</div>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 12, color: 'var(--text-primary)' }}>
          Upcoming tool
        </h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 15, lineHeight: 1.6, marginBottom: 8 }}>
          <strong>{toolLabel || 'This tool'}</strong> is under development and will be available soon.
        </p>
        <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
          Check back in a future update.
        </p>
      </div>
    </div>
  );
}

/* ─── HOME PAGE ─── */
function HomePage({ navigate }) {
  const [search, setSearch] = useState('');
  const cats = ['image', 'new', 'pdf'];

  const filteredTools = TOOLS.filter(t =>
    t.label.toLowerCase().includes(search.toLowerCase()) ||
    t.desc.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-body fade-in">
      <div style={{ marginBottom: 36, position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 12 }}>
          <div className="hero-icon-wrap" style={{ background: 'var(--accent-grad)', width: 64, height: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '16px', boxShadow: 'var(--shadow-glow)', color: '#ffffff' }}>
            <C.ToolIcon id="home" size={32} />
          </div>
          <div>
            <h1 className="page-title" style={{ marginBottom: 4, fontSize: 32, letterSpacing: '-0.5px' }}>PixPDF Studio</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: 15, fontWeight: 400 }}>
              The ultimate privacy-first suite for high-performance image &amp; PDF processing.
            </p>
          </div>
        </div>

        {/* Search bar */}
        <div style={{ position: 'relative', marginTop: 24, maxWidth: 500 }}>
          <input
            type="text"
            className="form-input search-input"
            placeholder="Search tools (e.g. compress, split, rotate)..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              paddingLeft: 44,
              height: 48,
              borderRadius: '10px',
              fontSize: 14,
              background: 'rgba(255,255,255,0.03)',
              borderColor: 'var(--border)'
            }}
          />
          <span style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', display: 'flex', alignItems: 'center', color: 'var(--text-muted)' }}>
            <C.ToolIcon id="upscale" size={16} />
          </span>
          {search && (
            <button
              onClick={() => setSearch('')}
              style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 16 }}
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {search ? (
        <div>
          <p className="section-heading">Search Results ({filteredTools.length})</p>
          {filteredTools.length > 0 ? (
            <div className="tools-grid">
              {filteredTools.map(t => (
                <div key={t.id} className="tool-card-home" onClick={() => navigate(t.id)}>
                  <span className={`category-label ${CAT_CLASS[t.cat]}`}>{CAT_LABELS[t.cat]}</span>
                  <span className="icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
                    <C.ToolIcon id={t.id} size={28} />
                  </span>
                  <h3>{t.label}</h3>
                  <p>{t.desc}</p>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '48px 24px', background: 'var(--bg-card)', borderRadius: 16, border: '1px solid var(--border)', color: 'var(--text-secondary)' }}>
              <div style={{ marginBottom: 12, display: 'flex', justifyContent: 'center' }}>
                <C.ToolIcon id="alert" size={36} style={{ color: 'var(--warning)' }} />
              </div>
              No tools found matching "{search}".
            </div>
          )}
        </div>
      ) : (
        cats.map(cat => (
          <div key={cat}>
            <p className="section-heading">{CAT_LABELS[cat]}</p>
            <div className="tools-grid">
              {TOOLS.filter(t => t.cat === cat).map(t => (
                <div key={t.id} className="tool-card-home" onClick={() => navigate(t.id)}>
                  <span className={`category-label ${CAT_CLASS[cat]}`}>{CAT_LABELS[cat]}</span>
                  <span className="icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
                    <C.ToolIcon id={t.id} size={28} />
                  </span>
                  <h3>{t.label}</h3>
                  <p>{t.desc}</p>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

/* ─── SIDEBAR ─── */
function Sidebar({ active, navigate, open, onClose }) {
  const cats = ['image', 'new', 'pdf'];
  return (
    <>
      {open && <div className="sidebar-overlay open" onClick={onClose} />}
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-logo" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <img src="favicon.png" style={{ width: 28, height: 28, borderRadius: 6, objectFit: 'cover' }} alt="Logo" />
            <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: 'var(--text-primary)' }}>PixPDF Studio</h1>
          </div>
          <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Professional Document Suite</span>
        </div>
        <div className="sidebar-section">
          <div className={`nav-item ${active === 'home' ? 'active' : ''}`} onClick={() => { navigate('home'); onClose(); }}>
            <span className="nav-icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><C.ToolIcon id="home" size={16} /></span> Home
          </div>
          <div className={`nav-item ${active === 'about' ? 'active' : ''}`} onClick={() => { navigate('about'); onClose(); }}>
            <span className="nav-icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><C.ToolIcon id="about" size={16} /></span> About Us
          </div>
        </div>
        {cats.map(cat => (
          <div className="sidebar-section" key={cat}>
            <div className="sidebar-section-label">{CAT_LABELS[cat]}</div>
            {TOOLS.filter(t => t.cat === cat).map(t => (
              <div key={t.id} className={`nav-item ${active === t.id ? 'active' : ''}`}
                onClick={() => { navigate(t.id); onClose(); }}>
                <span className="nav-icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><C.ToolIcon id={t.id} size={16} /></span>
                {t.label}
              </div>
            ))}
          </div>
        ))}
      </aside>
    </>
  );
}

/* ─── HEADER ─── */
function Header({ page, onToggleSidebar, navigate, theme, onToggleTheme, onOpenEsignature, onOpenResume }) {
  const tool = TOOLS.find(t => t.id === page);
  return (
    <header className="top-header">
      <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
        <button className="hamburger" onClick={onToggleSidebar}>☰</button>
        <div className="page-breadcrumb" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontWeight: 700, color: 'var(--text-primary)', cursor: 'pointer' }} onClick={() => navigate('home')}>PixPDF Studio</span>
          <span style={{ color: 'var(--text-muted)' }}>/</span>
          <span>{page === 'about' ? 'About Us' : tool ? tool.label : 'Home'}</span>
        </div>
      </div>
      <nav className="header-nav-links" style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
        <button
          onClick={onOpenEsignature}
          className="esig-header-btn"
          style={{ marginRight: 8 }}
          title="Open E-Signature Suite"
        >
          <span className="esig-header-btn-pulse"></span>
          <svg className="esig-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
          </svg>
          E-Signature
        </button>
        <button
          onClick={onOpenResume}
          className="esig-header-btn"
          style={{ marginRight: 8, background: 'linear-gradient(135deg, #10b981, #06b6d4)' }}
          title="Open Resume Builder"
        >
          <svg className="esig-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
            <polyline points="10 9 9 9 8 9" />
          </svg>
          Resume Builder
        </button>
        <span
          onClick={() => navigate('home')}
          style={{ cursor: 'pointer', fontSize: 14, fontWeight: 500, color: page === 'home' ? 'var(--accent)' : 'var(--text-secondary)' }}
        >
          Home
        </span>
        <span
          onClick={() => navigate('about')}
          style={{ cursor: 'pointer', fontSize: 14, fontWeight: 500, color: page === 'about' ? 'var(--accent)' : 'var(--text-secondary)' }}
        >
          About Us
        </span>
        <button
          onClick={onToggleTheme}
          style={{
            background: 'none',
            border: 'none',
            color: 'var(--text-primary)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 6,
            borderRadius: '50%',
            transition: 'background 0.2s',
            width: 32,
            height: 32
          }}
          title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
          className="theme-toggle-btn"
        >
          {theme === 'light' ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>
          )}
        </button>
      </nav>
      <div className="header-badge" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 8px var(--success)' }}></span>
        v1.0 · Privacy-First
      </div>
    </header>
  );
}

/* ─── ABOUT US PAGE ─── */
function AboutPage({ navigate }) {
  return (
    <div className="page-body fade-in" style={{ maxWidth: 800, margin: '0 auto', padding: '48px 32px' }}>
      <div style={{ textAlign: 'center', marginBottom: 48 }}>
        <h1 style={{ fontSize: 36, fontWeight: 800, marginBottom: 16, background: 'var(--accent-grad)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
          About PixPDF Studio
        </h1>
        <p style={{ fontSize: 16, color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 600, margin: '0 auto' }}>
          We believe you shouldn't have to sacrifice your privacy to compress a PDF, resize an image, or format a passport photo.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginBottom: 48 }}>
        <div style={{ background: 'var(--bg-secondary)', padding: 24, borderRadius: 16, border: '1px solid var(--border)', boxShadow: 'var(--shadow)' }}>
          <C.ToolIcon id="pdf-protect" size={28} style={{ color: 'var(--accent)', marginBottom: 12, display: 'block' }} />
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: 'var(--text-primary)' }}>100% Client-Side</h3>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5 }}>
            PixPDF Studio runs entirely in your web browser. Your files are never uploaded to any remote server or third party. Your data remains yours.
          </p>
        </div>

        <div style={{ background: 'var(--bg-secondary)', padding: 24, borderRadius: 16, border: '1px solid var(--border)', boxShadow: 'var(--shadow)' }}>
          <C.ToolIcon id="resize" size={28} style={{ color: 'var(--accent)', marginBottom: 12, display: 'block' }} />
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: 'var(--text-primary)' }}>High Performance</h3>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5 }}>
            By leveraging state-of-the-art Web APIs, canvas scaling, and client-side processing, PixPDF Studio processes files at lightning speed.
          </p>
        </div>
      </div>

      <div style={{ background: 'var(--bg-secondary)', padding: 32, borderRadius: 16, border: '1px solid var(--border)', boxShadow: 'var(--shadow)', marginBottom: 48 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 16, color: 'var(--text-primary)' }}>Technical Specifications</h2>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 16 }}>
          PixPDF Studio is designed for high-performance offline document and image editing under the following conditions:
        </p>
        <ul style={{ paddingLeft: 20, fontSize: 14, color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <li><strong>Maximum File Limits:</strong> Up to 50 MB for images and 250 MB for PDF documents.</li>
          <li><strong>Supported File Formats:</strong> Seamless conversion and processing across PDF, JPG, PNG, WEBP, and GIF.</li>
          <li><strong>Security Standard:</strong> 100% serverless client-side processing, meaning zero remote transmission or storage.</li>
          <li><strong>Browser Compatibility:</strong> Fully optimized for any modern browser environment supporting HTML5 Canvas, File API, and WebAssembly.</li>
        </ul>
      </div>

      <div style={{ textAlign: 'center' }}>
        <button className="btn btn-primary" onClick={() => navigate('home')}>
          Get Started - Browse Tools
        </button>
      </div>
    </div>
  );
}

/* ─── FOOTER ─── */
function Footer({ navigate }) {
  return (
    <footer style={{
      background: 'var(--bg-secondary)',
      borderTop: '1px solid var(--border)',
      padding: '32px 32px 24px 32px',
      marginTop: 'auto',
      color: 'var(--text-secondary)'
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: 32,
        maxWidth: 1100,
        margin: '0 auto',
        fontSize: 14
      }}>
        <div style={{ maxWidth: 350 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <img src="favicon.png" style={{ width: 22, height: 22, borderRadius: 5, objectFit: 'cover' }} alt="Logo" />
            <h3 style={{ color: 'var(--text-primary)', fontWeight: 700, margin: 0, fontSize: 16 }}>PixPDF Studio</h3>
          </div>
          <p style={{ color: 'var(--text-muted)', lineHeight: 1.6, fontSize: 13 }}>
            A high-performance, private, client-side document processing suite. All files stay on your device.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 48 }}>
          <div>
            <h4 style={{ color: 'var(--text-primary)', fontWeight: 600, marginBottom: 12, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Links</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <span onClick={() => navigate('home')} style={{ cursor: 'pointer', transition: 'color 0.2s' }} className="footer-link">Home</span>
              <span onClick={() => navigate('about')} style={{ cursor: 'pointer', transition: 'color 0.2s' }} className="footer-link">About Us</span>
            </div>
          </div>
          <div>
            <h4 style={{ color: 'var(--text-primary)', fontWeight: 600, marginBottom: 12, fontSize: 13, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Security</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 13, color: 'var(--text-muted)' }}>
              <span>🔒 Local Processing</span>
              <span>🛡️ No Data Logging</span>
            </div>
          </div>
        </div>
      </div>
      <div style={{
        borderTop: '1px solid var(--border)',
        marginTop: 24,
        paddingTop: 16,
        textAlign: 'center',
        fontSize: 12,
        color: 'var(--text-muted)',
        display: 'flex',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 12,
        maxWidth: 1100,
        margin: '24px auto 0 auto'
      }}>
        <span>&copy; {new Date().getFullYear()} PixPDF Studio. All rights reserved.</span>
        <span>Made with 🤍 for private document editing.</span>
      </div>
    </footer>
  );
}

/* ─── MAIN APP ─── */
function App() {
  const [page, setPage] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [esignOpen, setEsignOpen] = useState(false);
  const [resumeOpen, setResumeOpen] = useState(() => window.ResumeBuilderAutoOpen && window.ResumeBuilderAutoOpen());

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(t => t === 'light' ? 'dark' : 'light');

  const navigate = (p) => { setPage(p); window.scrollTo(0, 0); };

  const PageComponent = window.Pages && window.Pages[page];

  return (
    <div className="app-layout">
      <div className="hero-bg" />
      <Sidebar active={page} navigate={navigate} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="main-content" style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <Header
          page={page}
          onToggleSidebar={() => setSidebarOpen(s => !s)}
          navigate={navigate}
          theme={theme}
          onToggleTheme={toggleTheme}
          onOpenEsignature={() => setEsignOpen(true)}
          onOpenResume={() => setResumeOpen(true)}
        />
        <div style={{ flex: 1 }}>
          {page === 'home'
            ? <HomePage navigate={navigate} />
            : page === 'about'
              ? <AboutPage navigate={navigate} />
              : UPCOMING_TOOLS.includes(page)
                ? <UpcomingToolPage toolLabel={TOOLS.find(t => t.id === page)?.label} />
                : PageComponent
                  ? <PageComponent />
                  : <div className="page-body"><C.Alert type="info">Tool coming soon.</C.Alert></div>
          }
        </div>
        <Footer navigate={navigate} />
      </div>
      {window.ESignatureModal && <window.ESignatureModal isOpen={esignOpen} onClose={() => setEsignOpen(false)} />}
      {window.ResumeBuilderModal && <window.ResumeBuilderModal isOpen={resumeOpen} onClose={() => setResumeOpen(false)} />}
    </div>
  );
}

window.AppRoot = App;
